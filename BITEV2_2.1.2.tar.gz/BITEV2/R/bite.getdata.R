bite.getdata <- function(gds.path, node) {

  # get data from Genomic Data Structure objects

  showfile.gds(closeall = T, verbose = F)
  gds.temp <- snpgdsOpen(gds.path)

  if (node == "genotype") {
    return (snpgdsGetGeno(gds.temp, verbose = F))
  } else {
    return (read.gdsn(index.gdsn(gds.temp, node)))
  }
}

