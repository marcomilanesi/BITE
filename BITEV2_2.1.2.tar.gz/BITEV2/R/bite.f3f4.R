
################################################################################
################################# BITE F3 F4 ###################################
################################################################################


bite.f3f4 <- function (in.file, out.dir, f3Z = -1.65, f4Z = 1.96, figLabel = "Figure") {

  #if (!require("poolfstat")) install.packages("poolfstat")

  cat("\n")
  cat("When using bite.f3f4 please cite: \n1. Gautier M, Vitalis R, Flori L and Estoup A (2022). f-statistics estimation and admixture graph construction with Pool-Seq or allele count data using the R package poolfstat. Molecular Ecology Resources, 22(4):1394-1416 (preprint version: hal-03481066).\n2. Hivert V, Leblois R, Petit EJ, Gautier M, and Vitalis R (2018). Measuring genetic differentiation from Pool-seq data. Genetics, 210(1):315-330")
  cat("\n")
  cat("\n")
  cat("Runinng ....\n")

  ##### RES DIR #####
  res.dir <- paste0(out.dir, "/bitef3f4")

  if (!file.exists(res.dir)) {
    dir.create(res.dir)
  }

  logname <- paste0(res.dir, "/bite.f3f4.log")
  sink(logname)

  cat("*************** BITE F3 F4 ***************\n")

  input <- poolfstat::genotreemix2countdata(genotreemix.file = in.file) # eventualmente usare snp.pos per definire la posizione degli SNPs
  output <- poolfstat::compute.fstats(input, nsnp.per.bjack.block = 1000, computeDstat = FALSE)

  ##########
  ### Figure
  ##########

  #jpeg(paste0(res.dir, "/", figLabel, ".f3f4.jpeg"), width = 7, height = 7, units = 'in', res = 800)
  #par(mfrow=c(2,1), mar = c(4, 4, 2, 1))

  ####
  # Plotting all f3 tests and identifying tests of interest (multiple testing corretion under development)
  ####
  #plot(output@f3.values$Estimate, 1:length(output@f3.values$Estimate), pch=".", ylab = "Test index", xlab = "F3 statistic", col = "gray")
  #abline(v = 0, lty = 5, col ="red")
  tst.sel <- output@f3.values$`Z-score` < f3Z
  #y.sel <- which(tst.sel)
  #points(output@f3.values[tst.sel, 1], y.sel, col = "red", pch = 16, cex = 0.5)
  #legend("bottomright", legend = paste("Z < ", f3Z), pch = 16, col = "red", bg = "white")

  #####
  # ggplot imp
  #####

  f3.values <- output@f3.values
  f3.values$thresh <- ifelse(f3.values$`Z-score` < f3Z, 1, 0)
  y.sel <- which(f3.values$thresh == 1)

  p1 <- ggplot(data =f3.values) +
    geom_point(aes(x = Estimate, y = 1:length(f3.values$Estimate)), colour = "grey", shape = 16) +
    geom_point(data = subset(f3.values, thresh == 1), aes(x = Estimate, y = y.sel), colour = "red", shape = 16) +
    geom_vline(xintercept = 0, linetype = "dotted", color = "red") +
    xlab(paste("F3 statistic", " (Z < ", f3Z, ")", sep="")) +
    ylab("Test index") +
    theme_classic()

  # Printing f3 tests of interest
  write.table(output@f3.values[tst.sel, ], paste0(res.dir, "/bite.f3.txt"), col.names = TRUE, row.names = TRUE, sep = "\t", quote = FALSE)

  # This is the ad-hoc plotting function from poolfstat - can't be used with extremely large datasets - work in progress
  # plot(output, stat.name = "F3", main = "F3")

  ####
  # Plotting all f4 tests and identifying tests of interest (multiple testing corretion under development)
  ####
  #plot(output@f4.values$Estimate, 1:length(output@f4.values$Estimate), pch=".", ylab = "Test index", xlab = "F4 statistic", col = "gray")
  #abline(v = 0, lty = 1, col ="black")
  tst.sel2 <- abs(output@f4.values$`Z-score`) > f4Z
  #y.sel <- which(tst.sel)
  #points(output@f4.values[tst.sel, 1], y.sel, col = "red", pch = 16, cex = 0.5)
  #legend("bottomright", legend = paste("|Z| > ", f4Z), pch = 16, col = "red", bg = "white")

  #####
  # ggplot imp
  #####

  f4.values <- output@f4.values
  f4.values$thresh <- ifelse(abs(f4.values$`Z-score`) > f4Z, 1, 0)
  y.sel2 <- which(f4.values$thresh == 1)

  p2 <- ggplot(data =f4.values, cond = paste("|Z| > ", f4Z, sep="")) +
    geom_point(aes(x = Estimate, y = 1:length(f4.values$Estimate)), colour = "grey", shape = 15, size = 0.7) +
    geom_vline(xintercept = 0, linetype = "solid", color = "black") +
    geom_point(data = subset(f4.values, thresh == 1), aes(x = Estimate, y = y.sel2), colour = "red", shape = 16) +
    xlab(paste("F4 statistic ", "(|Z| > ", f4Z, ")", sep="")) +
    ylab("Test index") +
    theme_classic()
  p2
  p1
  grid.arr <- grid.arrange(p1, p2)
  ggsave(paste0(res.dir, "/", figLabel, ".f3f4.jpeg"),width = 7, height = 7, units = 'in', dpi = 800, plot = grid.arr)
  # This is the ad-hoc plotting function from poolfstat - can't be used with extremely large datasets - work in progress
  # plot(output, stat.name = "F4",main = "F4")

  # Printing f4 tests of interest
  write.table(output@f4.values[tst.sel2, ], paste0(res.dir, "/bite.f4.txt"), col.names = TRUE, row.names = TRUE, sep = "\t", quote = FALSE)

  dev.off()

  cat("******************************************\n")
  sink()

  return(output)

}
