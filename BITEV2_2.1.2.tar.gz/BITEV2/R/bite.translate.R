



################################################################################
################################# BITE TRANSLATE ###############################
################################################################################


bite.translate <- function(gds.path, out.dir, out.format = "bed", out.name = NULL) {
  cat("Running ....\n")
  showfile.gds(closeall = T, verbose = F)

  gds.in <- snpgdsOpen(gds.path)

  # gds name

  if (is.null(out.name)){
    filename <- basename(gds.in$filename)
    filename <- str_sub(filename, start = 1, end = -5)
    out.name <- filename
  }


  # extract pheno/ordermatrix info
  phenotype <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  family_id <- phenotype$pop
  write.table(phenotype, paste(out.dir, "/pheno_", out.name, ".txt", sep=""), quote = F, )
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))
  colnames(ordermatrix) <- c("pop", "color", "pch")
  write.table(ordermatrix, paste(out.dir, "/ordermatrix_", out.name, ".txt", sep=""), quote = F, )


  # remove pheno/ordermatrix info
  #pheno.gdsn <- index.gdsn(gds.in, "phenotype")
  #order.gdsn <- index.gdsn(gds.in, "ordermatrix")
  #delete.gdsn(pheno.gdsn, force = T)
  #delete.gdsn(order.gdsn, force = T)

  # check out.format
  if (out.format == "bed") {
    snpgdsGDS2BED(gds.in, paste(out.dir, "/", out.name, sep=""), verbose = F)
  } else if (out.format == "ped") {
    snpgdsGDS2PED(gds.in, paste(out.dir, "/", out.name, sep=""), verbose = F)
  } else {
    cat("Invalid out.format ....\n")
    stop("Exit", call. = F)
  }

  # add family id to fam file
  fam_name <- paste(out.dir, "/", out.name, ".fam", sep="")
  fam <- read.table(fam_name)
  fam$V1 <- family_id
  write.table(fam,fam_name, quote = F, col.names = F, row.names = F)

}















