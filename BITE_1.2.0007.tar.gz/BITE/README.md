This is the repository of BITE R package.
It is mantained by:

	1. Marco Milanesi
	2. Stefano Capomaccio
	3. Elia Vajana
	4. Lorenzo Bomba

Basic commands for git usage via shell are listed for your convenience:

# Check the status of your copy of the repo

	git status

# Add a file to the track

	git add FILENAME

# Commit the changes to the repo (locally)

	git commit -m "Instructions on the files you are committing"

# Push the changes to the online repository

	git push -u origin master
