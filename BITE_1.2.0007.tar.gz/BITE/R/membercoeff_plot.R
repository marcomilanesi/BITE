#Script: membercoeff.plot
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Marco Milanesi, Lorenzo Bomba, Stefano Capomaccio
#Contact: marco.milanesi.mm@gmail.com; lory.bomb@gmail.com; capemaster@gmail.com
#Description: Plot ancestral assignment results in an barplot fashion chart 

membercoeff.plot <- function(
  in.file,
  out.file="tmp",
  pop.order.file=NULL,
  id.order.file=NULL,
  k.order.file=NULL,
  k.color.file=NULL,
  software="Admixture",
  maxK=2,
  plot.color=NULL,
  plot.main="ADMIXTURE analyses",
  plot.ylab="Ancestry",
  plot.cex=1,
  plot.format="pdf",
  plot.width=100,
  plot.height=30,
  plot.res=100,
  ...
){
  
  # Parameters
  k.order <- k.order.file
  k.color <- k.color.file
  rm(k.order.file);rm(k.color.file)
  
  ##### Log file #####
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  cat(paste("Input file:",in.file,"\n"))
  cat(paste("Output file:",out.file,"\n"))
  if (software %in% c("Admixture","ADMIXTURE","admixture","FastStructure","faststructure","FASTSTRUCTURE", "Faststructure", "sNMF")){
    cat(paste("Software used:",software,"\n"))
  }else{
    sink()
    cat("Allows software (Admixture, FastStructure and sNMF) not found. Please check! \n")
    stop("Exit",call. = F)
  }
  cat(paste("Max K analysed:",maxK,"\n"))
  if (plot.format %in% c("pdf","png","tiff","tif")){
    cat(paste("Format of output file:",plot.format,"\n\n"))
    sink()
  }else{
    sink()
    cat("Allows plot format not found. Please check! \n")
    stop("Exit",call. = F)
  }
  
  # Previous ordering
  k.prev <- 0
  k.order.maxK <- 0
  if (!is.null(k.order) & !is.null(k.color)){
    if (file.exists(k.order)){
      sink(file=paste(out.file,".log",sep=""), append = T)
      if (file.exists(k.color)){
        k.order.file <- readLines(k.order)
        k.color.file <- readLines(k.color)
        k.order.maxK <- length(k.order.file)+1
        k.color.df <- as.data.frame(matrix(unlist(strsplit(k.color.file, split = "\t")), ncol=3, byrow = T), stringsAsFactors = F)
        colnames(k.color.df) <- k.color.df[1,]
        k.color.df <- k.color.df[-1,]
        if (maxK > k.order.maxK){
          cat("The number of Ks in the k.order argument file is less than maxK argument value. A new 'columnorder' file will be created to include the new Ks. \n")
          if (k.order == paste(out.file,"_columnorder.txt",sep="")){
            sink()
            cat("The name of the new 'columnorder' file will be the same given in the k.order argument. File replacement is not allow. Please check! \n")
            stop("Exit",call. = F)
          }
        }
        cat(paste("Column order for each Ks will be retrived from ",k.order," file and colors from ",k.color," file [only if plot.color option is not used]. \n\n"))
        sink()
        k.prev <- 1
      }else{
        sink()
        cat("File with POP order was not found! Please fill the k.color argument. \n")
        stop("Exit",call. = F)
      }
    }else{
      cat("File with POP order was not found! Please fill the k.order argument. \n")
      stop("Exit",call. = F)
    }
  }
  
  ##### Population order #####
  if (!is.null(pop.order.file)){
    sink(file=paste(out.file,".log",sep=""), append = T)
    cat(paste("Population order from ",pop.order.file," file.\n",sep=""))
    sink()
    if (!file.exists(pop.order.file)){
      cat("Populations order file not found. Please check! \n")
      stop("Exit",call. = F)
    }else{
      popord<-read.table(file=pop.order.file, stringsAsFactors = F)
      if (ncol(popord) != 1){
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      popord <- popord[,1]
      tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F)
      tmppop <- sort(unique(tmpfam[,1]))
      if (length(unique(popord)) != length(tmppop)){
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      rm(tmpfam,tmppop)
    }    
  }else{
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Populations order automatically retrive from ",in.file,".fam. Population will be alphabetically sorted by name.\n",sep=""))
    sink()
    tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F) 
    popord<-sort(unique(tmpfam[,1]))
  }
  sink(file=paste(out.file,".log",sep=""), append = TRUE)
  cat("Population order: \n",(paste(popord,collapse=" ")),"\n\n")
  sink()
  
  ##### Individual order #####
  if (file.exists(paste(in.file,"fam",sep=".")) == FALSE){
    cat(".fam file wasn't found. Please check! \n")
    stop("Exit",call. = F)
  }
  if (!is.null(id.order.file)){
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Individuals order from ",id.order.file," file. \n\n",sep=""))
    sink()
    if (!file.exists(id.order.file)){
      cat("Individual order file not found. Please check! \n")
      stop("Exit",call. = F)
    }else{
      key<-read.table(id.order.file)
      if (ncol(key) != 3){
        cat("The format of individual order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F)
      if (nrow(key) != nrow(tmpfam)){
        cat("The format of individual order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      rm(tmpfam)
    }    
  }else{
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Individuals order automatically retrive from ",in.file,".fam.\n\n",sep=""))
    sink()
    tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F) 
    key<-cbind(seq(1,nrow(tmpfam)),tmpfam[,1:2])
  }
  
  ##### Output file #####
  outf.plotorder<-paste(out.file,"_columnorder.txt",sep="")
  if (file.exists(outf.plotorder)){
    file.remove(outf.plotorder)
  }
  
  ### Graphs
  width.in<-plot.width/2.54
  height.in<-plot.height/2.54
  
  ##### Colors #####
  if (is.null(plot.color)){
    Mycol1<-c("red","darkblue","#e3c92e","green3","orange","purple","hotpink3","brown","gray50","blue2","darkgoldenrod3", "coral2","cornflowerblue", "darkolivegreen","cyan2", "darkgreen", "pink", "darkorange2", "deeppink", "deepskyblue", "dodgerblue2", "firebrick3", "gold", "indianred1", "khaki3", "lightsalmon", "lightslateblue", "mediumorchid1", "mediumpurple1", "royalblue1")
    set.seed(3)
    numcol<-maxK
    Mycol2<-NULL
    for (i in 1:numcol){
      red<-toupper(as.hexmode(sample(16:255,1)))
      green<-toupper(as.hexmode(sample(16:255,1)))
      blue<-toupper(as.hexmode(sample(16:255,1)))
      Mycol2[i]<-paste("#",red,green,blue,sep="")
    }
    Mycol<-c(Mycol1,Mycol2)
    rm(Mycol1);rm(Mycol2)
  }else{
    Mycol <- plot.color
    if (length(Mycol) < maxK){
      cat("The color vector contain less color than K to plot. Please check! \n")
      stop("Exit",call. = F)
    }
  }
  # if k.color file is used
  if (k.prev == 1 & is.null(plot.color)){
    Mycol <- c(k.color.df[,3],Mycol[-(which(Mycol %in% k.color.df[,3]))])
  }
  sink(file=paste(out.file,".log",sep=""), append = TRUE)
  if (is.null(plot.color)){
    cat("The function will create automatically a palette of distinct colors. \n\n")
  }else{
    cat("Ancestry color from custom vector: \n",(paste(Mycol,collapse=" ")),"\n\n")
  }
  sink()
  
  
  ### Option ###
  options(stringsAsFactors=F)
  
  ##### Ks preparations and plotting #####
  for (i in 2:maxK){
    cat("Plotting K --> ",i,"      \r")
    
    # Read the file
    if (software %in% c("Admixture","ADMIXTURE","admixture","sNMF")){
      filename <- paste(in.file,".",i,".Q",sep="")
      if (file.exists(filename) == FALSE){
        cat(paste("File ",filename," not found. Please check the name of your file or the software argument used! \n",sep=""))
        stop("Exit",call. = F)
      }
    }else{
      if (software %in% c("FastStructure","faststructure","FASTSTRUCTURE", "Faststructure")){
        filename <- paste(in.file,".",i,".meanQ",sep="")
        if (file.exists(filename) == FALSE){
          cat(paste("File ",filename," not found. Please check the name of your file or the software argument used! \n",sep=""))
          stop("Exit",call. = F)
        }
      }
    }
    Kraw<-read.table(filename)
    
    # Order the Q. based on the ID choise
    KordPop<-cbind(ID= key[,2], Kraw[key[,1],])
    
    ##### Ordering Populations ###
    vec<-NULL
    for (y in popord){
      if (y == popord[1]){
        vec<-which(KordPop[,1] == y)
        next
      }
      vec<-append(vec,which(KordPop[,1] == y))
    }
    KordordPop<-KordPop[vec,]
    KordordPop[,1]<-as.character(KordordPop[,1])
    
    ##### Create a space between POPs to better separate them #####
    KordordPopSpace<-as.data.frame(matrix(NA, nrow=(nrow(KordordPop)+(length(popord)-1)*3), ncol=ncol(KordordPop)), stringsAsFactors = F)
    cnt=0
    for (b in 1:nrow(KordordPop)){
      if (b==1){
        KordordPopSpace[1,]<-KordordPop[1,]
        test<-KordordPopSpace[1,1]
      }else{
        if(KordordPop[b,1] == test){
          KordordPopSpace[(b+cnt),]<-KordordPop[b,]
        }else{
          KordordPopSpace[(b+cnt),]<-c(KordordPop[(b-1),1],rep(0,(ncol(KordordPopSpace)-1)))
          cnt=cnt+1
          KordordPopSpace[(b+cnt),]<-c(KordordPop[(b-1),1],rep(0,(ncol(KordordPopSpace)-1)))
          cnt=cnt+1
          KordordPopSpace[(b+cnt),]<-c(KordordPop[(b-1),1],rep(0,(ncol(KordordPopSpace)-1)))
          cnt=cnt+1
          KordordPopSpace[(b+cnt),]<-KordordPop[b,] 
          test<-KordordPop[b,1]
        }
      }   
    }
    colnames(KordordPopSpace)<-c("POP",paste("K",seq(1:i),sep=""))
    
    
    ##### Order the Ks to mantain consistency between color and ancestry #####
    ### Previous order given 
    if (k.prev == 1 & i<=k.order.maxK){
      k.order.df <- unlist(strsplit(k.order.file[i-1], split = "\t"))
      ordercol <- as.numeric(k.order.df[-1])+1
    }
    
    ### Previous order given but i > k.order.maxK
    if (k.prev == 1 & i==(k.order.maxK+1)){
      orderpop <- k.color.df[,2]
    }
    
    ### If previous order is not done or i>k.order.maxK
    if (k.prev == 0 | i>k.order.maxK){
      ordercol<-NULL
      ### Calculate the Ks means for each pops ###
      meandf <- apply(X = KordordPop[,2:ncol(KordordPop)], MARGIN = 2, FUN = function(x){
        tapply(X = x, INDEX = KordordPop[,1], FUN = mean)
      })
      meandf <- as.data.frame(matrix(meandf,  nrow=length(popord)))
      meandf <- cbind(rownames(meandf), meandf)
      # colnames(meandf)<-c("POP",paste("K",seq(1:i),sep=""))
      if (i==2){
        ### initialization of the color order ### 
        ### for each ancestry, the population with the higher mean become the refence population for that ancestry ###
        tmp1<-meandf[which.max(meandf[,2]),1][1]
        tmp2<-meandf[which.max(meandf[,3]),1][1]
        ordercol<-c(2,3)
        orderpop<-c(tmp1,tmp2)  
      }else{
        tmpnumcol<-NULL
        tmpmeandf<-meandf
        ### The ref pop for a ancestry component is analized to retrive the correspondent column, and remove it from the df ###
        for (d in orderpop){
          tmpcolon<-names(which.max(tmpmeandf[which(tmpmeandf[,1]==d),2:ncol(tmpmeandf)]))
          ordercol<-c(ordercol,which(colnames(meandf)==tmpcolon))
          tmpnumcol<-c(tmpnumcol,tmpcolon)
          tmpmeandf<-tmpmeandf[,-(which(colnames(tmpmeandf)==tmpcolon))]
        }
        ### the new unassinged ancestry will be analyzed and the reference POP will be find ###
        tmpnum<-setdiff(colnames(meandf)[-1],tmpnumcol)
        ordercol<-c(ordercol,which(colnames(meandf)==tmpnum))
        other<-tmpmeandf[which.max(tmpmeandf[,tmpnum]),1][1]
        orderpop<-c(orderpop,other) 
      }
    }
    
    ##### Create plotting df #####
    ### the .Q file column will be ordered fallowing the ancestry order ###
    toplotraw<-cbind(KordordPopSpace[,1],KordordPopSpace[,ordercol])
    colnames(toplotraw)<-c("POP",paste("K",seq(1:i),sep=""))
    toplot<-toplotraw[,-1]
    ### for each Ks, the column oreder is sotred for future plot ###
    tmpordercol <- ordercol-1
    write.table(file=outf.plotorder,t(as.data.frame(c(paste("K",i,sep=""),tmpordercol))),row.names=F, col.names=F, quote=F, sep="\t", append=T)
    
    
    ##### Plotting the histogram #####
    ### Select the format ###
    if (plot.format == "pdf"){
      pdf(paste(out.file,"_",i,".pdf",sep=""),width=width.in,height=height.in)
    }else{
      if (plot.format == "png"){
        png(paste(out.file,"_",i,".png",sep=""),width=width.in*plot.res,height=height.in*plot.res, res=plot.res)
      }else{
        if (plot.format == "tiff" | plot.format == "tif"){
          tiff(paste(out.file,"_",i,".tif",sep=""), width=width.in*plot.res,height=height.in*plot.res, units="px", res=plot.res, compress="lzw")
        }else{
          cat("Allows plot format not found. Please check! \n")
          stop("Exit",call. = F)
        }
      }
    }
    par(cex=2.5, oma=c(3,0,0,0))
    row.names(toplot)<-NULL
    barplot(t(as.matrix(toplot)), col=Mycol[1:i], ylab=plot.ylab, border=NA,axes = FALSE,space=0,main=paste(plot.main,"\n K",i,sep=" "))
    
    ### Plotting pop name and black bar to divide pop###
    popname<-as.character(unique(KordordPopSpace[,1]))
    numpop=length(popname)
    eticall=0
    eticok=rep(NA, times=numpop)
    axis(2)
    for (a in 1:numpop){
      valor=length(which(KordordPopSpace[,1] == popname[a]))
      eticok[a]=eticall+(valor/2)
      eticall=eticall+valor
      if (a%%2 == 0){
        mtext(popname[a],at=eticok[a],side=1,line=1,las=2, cex=plot.cex)
      } else {
        mtext(popname[a],at=eticok[a],side=1,line=2.5,las=2, cex=plot.cex)
      }
      if (a!=numpop){
        abline(v=eticall-1.5, lwd=2)
      }
    }
    
    garbage <- dev.off()  
  }
  
  ### For each K, the population and color associated ###
  zz <- cbind(paste("K",seq(1:maxK), sep=""),orderpop,Mycol[1:maxK])
  colnames(zz)<-c("K","POP_assigned", "Color_assigned")
  write.table(zz,file=paste(out.file,"_colorassignement.txt",sep=""), quote=F, row.names=F, col.names=T, sep="\t")
  
}
