#Script: bite.biostat
#License: GPLv3 or later
#Modification date: 2019-07-26
#Written by: Marco Milanesi, Lorenzo Bomba
#Contact: marco.milanesi.mm@gmail.com, lory.bomb@gmail.com 
#Description: Functions to run QC and control of genetic structure using SNP data

bite.biostat <- function (
  in.file,
  out.file="tmp",
  pheno.file=NULL,
  pop.order.color.file=NULL,
  n.k=3,
  report=FALSE,
  ws.save=FALSE,
  ...
){
  
  #################################
  # Pre-requisites & Log file #
  cat("Importing and checking data before analyses starting. \n")
  options(stringsAsFactors=FALSE)
  
  RES<-paste("RESULTS_",out.file,sep="")
  dir.create(RES)
  RES <- paste(RES,"/",sep="")
  
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  tped <- paste(in.file,"tped",sep=".")
  tfam <- paste(in.file,"tfam",sep=".")
  if (file.exists(tped) & file.exists(tfam)){
    cat(paste("Input file:",in.file,"\n"))
  }else{
    sink()
    cat("Input file not found. Please check! \n")
    stop("Exit",call. = F)
  }
  cat(paste("Output file:",out.file,"\n"))
  cat(paste("Output directory:",RES,"\n"))
  sink()
  
  Refsnpsize <- 5000
  
  # PhenoFile
  if (is.null(pheno.file)){
    tmp <- read.table(tfam)
    tmpsex<-tmp[,5]
    tmpsex[tmpsex!=1] <- 0
    tmppheno <- cbind(tmp[,1:2],tmpsex,rep(-9,nrow(tmp)))
    colnames(tmppheno)<-c("pop","id","sex","pheno")
    write.table(tmppheno, file = "phenotype.txt", quote = F, row.names = F, col.names = T, sep="\t")
    rm(tmp,tmpsex,tmppheno)
    pheno.file="phenotype.txt"
  }else{
    if (!file.exists(pheno.file)){
      cat("Phenotypes file not found. Please check! \n")
      stop("Exit",call. = F)
    }
  }
  
  # Importing  
  tmplog <- capture.output({
    convert.snp.tped(tpedfile=tped,tfamfile=tfam,strand = "u", bcast = 10000, outfile="gwa.raw")
    MyData<-load.gwaa.data(phenofile = pheno.file, genofile = 'gwa.raw' , force=F)
  })
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(RES,out.file,"_ws.RData",sep=""))
  }
  
  # outfile name
  nfile=paste(RES,out.file,"_GeneralStats.txt",sep="") # file con statistiche
  nfile.ind=paste(RES,out.file,"_IndStats.txt",sep="") # file con statistiche per Ind
  nfile.snp=paste(RES,out.file,"_SNPStats.txt",sep="") # file con statistiche per Ind
  
  # Prepare file
  uniqpop<-sort(unique(MyData@phdata$pop))
  write.table(x = table(MyData@phdata$pop), file = nfile, quote = F, row.names = F, col.names = F)
  
  ##### Population order #####
  popcol <- NULL
  sink(file=paste(out.file,".log",sep=""), append = TRUE)
  if (length(pop.order.color.file) != 0){
    if (file.exists(pop.order.color.file)){
      popord<-read.table(file=pop.order.color.file, stringsAsFactors = F, comment.char = "", quote = "")
      
      if (ncol(popord) > 2){
        sink()
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }else{
        if (ncol(popord) == 2){
          popcol <- popord[,2]
          cat(paste("Population order and custom colors from ",pop.order.color.file," file.\n",sep=""))
        }else{
          cat(paste("Population order from ",pop.order.color.file," file.\n",sep=""))
        }
        popord <- popord[,1]
        if (!setequal(x = uniqpop, y = popord)){
          sink()
          cat("File with population order and colors doesn't match with the population in the dataset. Please check! \n")
          stop("Exit",call. = F)
        }
      }
      sink()
    }else{
      sink()
      cat("Population order file not found. Please check! \n")
      stop("Exit",call. = F)
    }
  }else{
    popord <- uniqpop
    cat("Population are alphebetical ordered.\n")
    sink()
  }  
  
  # Set colour
  if (length(popcol) == 0){
    Mycol1<-c("red","darkblue","#e3c92e","green3","orange","purple","hotpink3","brown","gray50","blue2","darkgoldenrod3", "coral2","cornflowerblue", "darkolivegreen","cyan2", "darkgreen", "pink", "darkorange2", "deeppink", "deepskyblue", "dodgerblue2", "firebrick3", "gold", "indianred1", "khaki3", "lightsalmon", "lightslateblue", "mediumorchid1", "mediumpurple1", "royalblue1")
    set.seed(3)
    numcol<-length(popord)
    Mycol2<-NULL
    for (i in 1:numcol){
      red<-toupper(as.hexmode(sample(16:255,1)))
      green<-toupper(as.hexmode(sample(16:255,1)))
      blue<-toupper(as.hexmode(sample(16:255,1)))
      Mycol2[i]<-paste("#",red,green,blue,sep="")
    }
    Mycol<-c(Mycol1,Mycol2)
    rm(Mycol1,Mycol2,red,green,blue,numcol,i)
  }else{
    Mycol <- popcol
  }
  
  # Set point
  Mypointraw<- c(1:20,97:101,c(35,42,64,94,121,119,122))
  Mypoint<-rep(Mypointraw,round(length(popord)/length(Mypointraw),0)+1)
  rm(Mypointraw)
  
  # Create matrix colors/points
  ordermatrix<-as.data.frame(cbind(popord,Mycol[1:length(popord)],Mypoint[1:length(popord)]))
  ordermatrix[,3]<-as.numeric(ordermatrix[,3])
  MyData@phdata$popcol<-rep(NA,length(MyData@phdata$pop))
  MyData@phdata$poppoint<-rep(NA,length(MyData@phdata$pop))
  for (i in ordermatrix[,1]){
    MyData@phdata$popcol[which(MyData@phdata$pop==i)]<-ordermatrix[which(ordermatrix[,1]==i),2]
    MyData@phdata$poppoint[which(MyData@phdata$pop==i)]<-as.numeric(ordermatrix[which(ordermatrix[,1]==i),3])
  }
  
  # Breed code
  pdf(paste(RES,out.file,"_PopCode.pdf",sep=""))
  tmp <- ceiling(sqrt(length(popord)))
  plot(0,0,type="n",xlim=c(0,tmp*7), ylim=c(0,tmp*7),yaxt="n", xaxt="n", frame.plot=F, xlab="", ylab="")
  legend(0,tmp*7,ordermatrix[,1], ncol=floor(tmp/2), col=ordermatrix[,2], lty=0,pch=as.numeric(ordermatrix[,3]), cex=0.75)
  garbage <- dev.off()
  rm(tmp)
  
  
  ###########
  ### SNP ###
  cat("SNPs stats: running ...\n")
  SNP<-paste(RES,"SNP",sep="")
  dir.create(SNP)
  
  sink(file=nfile, append = T)
  
  DescMark<-descriptives.marker(MyData)
  sumMyData<-summary(gtdata(MyData))
  write.table(sumMyData,file=nfile.snp,quote=F, row.names = T)
  
  cat("\n\n ***** General stats ***** \n")
  print(DescMark)
  
  cat("\n\n ***** Per Marker stats ***** \n")
  #Call Rate
  cat("# Call rate\n")
  cat("Summary\n")
  crate<- sumMyData[,"CallRate"]
  print(summary(crate))
  cat("\n")
  cat("Distribution\n")
  print(catable(crate,c(seq(0.75,1,0.05)), cumulative = F))
  cat("\n")
  cat("Cumulative Distribution\n")
  print(catable(crate,c(seq(0.75,1,0.05)), cumulative = T))
  
  #Maf
  cat("\n\n# MAF\n")
  afr<-sumMyData[,"Q.2"]
  maf <- pmin(afr,(1.-afr))
  cat("Summary\n")
  print(summary(maf))
  cat("\n")
  cat("Cumulative Distribution\n")
  print(catable(maf,c(seq(0,0.1,0.01)),cumulative = T))
  
  #Hwe
  cat("\n\n# H-W eq\n")
  hwp <- sumMyData[,"Pexact"]
  cat("Summary\n")
  print(summary(hwp))
  cat("\n")
  cat("Distribution\n")
  print(catable(hwp,c(0.05/nsnps(MyData),1/100000,1/10000,.01,0.05)))
  cat("\n")
  cat("Cumulative Distribution\n")
  print(catable(hwp,c(0.05/nsnps(MyData),1/100000,1/10000,.01,0.05),cumulative = T))
  cat("\n\n\n")
  sink()
  
  ## Plotting ##
  colors<-densCols(crate,maf)
  pdf(paste(RES,"SNP/",out.file,"_SNP_Stats.pdf",sep=""))
  par(mfcol=c(2,2))
  hist(crate,col="red")
  hist(maf,col="red")
  hist(hwp,col="red")
  plot(crate,maf,col=colors,pch=20,xlab="crate",ylab="maf",main="Plot of crateVSmaf")
  abline(v=c(.90,.95,.99),h=c(0.01,0.05,0.1),col="black",lty=2)
  garbage <- dev.off()
  
  # PLot MAF
  pdf(paste(RES,"SNP/",out.file,"_SNP_MAF.pdf",sep=""))
  hist(maf,col="red", main="MAF", breaks=50, xlim=c(0,0.50))
  garbage <- dev.off()
  
  pdf(paste(RES,"SNP/",out.file,"_SNP_MAF_density.pdf",sep=""))
  plot(density(maf), main="MAF density", lwd=2)
  garbage <- dev.off()
  
  pdf(paste(RES,"SNP/",out.file,"_SNP_MAF_zoom.pdf",sep=""))
  hist(maf[which(maf<=0.1)],col="red", main="MAF", breaks=100, xlim=c(0,0.1))
  rug(maf[which(maf<=0.1)], lwd = 0.1, col = "#00000075")
  garbage <- dev.off()
  
  # PLot SNPcall
  spazi <- ceiling((max(crate)-min(crate))/0.01)
  if (spazi < 10){
    spazi <- 10
  }
  pdf(paste(RES,"SNP/",out.file,"_SNP_CR.pdf",sep=""))
  hist(crate,col="red", main="SNP call rate", breaks=spazi, xlab="Call Rate")
  #rug(crate, lwd = 0.1, col = "#00000075")
  abline(v=c(.90,.95,.99),col="#000000",lty=2, lwd=2)
  garbage <- dev.off()
  
  spazi <- ceiling((max(crate)-min(crate))/0.005)
  if (spazi < 10){
    spazi <- 10
  }
  pdf(paste(RES,"SNP/",out.file,"_SNP_CR_zoom.pdf",sep=""))
  hist(crate,col="red", main="SNP call rate", breaks=spazi, xlim=c(0.9,1), xlab="Call Rate")
  rug(crate, lwd = 0.1, col = "#00000075")
  abline(v=c(.90,.95,.99),col="#00000095",lty=2)
  garbage <- dev.off()
  
  # PLot CR vs MAF
  pdf(paste(RES,"SNP/",out.file,"_SNP_MAF_vs_CR.pdf",sep=""))
  plot(crate,maf,col=colors,pch=20,xlab="Call Rate",ylab="MAF",main="Plot of Call Rate VS MAF")
  abline(v=c(.90,.95,.99),h=c(0.01,0.05,0.1),col="black",lty=2, lwd=2)
  garbage <- dev.off()
  
  
  ###########
  ### IDs ###
  cat("IDs stats: running ...\n")
  IND<-paste(RES,"IND",sep="")
  dir.create(IND)
  
  sink(file=nfile, append=T)
  cat("\n ***** Per ID stats ***** \n")
  
  sumMyDataind<-perid.summary(gtdata(MyData))
  sumMyDataind$ID <- rownames(sumMyDataind)
  sumMyDataind$FID <- MyData@phdata$pop
  sumMyDataind <- sumMyDataind[order(match(sumMyDataind$FID, table = popord)),]
  write.table(sumMyDataind[,c(10,9,1:8)],file=nfile.ind,quote=F, row.names = F)
  tmpphdata <- MyData@phdata
  tmpphdata <- tmpphdata[order(match(tmpphdata$pop, table = popord)),]
  
  # ID call
  idcall<-sumMyDataind$Call
  cat("# ID call\n")
  cat("Summary\n")
  print(summary(idcall))
  cat("\n")
  cat("Distribution\n")
  print(catable(idcall,c(seq(0.75,1,0.05)), cumulative = F))
  cat("\n")
  cat("Cumulative Distribution\n")
  print(catable(idcall,c(seq(0.75,1,0.05)), cumulative = T))
  
  # Het
  het <- sumMyDataind$Het
  cat("\n\n# ID heterozygosity \n")
  cat("Distribution\n")
  print(summary(het))
  cat("\n")
  cat("Distribution\n")
  print(catable(het,c(seq(0,1,0.05))))
  cat("\n\n")
  sink()
  
  ## Plot ##
  posbreed <- as.data.frame(cbind(popord, rep(NA, length(popord))), stringsAsFactors = F)
  for (i in posbreed[,1]){
    t <- which(sumMyDataind$FID == i)
    posbreed[which(posbreed[,1] == i),2] <- ceiling((max(t) + min(t))/2)
  }
  
  pdf(paste(RES,"IND/",out.file,"_IND_Stats.pdf",sep=""))
  par(mfcol=c(2,2))
  hist(idcall,col="red")
  hist(het,col="red")
  barplot(1-idcall,names.arg=NULL,border=NA, las=2, cex.names=0.4, 
          col=tmpphdata$popcol, main= "Barplot of Individual Call Rate", ylab="Call Rate")
  abline(h=c(.1,.05,.01),col="#00000095",lty=2)
  barplot(het,names.arg=NULL,border=NA, ylim=c(0,round(max(het, na.rm=T)+0.06,1)), las=2, cex.names=0.4, 
          col=tmpphdata$popcol, main= "Barplot of Observed Heterozygosity", ylab="Obs.Het")
  garbage <- dev.off()
  
  pdf(paste(RES,"IND/",out.file,"_IND_CR_vs_HET.pdf",sep=""))
  plot(0,0,xlim=c(min(idcall)-0.05,1),
       ylim= c(min(het, na.rm=T)-0.05,max(het, na.rm=T)+0.05),
       pch=1,xlab="ID Call Rate",ylab="Observed Heterozygosity",main="CR vs Obs.Het", type="n")
  abline(h=c(mean(het, na.rm=T)+(3*sd(het, na.rm=T)),mean(het, na.rm=T)-(3*sd(het, na.rm=T))),col="red",lty=2)
  abline(v=c(.90,.95,.99),col="black",lty=2)
  tmphet <- het; tmphet[is.na(tmphet)] <- 0
  points(idcall,tmphet,col=tmpphdata$popcol,pch=as.numeric(tmpphdata$poppoint), cex=0.8)
  garbage <- dev.off()
  
  # Plot CR ID
  spazi <- ceiling((max(idcall)-min(idcall))/0.005)
  if (spazi < 10){spazi <- 10}
  if (spazi > 100){spazi <- 100}
  pdf(paste(RES,"IND/",out.file,"_IND_CR_hist.pdf",sep=""))
  hist(idcall,col="red", main="Individual Call Rate", breaks=spazi, xlab="Call Rate")
  abline(v=c(.90,.95,.99),col="#000000",lty=2, lwd=2)
  garbage <- dev.off()
  
  pdf(paste(RES,"IND/",out.file,"_IND_CR_hist_zoom.pdf",sep=""))
  hist(idcall,col="red", main="Individual Call Rate", breaks=spazi, xlim=c(0.9,1), xlab="Call Rate")
  rug(idcall, lwd = 0.1, col = "#00000075")
  abline(v=c(.90,.95,.99),col="#00000095",lty=2)
  garbage <- dev.off()
  
  pdf(paste(RES,"IND/",out.file,"_IND_CR.pdf",sep=""))
  barplot(1-idcall,names.arg=NULL,border=NA, las=2, cex.names=0.4, ylim=c(0,max(1-idcall)+0.05),
          col=tmpphdata$popcol, main= "Barplot of Individual Call Rate", ylab="Call Rate")
  abline(h=c(.1,.05,.01),col="#00000095",lty=2)
  p <- barplot(1-idcall, plot = F)
  mtext(text = posbreed[,1], side = 1, 
        line = rep(c(1,2.5),nrow(posbreed))[1:nrow(posbreed)], 
        at=p[as.numeric(posbreed[,2])], las=2, cex=0.4)
  garbage <- dev.off()
  
  pdf(paste(RES,"IND/",out.file,"_IND_HET.pdf",sep=""))
  barplot(het,names.arg=NULL,border=NA, ylim=c(0,round(max(het, na.rm=T)+0.06,1)), 
          las=2, cex.names=0.4, col=tmpphdata$popcol, 
          main= "Barplot of Observed Heterozygosity", ylab="Obs.Het")
  p <- barplot(het, plot = F)
  mtext(text = posbreed[,1], side = 1, 
        line = rep(c(1,2.5),nrow(posbreed))[1:nrow(posbreed)],
        at =  p[as.numeric(posbreed[,2])], las=2, cex=0.4)
  garbage <- dev.off()
  
  sumMyDataind$FID <- factor(sumMyDataind$FID, ordermatrix[,1])
  pdf(paste(RES,"IND/",out.file,"_IND_HET_boxplot.pdf",sep=""))
  boxplot(tmphet~sumMyDataind$FID, las=2, cex.axis=0.4, cex=0.7, col=ordermatrix[,2], 
          main= "Boxplot of Observed Heterozygosity", ylab="Obs.Het")
  garbage <- dev.off()
  pdf(paste(RES,"IND/",out.file,"_IND_HET_beanplot.pdf",sep=""))
  beanplot(tmphet~sumMyDataind$FID, 
           bw = "nrd0", col = as.list(ordermatrix[,2]), 
           cutmin = 0, cutmax = 1, 
           las=2, cex.axis=0.5, 
           what=c(0,1,1,0), 
           beanlines = "mean",
           ylab="Obs.Het", main= "Beanplot of Observed Heterozygosity")
  garbage <- dev.off()
  
  
  ###########
  ### MDS ###
  ###########
  if (ws.save == TRUE){
    save(list = objects(), file = paste(RES,out.file,"_ws.RData",sep=""))
  }
  
  cat("Analyses based on IBS/IBD matrix: running ...\n")
  cat("   ... this can take several minutes ... please wait\n")
  MDS<-paste(RES,"MDS",sep="")
  dir.create(MDS)
  
  # Test IBS
  if (length(autosomal(MyData))<=Refsnpsize){
    snpsize<-length(autosomal(MyData))
  }else{
    snpsize<-Refsnpsize
  }
  set.seed(1986)
  MyData.IBS <- ibs(MyData[,sample(autosomal(MyData), size = snpsize, replace = F)], weight="no")
  MyData.IBSdist <- as.dist(MyData.IBS)
  
  sink(file=nfile, append=T)
  cat("\n\n ***** IBS evaluation ***** \n")
  cat("Summary\n")
  print(summary(MyData.IBSdist))
  cat("\n")
  cat("Distribution\n")
  print(catable(as.vector(MyData.IBSdist),c(seq(0.90,1,0.01)), cumulative = F))
  cat("\n")
  cat("Cumulative Distribution\n")
  print(catable(as.vector(MyData.IBSdist),c(seq(0.90,1,0.01)), cumulative = T))
  cat("\n\n")
  sink()
  
  spazi <- ceiling((max(MyData.IBSdist)-min(MyData.IBSdist))/0.01)
  if (spazi < 10){
    spazi <- 10
  }
  pdf(paste(RES,"MDS/",out.file,"_IBS_hist.pdf",sep=""))
  hist(MyData.IBSdist, main=paste("Pairwise IBS\nevaluated using ",snpsize," SNPs",sep=""), breaks=spazi, xlab="IBS")
  rug(MyData.IBSdist[MyData.IBSdist>=0.9], lwd = 0.1, col = "#00000075")
  abline(v=c(.90,.95,.99),col="#000000",lty=2, lwd=2)
  garbage <- dev.off()
  
  # Kinship to plot
  MyData.gkin <- ibs(MyData[,autosomal(MyData)],weight="freq")
  MyData.dist <- as.dist(0.5-MyData.gkin)
  MyData.mds.15 <- cmdscale(MyData.dist,k=n.k ,eig = TRUE)
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(RES,out.file,"_ws.RData",sep=""))
  }
  cat("   ... plotting step is running ... \n")
  
  # cat(" ... plotting tree ... \n\n")
  # tree <- nj(MyData.dist)
  # pdf(paste(RES,"MDS/",out.file,"_tree_Cladogram.pdf",sep=""))
  # plot(tree, type = "cladogram", pch = "", no.margin = TRUE,
  #      show.tip.label = F,
  #      edge.col="grey", edge.width = 0.8 )
  # tiplabels(col=adjustcolor(MyData@phdata$popcol,0.75),
  #           pch=as.numeric(MyData@phdata$poppoint), 
  #           cex=0.7)
  # garbage <- dev.off()
  # pdf(paste(RES,"MDS/",out.file,"_tree_Unrooted.pdf",sep=""))
  # plot(tree, "u", direction="l", srt=0, cex = 1, lab4ut = "axial", no.margin = TRUE,
  #      show.tip.label = F,
  #      edge.col="grey", edge.width = 0.8 )
  # tiplabels(col=adjustcolor(MyData@phdata$popcol,0.75),
  #           pch=as.numeric(MyData@phdata$poppoint), 
  #           cex=0.7)
  # garbage <- dev.off()
  # pdf(paste(RES,"MDS/",out.file,"_tree_Phylogram.pdf",sep=""))
  # plot(tree, no.margin = TRUE,
  #      show.tip.label = F,
  #      edge.col="grey", edge.width = 0.8 )
  # tiplabels(col=adjustcolor(MyData@phdata$popcol,0.75),
  #           pch=as.numeric(MyData@phdata$poppoint), 
  #           cex=0.7)
  # garbage <- dev.off()
  
  t <- as.data.frame(cbind(MyData@phdata$pop,rownames(MyData.mds.15$points),MyData.mds.15$points))
  colnames(t) <- c("POP","ID",paste("PC",seq(1:n.k),sep=""))
  t <- t[order(match(t$POP, table = popord)),]
  write.table(t,file=paste(RES,"MDS/",out.file,"_MDS_table_points.txt",sep=""),quote=F, row.names = F, col.names = TRUE)
  
  # Eig
  tempeig<-MyData.mds.15$eig
  tempeig[which(tempeig<=0)]<-0
  tottempeig<-sum(tempeig)
  perctempeig<-(tempeig/tottempeig)*100
  csperctempeig<-cumsum(perctempeig)
  tmp <- data.frame(MyData.mds.15$eig,perctempeig,csperctempeig,stringsAsFactors = F)
  colnames(tmp) <- c("EIG","perc_EIG","CumSum_EIG")
  write.table(tmp,file=paste(RES,"MDS/",out.file,"_MDS_table_eig.txt",sep=""),quote=F, col.names=T, row.names = T)
  
  if (length(tempeig)>20){
    pdf(paste(RES,"MDS/",out.file,"_MDS_eig_barplot_zoom.pdf",sep=""))
    barplot(perctempeig[1:20], col="red")
    garbage <- dev.off()
  }
  pdf(paste(RES,"MDS/",out.file,"_MDS_eig_barplot.pdf",sep=""))
  barplot(perctempeig, col="red")
  garbage <- dev.off()
  
  pdf(paste(RES,"MDS/",out.file,"_MDS_eig_cumsum.pdf",sep=""))
  plot(csperctempeig, type="l", col="blue", lwd=2)
  garbage <- dev.off()
  
  MyData.mds <- as.data.frame(MyData.mds.15$points)
  MyData.mds$BRD<-MyData@phdata$pop
  MyData.mds <- MyData.mds[order(match(MyData.mds$BRD, table = popord)),]
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(RES,out.file,"_ws.RData",sep=""))
  }
  
  ### Plotting 
  comb<-combn(n.k,2)
  for (i in 1:dim(comb)[2]){
    # cat(paste("     PC ",comb[1,i]," VS PC ",comb[2,i]," \n",sep=""))
    
    # Plot: IDs
    pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],".pdf",sep=""))
    plot(0,0,xlim=range(MyData.mds.15$points[,comb[1,i]]),ylim=range(MyData.mds.15$points[,comb[2,i]]),
         xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
         ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
         pch="",main="MultiDimensional Scaling")
    points(MyData.mds.15$points[,comb[1,i]],
           MyData.mds.15$points[,comb[2,i]],
           col=MyData@phdata$popcol,pch=as.numeric(MyData@phdata$poppoint),cex=0.5)
    abline(v=0, h=0, col="grey", lwd=0.5)
    garbage <- dev.off()
    
    
    # pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_breed_pch.pdf",sep=""))
    # plot(0,0,xlim=range(MyData.mds[,comb[1,i]]),ylim=range(MyData.mds[,comb[2,i]]),
    #      xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
    #      ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
    #      pch="",main="MultiDimensional Scaling")
    # abline(v=0, h=0, col="grey", lwd=0.5)
    # for (a in 1:length(popord)){
    #   points(mean(subset(MyData.mds,MyData.mds$BRD==popord[a])[,comb[1,i]]),
    #          mean(subset(MyData.mds,MyData.mds$BRD==popord[a])[,comb[2,i]]),
    #          col=MyData@phdata$popcol[which(MyData@phdata$pop==popord[a])],
    #          pch=as.numeric(MyData@phdata$poppoint[which(MyData@phdata$pop==popord[a])]), cex=0.7)
    # }
    # garbage <- dev.off()
    
    # Plot: breed - name
    pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_pop.pdf",sep=""))
    plot(0,0,xlim=range(MyData.mds[,comb[1,i]]),ylim=range(MyData.mds[,comb[2,i]]),
         xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
         ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
         pch="",main="MultiDimensional Scaling")
    abline(v=0, h=0, col="grey", lwd=0.5)
    for (a in 1:length(popord)){
      text(mean(subset(MyData.mds,MyData.mds$BRD==popord[a])[,comb[1,i]]),
           mean(subset(MyData.mds,MyData.mds$BRD==popord[a])[,comb[2,i]]),
           col=MyData@phdata$popcol[which(MyData@phdata$pop==popord[a])],
           labels=popord[a], cex=0.7)
    }
    garbage <- dev.off()
    
    # Elipse plot
    # Test if dataset works
    possibleError <- tryCatch({
      plot.new()
      dataEllipse(x = MyData.mds[,comb[1,i]], y = MyData.mds[,comb[2,i]],
                  groups = factor(MyData.mds[,"BRD"], ordermatrix[,1]), 
                  plot.points = F,col=ordermatrix[,2], levels=0.95)
      dev.off()},
      error=function(e) e)
    
    if(!inherits(possibleError, "error")){
      pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_popCI.pdf",sep=""))
      plot(0,0,xlim=range(MyData.mds[,comb[1,i]])*1.1,ylim=range(MyData.mds[,comb[2,i]])*1.1,
           xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
           ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
           pch="",main="MultiDimensional Scaling")
      abline(v=0, h=0, col="grey", lwd=0.5)
      dataEllipse(x = MyData.mds[,comb[1,i]], y = MyData.mds[,comb[2,i]], groups = factor(MyData.mds[,"BRD"], ordermatrix[,1]), 
                  plot.points = F, cex=0.5, 
                  col=ordermatrix[,2], 
                  lwd=1, levels=0.95, center.pch=20, center.cex=0.8) # ellipse.label
      garbage <- dev.off()
      
      # pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_breed_ellipse_id.pdf",sep=""))
      # plot(0,0,xlim=range(MyData.mds[,comb[1,i]])*1.1,ylim=range(MyData.mds[,comb[2,i]])*1.1,
      #      xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
      #      ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
      #      pch="",main="MultiDimensional Scaling")
      # abline(v=0, h=0, col="grey", lwd=0.5)
      # dataEllipse(x = MyData.mds[,comb[1,i]], y = MyData.mds[,comb[2,i]], groups = as.factor(MyData.mds[,"BRD"]), 
      #             plot.points = T, pch= as.numeric(ordermatrix[,3]), cex=0.3,
      #             col=adjustcolor(ordermatrix[,2], 0.5),  
      #             lwd=1, levels=0.95, center.pch=20, center.cex=0.9, grid = FALSE, add=TRUE)
      # garbage <- dev.off()
      
    }else{
      # If dataset complete doesn't work remove breed with low number of animals 
      tableMds<-table(MyData.mds[,"BRD"])
      for (minnum in c(2:50)){
        tormv <- as.vector(names(tableMds)[which(tableMds<=minnum)])
        tmp.MyData.mds <- MyData.mds[-(which(MyData.mds[,"BRD"] %in% tormv)),]
        tmp.ordermatrix <-  ordermatrix[-(which(ordermatrix[,1] %in% tormv)),]
        
        possibleError <- tryCatch({
          plot.new()
          dataEllipse(x = tmp.MyData.mds[,comb[1,i]], y = tmp.MyData.mds[,comb[2,i]], 
                      groups = factor(tmp.MyData.mds[,"BRD"], tmp.ordermatrix[,1]), plot.points = F, 
                      col=tmp.ordermatrix[,2], levels=0.95)
          dev.off()},
          error=function(e) e)
        
        if(!inherits(possibleError, "error")){
          pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_popCI_sub",minnum,".pdf",sep=""))
          plot(0,0,xlim=range(tmp.MyData.mds[,comb[1,i]])*1.1,ylim=range(tmp.MyData.mds[,comb[2,i]])*1.1,
               xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
               ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
               pch="",main="MultiDimensional Scaling")
          abline(v=0, h=0, col="grey", lwd=0.5)
          dataEllipse(x = tmp.MyData.mds[,comb[1,i]], y = tmp.MyData.mds[,comb[2,i]], groups = factor(tmp.MyData.mds[,"BRD"], tmp.ordermatrix[,1]), 
                      plot.points = F, cex=0.5, 
                      col=tmp.ordermatrix[,2], 
                      lwd=1, levels=0.95, center.pch=20, center.cex=0.8) # ellipse.label
          garbage <- dev.off()
          
          # pdf(paste(RES,"MDS/",out.file,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_breed_ellipse_id_RID",minnum,".pdf",sep=""))
          # plot(0,0,xlim=range(tmp.MyData.mds[,comb[1,i]])*1.1,ylim=range(tmp.MyData.mds[,comb[2,i]])*1.1,
          #      xlab=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
          #      ylab=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
          #      pch="",main="MultiDimensional Scaling")
          # abline(v=0, h=0, col="grey", lwd=0.5)
          # dataEllipse(x = tmp.MyData.mds[,comb[1,i]], y = tmp.MyData.mds[,comb[1,i]], groups = as.factor(tmp.MyData.mds[,"BRD"]), 
          #             plot.points = T, pch= as.numeric(tmp.ordermatrix[,3]), cex=0.3,
          #             col=tmp.ordermatrix[,2],  
          #             lwd=1, levels=0.95, center.pch=20, center.cex=0.9, grid = FALSE, add=TRUE)
          # garbage <- dev.off()
          break
          
        }else{
          if (minnum == 50){
            # sink(file=nfile, append=T)
            cat("\n!!!!! It's not possible create an MDS with ellipse with this PCs combination. !!!!! \n")
            cat(possibleError,"\n")
            # sink()
          }
        }
      }
    }
  }
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(RES,out.file,"_ws.RData",sep=""))
  }
  
  if (report==TRUE){
    cat("Report is creating ... \n")
    render(input = system.file("markdown","bite_biostat.Rmd", package = "BITE"), 
           output_file = paste(out.file,".html", sep=""), 
           output_dir = "./", 
           quiet = TRUE, 
           params = list(
             in.file = in.file, 
             MyData = MyData, 
             ordermatrix = ordermatrix, 
             DescMark = DescMark, 
             sumMyData = sumMyData, 
             sumMyDataind = sumMyDataind,
             MyData.IBSdist=MyData.IBSdist,
             MyData.mds.15 = MyData.mds.15, 
             MyData.mds = MyData.mds))
  }
}
