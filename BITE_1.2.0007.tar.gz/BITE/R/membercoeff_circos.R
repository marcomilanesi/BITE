#Script: membercoeff.circos
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Marco Milanesi
#Contact: marco.milanesi.mm@gmail.com
#Description: Plotting ancestral assignment results in a Circos style 

##### MAIN FUNCTION #####
membercoeff.circos <- function(
  in.file,
  out.file="tmp",
  pop.order.file=NULL,
  id.order.file=NULL,
  k.order.file=NULL,
  k.color.file=NULL,
  software="Admixture",
  maxK=2,
  K.to.plot=NULL,
  halfmoon=FALSE,
  plot.color=NULL,
  plot.main="ADMIXTURE analyses",
  plot.cex=1,
  plot.format="pdf",
  plot.width=60,
  plot.height=60,
  plot.res=100,
  ...
){
  
  # Parameters
  k.order <- k.order.file
  k.color <- k.color.file
  rm(k.order.file);rm(k.color.file)
  
  ##### Log file #####
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  cat(paste("Input file:",in.file,"\n"))
  cat(paste("Output file:",out.file,"\n"))
  if (software %in% c("Admixture","ADMIXTURE","admixture","FastStructure","faststructure","FASTSTRUCTURE", "Faststructure", "sNMF")){
    cat(paste("Software used:",software,"\n"))
  }else{
    sink()
    cat("Allows software (Admixture, FastStructure and sNMF) not found. Please check! \n")
    stop("Exit",call. = F)
  }
  cat(paste("Max K analysed:",maxK,"\n"))
  sink()
  
  ### K to plot ###
  if (is.null(K.to.plot)){
    cat("K.to.plot vector is empty! Please check! \n")
    stop("Exit",call. = F)
  }else{
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Plotted K:",(paste(K.to.plot,collapse=" ")),"\n"))
    cat(paste("Do you plot half circle graph?",halfmoon,"\n"))
  }
  
  ### Figure infos ###
  if (plot.format %in% c("pdf","png","tiff","tif")){
    cat(paste("Format of output file:",plot.format,"\n\n"))
    sink()
  }else{
    sink()
    cat("Allows plot format not found. Please check! \n")
    stop("Exit",call. = F)
  }
  
  # Previous ordering
  k.prev <- 0
  k.order.maxK <- 0
  if (!is.null(k.order) & !is.null(k.color)){
    if (file.exists(k.order)){
      sink(file=paste(out.file,".log",sep=""), append = T)
      if (file.exists(k.color)){
        k.order.file <- readLines(k.order)
        k.color.file <- readLines(k.color)
        k.order.maxK <- length(k.order.file)+1
        k.color.df <- as.data.frame(matrix(unlist(strsplit(k.color.file, split = "\t")), ncol=3, byrow = T), stringsAsFactors = F)
        colnames(k.color.df) <- k.color.df[1,]
        k.color.df <- k.color.df[-1,]
        if (maxK > k.order.maxK){
          cat("The number of Ks in the k.order argument file is less than maxK argument value. A new 'columnorder' file will be created to include the new Ks. \n")
          if (k.order == paste(out.file,"_columnorder.txt",sep="")){
            sink()
            cat("The name of the new 'columnorder' file will be the same given in the k.order argument. File replacement is not allow. Please check! \n")
            stop("Exit",call. = F)
          }
        }
        cat(paste("Column order for each Ks will be retrived from ",k.order," file and colors from ",k.color," file [only if plot.color option is not used]. \n\n"))
        sink()
        k.prev <- 1
      }else{
        sink()
        cat("File with POP order was not found! Please fill the k.color argument. \n")
        stop("Exit",call. = F)
      }
    }else{
      cat("File with POP order was not found! Please fill the k.order argument. \n")
      stop("Exit",call. = F)
    }
  }

  
  ##### Population order #####
  if (!is.null(pop.order.file)){
    sink(file=paste(out.file,".log",sep=""), append = T)
    cat(paste("Population order from ",pop.order.file," file.\n",sep=""))
    sink()
    if (!file.exists(pop.order.file)){
      cat("Populations order file not found. Please check! \n")
      stop("Exit",call. = F)
    }else{
      popord<-read.table(file=pop.order.file, stringsAsFactors = F, h=F, na.strings = "")
      if (ncol(popord) != 1){
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      popord <- popord[,1]
      tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F, na.strings = "")
      tmppop <- sort(unique(tmpfam[,1]))
      if (length(unique(popord)) != length(tmppop)){
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      rm(tmpfam,tmppop)
    }    
  }else{
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Populations order automatically retrive from ",in.file,".fam. Population will be alphabetically sorted by name.\n",sep=""))
    sink()
    tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F) 
    popord<-sort(unique(tmpfam[,1]))
  }
  sink(file=paste(out.file,".log",sep=""), append = TRUE)
  cat("Population order: \n",(paste(popord,collapse=" ")),"\n\n")
  sink()
  
  ##### Individual order #####
  if (file.exists(paste(in.file,"fam",sep=".")) == FALSE){
    cat(".fam file wasn't found. Please check! \n")
    stop("Exit",call. = F)
  }
  if (!is.null(id.order.file)){
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Individuals order from ",id.order.file," file. \n\n",sep=""))
    sink()
    if (!file.exists(id.order.file)){
      cat("Individual order file not found. Please check! \n")
      stop("Exit",call. = F)
    }else{
      key<-read.table(id.order.file)
      if (ncol(key) != 3){
        cat("The format of individual order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F)
      if (nrow(key) != nrow(tmpfam)){
        cat("The format of individual order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }
      rm(tmpfam)
    }    
  }else{
    sink(file=paste(out.file,".log",sep=""), append = TRUE)
    cat(paste("Individuals order automatically retrive from ",in.file,".fam.\n\n",sep=""))
    sink()
    tmpfam <- read.table(file=paste(in.file,"fam",sep="."), stringsAsFactors = F, h=F) 
    key<-cbind(seq(1,nrow(tmpfam)),tmpfam[,1:2])
  }
  
  ##### Output file #####
  outf.plotorder<-paste(out.file,"_columnorder.txt",sep="")
  if (file.exists(outf.plotorder)){
    file.remove(outf.plotorder)
  }
  
  ###### Circos parameters ###### 
  if (halfmoon==TRUE){
    plusanim<-ceiling(nrow(key)*0.03)
    Baseperunit<-round(1000000/((nrow(key)+length(popord)+plusanim+1)*2),0)
  }else{
    plusanim<-ceiling(nrow(key)*0.015)
    Baseperunit<-round(1000000/(nrow(key)+length(popord)+plusanim+1),0)
  }
  
  ### Graphs
  width.in<-plot.width/2.54
  height.in<-plot.height/2.54
  
  ##### Colors #####
  if (is.null(plot.color)){
    Mycol1<-c("red","darkblue","#e3c92e","green3","orange","purple","hotpink3","brown","gray50","blue2","darkgoldenrod3", "coral2","cornflowerblue", "darkolivegreen","cyan2", "darkgreen", "pink", "darkorange2", "deeppink", "deepskyblue", "dodgerblue2", "firebrick3", "gold", "indianred1", "khaki3", "lightsalmon", "lightslateblue", "mediumorchid1", "mediumpurple1", "royalblue1")
    set.seed(3)
    numcol<-maxK
    Mycol2<-NULL
    for (i in 1:numcol){
      red<-toupper(as.hexmode(sample(16:255,1)))
      green<-toupper(as.hexmode(sample(16:255,1)))
      blue<-toupper(as.hexmode(sample(16:255,1)))
      Mycol2[i]<-paste("#",red,green,blue,sep="")
    }
    Mycol<-c(Mycol1,Mycol2)
    rm(Mycol1);rm(Mycol2)
  }else{
    Mycol <- plot.color
    if (length(Mycol) < maxK){
      cat("The color vector contain less color than K to plot. Please check! \n")
      stop("Exit",call. = F)
    }
  }
  # if k.color file is used
  if (k.prev == 1 & is.null(plot.color)){
    Mycol <- c(k.color.df[,3],Mycol[-(which(Mycol %in% k.color.df[,3]))])
  }
  sink(file=paste(out.file,".log",sep=""), append = TRUE)
  if (is.null(plot.color)){
    cat("The function will create automatically a palette of distinct colors. \n\n")
  }else{
    cat("Ancestry color from custom vector: \n",(paste(Mycol,collapse=" ")),"\n\n")
  }
  #  cat("\n***** *** *****\n")
  sink()
  
  
  ##### Create populations dataframe in the format required by RCircos package#####
  ### Populations ordering ###
  dfpoporder<-NULL
  for (y in popord){
    if (y == popord[1]){
      dfpoporder<-which(key[,2] == y)
      next
    }
    dfpoporder<-append(dfpoporder,which(key[,2] == y))
  }
  tmpdfpop<-key[dfpoporder,2:3]
  tmpdfpop[,1]<-factor(tmpdfpop[,1], levels = popord)
  ### create the df with the IDs position in the plot ###
  dfpop<-as.data.frame(matrix(NA,ncol=5,nrow=nrow(tmpdfpop)))
  colnames(dfpop)<-c("Chromosome","ChromStart","ChromEnd","Band","Stain")
  dfpop$Chromosome<-paste("chr",seq(2,(length(popord)+1)),sep="")[unclass(tmpdfpop[ ,1])]
  dfpopRosetta<-unique(cbind(as.character(tmpdfpop[,1]),paste("chr",(seq(1,length(popord))+1),sep="")[unclass(tmpdfpop[ ,1])]))
  dfpop$Band<-tmpdfpop[,2]
  dfpop$Stain<-Mycol[1:length(popord)][unclass(tmpdfpop[ ,1])]
  ### bar dimension based on the numebr of animals ###
  for (a in unique(dfpop$Chromosome)){
    tmpchr<-which(dfpop$Chromosome==a)
    dfpop[tmpchr,"ChromStart"]<-seq(0,(Baseperunit*(length(tmpchr)-1)),Baseperunit)
    dfpop[tmpchr,"ChromEnd"]<-seq(Baseperunit,(Baseperunit*(length(tmpchr))),Baseperunit)
  }
  rm(tmpdfpop)
  
  ##### Adding a fake population to write K value #####
  tmpchrStart<-as.data.frame(matrix(NA,ncol=5,nrow=plusanim))
  colnames(tmpchrStart)<-c("Chromosome","ChromStart","ChromEnd","Band","Stain")
  tmpchrStart$Chromosome<-"chr1"
  tmpchrStart$Band<-"FAKE"
  tmpchrStart$Stain<-"gray"
  tmpchrStart$ChromStart<-seq(0,(Baseperunit*(nrow(tmpchrStart)-1)),Baseperunit)
  tmpchrStart$ChromEnd<-seq(Baseperunit,(Baseperunit*(nrow(tmpchrStart))),Baseperunit)
  tmpdfpop<-dfpop
  dfpop<-rbind(tmpchrStart,tmpdfpop)
  rm(tmpdfpop);rm(tmpchrStart)
  
  ##### Insert 1 fake animal for each populations to create space between pops #####
  dfpopraw<-dfpop
  rm(dfpop)
  dfpop<-as.data.frame(matrix(NA,nrow=nrow(dfpopraw)+length(unique(dfpopraw[,1])), ncol=ncol(dfpopraw)))
  colnames(dfpop)<-colnames(dfpopraw)
  cnt=0
  for (b in 1:nrow(dfpopraw)){
    if (b==1){
      dfpop[1,]<-dfpopraw[1,]
      test<-dfpop[1,1]
    }else{
      if(dfpopraw[b,1] == test){
        dfpop[(b+cnt),]<-dfpopraw[b,]
      }else{
        dfpop[(b+cnt),]<-c(dfpopraw[(b-1),1],dfpopraw[(b-1),2]+Baseperunit,dfpopraw[(b-1),3]+Baseperunit,"FAKE",dfpopraw[(b-1),5])
        cnt=cnt+1
        dfpop[(b+cnt),]<-dfpopraw[b,] 
        test<-dfpopraw[b,1]
      }
    } 
  }
  dfpop[nrow(dfpop),]<-c(dfpopraw[nrow(dfpopraw),1],dfpopraw[nrow(dfpopraw),2]+Baseperunit,dfpopraw[nrow(dfpopraw),3]+Baseperunit,"FAKE",dfpopraw[nrow(dfpopraw),5])
  
  ##### Adding fake pop for a graphical reasons #####
  dfpopOK<-dfpop
  ### If halfmoon=TRUE --> insert a fake population to have that ###
  if (halfmoon==TRUE){
    rm(dfpop)
    tmpb<-as.data.frame(matrix(NA,nrow=nrow(dfpopOK),ncol=ncol(dfpopOK)))
    colnames(tmpb)<-colnames(dfpopOK)
    tmpb$Band<-"FAKE"
    tmpb$Stain<-"white"
    tmpb$ChromStart<-dfpopOK$ChromStart
    tmpb$ChromEnd<-dfpopOK$ChromEnd
    tmpchrhalf<-unique(dfpopOK$Chromosome)
    for (b in tmpchrhalf){
      tmpnamechr<-length(popord)+1+which(tmpchrhalf==b)
      tmpname<-paste("chr",tmpnamechr,sep="")
      tmpb[which(dfpopOK==b),1]<-tmpname
    }
    dfpop<-rbind(dfpopOK,tmpb)
    rm(tmpb)
  }else{
    ### Adding a new fake population to have a simmetric circle ###
    tmpchrEnd<-as.data.frame(matrix(NA,ncol=5,nrow=plusanim+1))
    colnames(tmpchrEnd)<-c("Chromosome","ChromStart","ChromEnd","Band","Stain")
    tmpchrEnd$Chromosome<-paste("chr",(length(popord)+2),sep="")
    tmpchrEnd$Band<-"FAKE"
    tmpchrEnd$Stain<-"gray"
    tmpchrEnd$ChromStart<-seq(0,(Baseperunit*(nrow(tmpchrEnd)-1)),Baseperunit)
    tmpchrEnd$ChromEnd<-seq(Baseperunit,(Baseperunit*(nrow(tmpchrEnd))),Baseperunit)
    dfpop<-rbind(dfpopOK,tmpchrEnd)
    rm(tmpchrEnd)
  }
  rm(dfpopOK)
  
  
  ##### Circos plot parameters #####
  dfpop$ChromStart <- as.numeric(dfpop$ChromStart)
  dfpop$ChromEnd <- as.numeric(dfpop$ChromEnd)
  chr.exclude <- NULL
  cyto.info <- dfpop
  tracks.inside <- length(K.to.plot)
  tracks.outside <- 0
  # suppressMessages(RCircos.Set.Core.Components(cyto.info, chr.exclude,tracks.inside, tracks.outside))
  RCircos.Set.Core.Components(cyto.info, chr.exclude,tracks.inside, tracks.outside)
  # RCircos.List.Parameters() ## to check the default paremeters
  ### some changing in the parameters for graphical reasons ###
  rcircos.params <- RCircos.Get.Plot.Parameters()
  rcircos.params$radius.len <- rcircos.params$radius.len + 0.5
  rcircos.params$track.height <- 0.1 
  rcircos.params$track.padding <- 0.025 
  rcircos.params$chr.name.pos <- rcircos.params$radius.len - 0.7
  rcircos.params$base.per.unit <- Baseperunit
  rcircos.params$hist.width <- 1
  rcircos.params$chrom.paddings <- 1
  rcircos.params$sub.tracks <- 0
  rcircos.params$track.background <- "white"
  rcircos.params$Bezier.point <- 10000 
  RCircos.Reset.Plot.Parameters(rcircos.params)
  # cat(RCircos.List.Parameters()) ## check the new paremeters
  
  # Change starting point for plotting in halfmoon plot
  if (halfmoon==TRUE){
    RCircosEnvironment <- NULL
    RCircosEnvironment <- get("RCircos.Env", envir = globalenv())
    plot.postions <- (RCircosEnvironment[["RCircos.Base.Position"]])
    num <- which(plot.postions[,1] == -1)
    plot.postions2 <- rbind(plot.postions[num:nrow(plot.postions),],plot.postions[1:(num-1),])
    RCircosEnvironment[["RCircos.Base.Position"]] <- plot.postions2
  }
  
  
  ##### Starting plotting #####
  ### Select the format ###
  if (plot.format == "pdf"){
    pdf(paste(out.file,"_Circos.pdf",sep=""),width=width.in,height=height.in)
  }else{
    if (plot.format == "png"){
      png(paste(out.file,"_Circos.png",sep=""),width=width.in*plot.res,height=height.in*plot.res, res=plot.res)
    }else{
      if (plot.format == "tiff" | plot.format == "tif"){
        tiff(paste(out.file,"_Circos.tif",sep=""), width=width.in*plot.res,height=height.in*plot.res, units="px", res=plot.res, compress="lzw")
      }else{
        cat("Allows plot format not found. Please check! \n")
        stop("Exit",call. = F)
      }
    }
  }
  
  ### set the plotting area ###
  RCircos.Set.Plot.Area()
  ### Plot the pops name ###
  FAKEpopord<-factor(c("",as.vector(popord),rep("",(length(popord)+5))))
  RCircos.Chromosome.Ideogram.Plot.bite(order = FAKEpopord, plot.cex = plot.cex)
  
  ##### Ks plotting #####
  for (i in 2:maxK){
    
    ### Import data ###
    # Read the file
    if (software %in% c("Admixture","ADMIXTURE","admixture", "sNMF")){
      filename <- paste(in.file,".",i,".Q",sep="")
      if (file.exists(filename) == FALSE){
        cat(paste("File ",filename," not found. Please check the name of your file or the software argument used! \n",sep=""))
        stop("Exit",call. = F)
      }
    }else{
      if (software %in% c("FastStructure","faststructure","FASTSTRUCTURE", "Faststructure")){
        filename <- paste(in.file,".",i,".meanQ",sep="")
        if (file.exists(filename) == FALSE){
          cat(paste("File ",filename," not found. Please check the name of your file or the software argument used! \n",sep=""))
          stop("Exit",call. = F)
        }
      }
    }
    Kraw<-read.table(filename)
    
    ### Order the IDs ###
    KordPop<-cbind(POP= key[,2], IID= key[,3],Kraw[key[,1],])  
    ### Order the pops ###
    vec<-NULL
    for (y in popord){
      if (y == popord[1]){
        vec<-which(KordPop[,1] == y)
        next
      }
      vec<-append(vec,which(KordPop[,1] == y))
    }
    KordordPop<-KordPop[vec,]
    dfpop$order<-seq(1,nrow(dfpop))
    ### create the df with the data to plot ###
    toplot<-merge(x=dfpop, y=KordordPop, by.x="Band", by.y="IID", all.x=T )
    toplot<-toplot[order(toplot$order),]
    tmptoplot <- toplot[-(which(toplot$Band == "FAKE")),c(2,3,4,seq(8,ncol(toplot)))]
    toplot<-toplot[,c(2,3,4,seq(8,ncol(toplot)))]
    toplot[is.na(toplot)==T]<-0.000001
    colnames(toplot)<-c("Chromosome","ChromStart","ChromEnd",paste("K",seq(1:i),sep=""))
    
    ##### Order the Ks to mantain consistency between color and ancestry #####
    ### Previous order given 
    if (k.prev == 1 & i<=k.order.maxK){
      k.order.df <- unlist(strsplit(k.order.file[i-1], split = "\t"))
      ordercol <- as.numeric(k.order.df[-1])+3
    }
    
    ### Previous order given but i > k.order.maxK
    if (k.prev == 1 & i==(k.order.maxK+1)){
      orderpop <- k.color.df[,2]
    }
    
    ### If previous order is not done or i>k.order.maxK
    if (k.prev == 0 | i>k.order.maxK){
      ordercol<-NULL
      ### Calculate the Ks means for each pops ###
      meandf <- apply(X = KordordPop[,3:ncol(KordordPop)], MARGIN = 2, FUN = function(x){
        tapply(X = x, INDEX = KordordPop[,1], FUN = mean)
      })
      meandf <- cbind(rownames(meandf), meandf)
      # colnames(meandf)<-c("POP",paste("K",seq(1:i),sep=""))
      if (i==2){
        ### initialization of the color order ### 
        ### for each ancestry, the population with the higher mean become the refence population for that ancestry ###
        tmp1<-meandf[which.max(meandf[,2]),1][1]
        tmp2<-meandf[which.max(meandf[,3]),1][1]
        ordercol<-c(4,5)
        orderpop<-c(tmp1,tmp2)  
      }else{
        tmpnumcol<-NULL
        tmpmeandf<-meandf
        ### The ref pop for a ancestry component is analized to retrive the correspondent column, and remove it from the df ###
        for (d in orderpop){
          tmpcolon<-names(which.max(tmpmeandf[which(tmpmeandf[,1]==d),2:ncol(tmpmeandf)]))
          ordercol<-c(ordercol,which(colnames(meandf)==tmpcolon)+2)
          tmpnumcol<-c(tmpnumcol,tmpcolon)
          tmpmeandf<-tmpmeandf[,-(which(colnames(tmpmeandf)==tmpcolon))]
        }
        ### the new unassinged ancestry will be analyzed and the reference POP will be find ###
        tmpnum<-setdiff(colnames(meandf)[-1],tmpnumcol)
        ordercol<-c(ordercol,which(colnames(meandf)==tmpnum)+2)
        other<-tmpmeandf[which.max(tmpmeandf[,tmpnum]),1][1]
        orderpop<-c(orderpop,other) 
      }
    }
    
    toplotOLD<-toplot
    rm(toplot);rm(tmptoplot)
    
    ##### Order the Ks colums to mantain the color order #####
    toplot<-cbind(toplotOLD[,1:3],toplotOLD[,ordercol])
    colnames(toplot)<-c("Chromosome","ChromStart","ChromEnd",paste("K",seq(1:i),sep=""))
    tmpordercol <- ordercol-3
    write.table(file=outf.plotorder,t(as.data.frame(c(paste("K",i,sep=""),tmpordercol))),row.names=F, col.names=F, quote=F, sep="\t", append=T)
    toplot$ChromStart<-as.numeric(toplot$ChromStart)
    toplot$ChromEnd<-as.numeric(toplot$ChromEnd)
    
    ##### Decide if K is or not plotted in the circos #####
    if (i %in% K.to.plot){
      cat(i," --> PLOTTED!              \r")
      cat(paste("K",i," plotted \n"),file=paste(out.file,".log",sep=""), append=T)
      ### Plotting parameters ###
      tp<-which(K.to.plot==i) # position in the plot
      data.col <- 4:ncol(toplot)
      track.num <- tracks.inside+1-tp
      side <- "in"
      RCircos.Histogram.Plot.bite(hist.data = toplot, data.col = data.col, 
                                  track.num = track.num, side = side, color = Mycol, 
                                  knum=i, halfmoon=halfmoon, plot.cex = plot.cex)
    }else{
      cat(i," --> Not plotted          \r")
    }
  }
  garbage <- dev.off()
  
  ### For each K, the population and color associated ###
  zz <- cbind(paste("K",seq(1:maxK), sep=""),orderpop,Mycol[1:maxK])
  colnames(zz)<-c("K","POP_assigned", "Color_assigned")
  write.table(zz,file=paste(out.file,"_colorassignement.txt",sep=""), quote=F, row.names=F, col.names=T, sep="\t")

}



##### Funtions from RCircos modified to plot adixture results #####
### They are used internally in the admixture.circos function ###
### In some case the modifications are few compared to the original ###
### the user can check the RCircos manual to understand the funtions ### 
### for dubts contact the BITE or RCircos maintainers ###

##### Plot the populations names #####
RCircos.Chromosome.Ideogram.Plot.bite<-function (order, plot.cex = 1){
  options(stringsAsFactors=F)
  RCircos.Cyto <- RCircos.Get.Plot.Ideogram()
  RCircos.Pos <- RCircos.Get.Plot.Positions()
  RCircos.Par <- RCircos.Get.Plot.Parameters()
  tmp.chr.name.pos <- RCircos.Par$chr.name.pos-0.25
  chroms <- unique(RCircos.Cyto$Chromosome)
  popord<-order
  for (a.chr in 1:length(chroms)) {
    the.chr <- RCircos.Cyto[RCircos.Cyto$Chromosome == chroms[a.chr],]
    start <- the.chr$Location[1] - the.chr$Unit[1] + 1
    end <- the.chr$Location[nrow(the.chr)]
    mid <- round((end - start + 1)/2, digits = 0) + start
    chr.name <- popord[a.chr]
    if (a.chr%%2==0){
      text(RCircos.Pos[mid, 1] * tmp.chr.name.pos, 
           RCircos.Pos[mid, 2] * tmp.chr.name.pos, label = chr.name, 
           srt = RCircos.Pos$degree[mid], cex=plot.cex)
    }else{
      text(RCircos.Pos[mid, 1] * (tmp.chr.name.pos+0.1), 
           RCircos.Pos[mid, 2] * (tmp.chr.name.pos+0.1), label = chr.name, 
           srt = RCircos.Pos$degree[mid], cex=plot.cex)
    }
  }
}

##### Function to plot the admixture result. Adapted to complete or half circle. #####
RCircos.Histogram.Plot.bite <- function (hist.data, data.col, track.num, side, color, knum, halfmoon, plot.cex){
  RCircos.Pos <- RCircos.Get.Plot.Positions()
  RCircos.Par <- RCircos.Get.Plot.Parameters()
  RCircos.Cyto <- RCircos.Get.Plot.Ideogram()
  hist.data <- RCircos.Get.Plot.Data(hist.data, "plot")
  hist.locations <- as.numeric(hist.data[, ncol(hist.data)])
  data.chroms <- as.character(hist.data[, 1])
  chromosomes <- unique(data.chroms)
  cyto.chroms <- as.character(RCircos.Cyto$Chromosome)
  if (halfmoon==TRUE){
    noplot<-c(1,seq((length(chromosomes)/2)+1,length(chromosomes)))
  }else{
    noplot<-c(1,length(chromosomes))
  }
  start<-NULL
  end<-NULL
  for (a.chr in 1:length(chromosomes)) {
    cyto.rows <- which(cyto.chroms == chromosomes[a.chr])
    locations <- as.numeric(RCircos.Cyto$Location[cyto.rows])
    start<-c(start,locations)
    end<-c(end,(locations+1))
  }  
  locations <- RCircos.Track.Positions(side, track.num)
  out.pos <- locations[1]
  in.pos <- locations[2]
  hist.colors <- matrix(RCircos.Get.Plot.Colors(hist.data, color[1:length(data.col)]),ncol=length(data.col),byrow=T)
  num.subtrack <- RCircos.Par$sub.tracks
  # To plot the borders # 
  RCircos.Track.Outline.bite(out.pos, in.pos, RCircos.Par$sub.tracks,noplot) 
  
  for (a.point in 1:nrow(hist.data)) {
    if (a.point == 1){
      # K value plotting #
      the.start <- start[2]
      if (halfmoon==TRUE){
        text(RCircos.Pos[the.start, 1] * (in.pos + (RCircos.Par$track.height/2)), 
             RCircos.Pos[the.start, 2] * (in.pos + (RCircos.Par$track.height/2)), 
             label = paste("K",knum,sep=""), cex=plot.cex, srt = 270)
      }else{
        text(RCircos.Pos[the.start, 1] * (in.pos + (RCircos.Par$track.height/2)), 
             RCircos.Pos[the.start, 2] * (in.pos + (RCircos.Par$track.height/2)), 
             label = paste("K",knum,sep=""), cex=plot.cex) 
      }
    }
    # Histogram plotting #
    for (a.col in 1:length(data.col)){
      if (a.col!=1){
        hist.height <- hist.data[a.point, data.col[a.col]]
        height2<-height + RCircos.Par$track.height * hist.height
        polygon.x <- c(RCircos.Pos[the.start:the.end, 1] * height2, 
                       RCircos.Pos[the.end:the.start, 1] * height)
        polygon.y <- c(RCircos.Pos[the.start:the.end, 2] * height2, 
                       RCircos.Pos[the.end:the.start, 2] * height)
        polygon(polygon.x, polygon.y, col = hist.colors[a.point,a.col], border = NA) 
        height<-height2        
      }else{
        # First # 
        hist.height <- hist.data[a.point, data.col[a.col]]
        the.start <- start[a.point]
        the.end <- end[a.point]
        height <- in.pos + RCircos.Par$track.height * hist.height
        polygon.x <- c(RCircos.Pos[the.start:the.end, 1] * height, 
                       RCircos.Pos[the.end:the.start, 1] * in.pos)
        polygon.y <- c(RCircos.Pos[the.start:the.end, 2] * height, 
                       RCircos.Pos[the.end:the.start, 2] * in.pos)
        polygon(polygon.x, polygon.y, col = hist.colors[a.point,a.col] , border = NA)
      }
    }
  }
}

##### Function to plot the outline #####
RCircos.Track.Outline.bite<-function (out.pos, in.pos, num.layers,noplot){
  RCircos.Cyto <- RCircos.Get.Plot.Ideogram()
  RCircos.Pos <- RCircos.Get.Plot.Positions()
  RCircos.Par <- RCircos.Get.Plot.Parameters()
  subtrack.height <- (out.pos - in.pos)/num.layers
  chroms <- unique(RCircos.Cyto$Chromosome)
  for (a.chr in 1:length(chroms)) {
    if (a.chr %in% noplot){
      next
    }else{
      the.chr <- RCircos.Cyto[RCircos.Cyto$Chromosome == chroms[a.chr],]
      start <- the.chr$Location[1] - the.chr$Unit[1] + 1
      end <- the.chr$Location[nrow(the.chr)]
      polygon.x <- c(RCircos.Pos[start:end, 1] * out.pos, RCircos.Pos[end:start,1] * in.pos)
      polygon.y <- c(RCircos.Pos[start:end, 2] * out.pos, RCircos.Pos[end:start,2] * in.pos)
      polygon(polygon.x, polygon.y, col = RCircos.Par$track.background)
      
      for (a.line in 1:(num.layers - 1)) {
        height <- out.pos - a.line * subtrack.height
        lines(RCircos.Pos[start:end, 1] * height, RCircos.Pos[start:end,2] * height, col = RCircos.Par$grid.line.color) 
      }
    }
  }
}
