#Function: bite.trialdata
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Marco Milanesi
#Contact: marco.milanesi.mm@gmail.com
#Description: Creates a copy of the desired example file type in the current working directory  

bite.trialdata<-function(type=NULL){
  
  list.type=c("plink", "Plink", "PLINK",  
              "Admixture","ADMIXTURE","admixture", 
              "FastStructure","faststructure","FASTSTRUCTURE", "Faststructure", 
              "sNMF",
              "treemix", "Treemix", "TreeMix", 
              "treemix_bootstrap", "Treemix_bootstrap", "TreeMix_bootstrap", "bootstrap", "Bootstrap")
  
  if (is.null(type)){
    cat("type argument empty. Please check! \n")
    stop("Exit",call. = F)
  }
  
  if (!(type %in% list.type)){
    cat("Allows example file type not found. Allowed types file are: \n",paste(list.type, collapse = ", "),"\nPlease check! \n")
    stop("Exit",call. = F)
  }
  
  
  ##### Copy files to the current working directory #####
  
  if (type %in% c("plink", "Plink", "PLINK")){
    cat("Plink example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample.tar.bz2")
    untar("HapMap3_chr2_subsample.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample.tar.bz2")
  }
  
  if (type %in% c("Admixture","ADMIXTURE","admixture")){
    cat("Admixture example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample_admixture.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample_admixture.tar.bz2")
    untar("HapMap3_chr2_subsample_admixture.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample_admixture.tar.bz2")
  }
  
  if (type %in% c("FastStructure","faststructure","FASTSTRUCTURE", "Faststructure")){
    cat("FastStructure example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample_faststructure.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample_faststructure.tar.bz2")
    untar("HapMap3_chr2_subsample_faststructure.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample_faststructure.tar.bz2")
  }
  
  if (type == "sNMF"){
    cat("sNMF example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample_sNMF.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample_sNMF.tar.bz2")
    untar("HapMap3_chr2_subsample_sNMF.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample_sNMF.tar.bz2")
  }
  
  if (type %in% c("treemix", "Treemix", "TreeMix")){
    cat("Treemix example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample_treemix.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample_treemix.tar.bz2")
    untar("HapMap3_chr2_subsample_treemix.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample_treemix.tar.bz2")
  }
  
  if (type %in% c("treemix_bootstrap", "Treemix_bootstrap", "TreeMix_bootstrap", "bootstrap", "Bootstrap")){
    cat("Treemix boostrap test example files will be copied in the current work directory \n")
    file.copy(system.file("extdata","HapMap3_chr2_subsample_treemix_bootstrap.tar.bz2", package = "BITE"), "HapMap3_chr2_subsample_treemix_bootstrap.tar.bz2")
    untar("HapMap3_chr2_subsample_treemix_bootstrap.tar.bz2",compressed = "bzip2")
    file.remove("HapMap3_chr2_subsample_treemix_bootstrap.tar.bz2")
  }
  
}

