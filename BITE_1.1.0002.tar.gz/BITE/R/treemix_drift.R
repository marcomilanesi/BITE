#Script: treemix.drift
#License: GPLv3 or later
#Written by: Marco Milanesi, Elia Vajana
#Contact: marco.milanesi.mm@gmail.com, vajana.elia@gmail.com
#Description: Produce a heatmap of drift parameters 
#Creation date: 2017-05-10

treemix.drift = function(
  in.file, 
  pop.order.color.file=NULL, 
  cex.lab = 1, 
  flip=vector(),
  ...
){
  ##### Import data and prepare the dataframe with the drift results #####
  d = paste(in.file, ".vertices.gz", sep = "")
  e = paste(in.file, ".edges.gz", sep = "")
  d = read.table(gzfile(d), as.is = T, comment.char = "", quote = "")
  e = read.table(gzfile(e), as.is  = T, comment.char = "", quote = "")
  e[,3] = e[,3]*e[,4]
  e[,3] = e[,3]*e[,4]
  
  pops <- sort(d$V2[!is.na(d$V2)])
  if (length(pop.order.color.file) == 0){
    o <- as.data.frame(cbind(pops,rep("black",length(pops))), stringsAsFactors = F)
    colnames(o) <- c("V1","V2")
  }else{
    if (!file.exists(pop.order.color.file)){
      cat("File with population order and colors not found. Please check! \n")
      stop("Exit",call. = F)
    }else{
      o = read.table(pop.order.color.file, as.is = T, comment.char = "", quote = "")
      if (!setequal(x = pops, y = o[,1])){
        cat("File with population order and colors doesn't match with the population in the dataset. Please check! \n")
        stop("Exit",call. = F)
      }
    }
  }
  
  for(i in 1:length(flip)){
    d = flip_node(d, flip[i])
  }
  d$x = "NA"
  d$y = "NA"
  d$ymin = "NA"
  d$ymax = "NA"
  options(warn=-1)
  d$x = as.numeric(d$x)
  d$y = as.numeric(d$y)
  d$ymin = as.numeric(d$ymin)
  d$ymax = as.numeric(d$ymax)
  options(warn=0)
  d = set_y_coords(d)
  d = set_x_coords(d, e)
  tmplog <- capture.output({
    d = set_mig_coords(d, e)
  })
  
  ##### Detect drift difference between pops #####
  coordinate <- d[which(d$V2 %in% o[,1]),c("V2","x","y")]
  subX <- as.data.frame(coordinate$x)
  rownames(subX) <- coordinate$V2
  DiffX <- abs(apply(combn(subX[,1],2), 2, diff))
  comparison <- combn(coordinate[,1],2)
  tmp1 <- data.frame(t(comparison),DiffX)
  tmp2 <- tmp1[,c(2,1,3)]
  colnames(tmp1) <- c("B1","B2","DELTA")
  colnames(tmp2) <- c("B1","B2","DELTA")
  DiffX <- rbind(tmp1,tmp2)
  rm(coordinate,subX,comparison,tmp1,tmp2)
  toplot<-dcast(data = DiffX, formula = B1 ~ B2, fill = 0, value.var = "DELTA")
  rownames(toplot) <- toplot[,1]
  toplot <- toplot[,-1]
  toplot <- toplot[o[,1],o[,1]]
  m1 = max(abs(toplot), na.rm = T)
  max = m1*1.02
  min = -(m1*1.02)	
  
  ##### PLOTTING #####
  d <- toplot
  npop = nrow(d)
  width = 1/npop
  height = 1/npop
  colors <- rev(c("darkblue","deepskyblue","limegreen","gold","yellow"))
  pal = colorRampPalette(colors)
  ncol = 100
  cols = pal(ncol)
  
  plot(0,0, xlim = c(0, 1), ylim = c(0, 1), axes = F, xlab = "", ylab = "", type="n")
  
  for (i in 1:npop){
    for( j in 1:i){
      v = d[i,j]
      posc <- ceiling((v/max)*(ncol))
      if (posc == 0){
        col = "gray95"
      }else{
        col = cols[posc]
      }
      xmin = j/npop - 1/npop
      xmax = j/npop
      ymin = 1-(i/npop)
      ymax = 1-(i/npop)+1/npop
      rect(xmin, ymin, xmax, ymax, col = col, border = col)
    }
    tmp = o[o[,1] == names(d)[i],]
    if (ncol(o) != 1){
      tcol = tmp[1,2]
    }else{
      tcol = "black"
    }
    mtext(names(d)[i], side = 2, at = 1-i/npop+0.5/npop, las = 1, cex = cex.lab, col = tcol)
    mtext(names(d)[i], side = 1, at =  i/npop-0.5/npop, las = 3, cex = cex.lab, col = tcol)
  }
  
  # Legend
  ymi = 0.45
  yma = 0.95
  ncol = 100+1
  w = (yma-ymi)/ncol
  xma = 0.80
  lmi=0
  lma=round(max,4)
  rect(rep(0.75, ncol), ymi+(0:(ncol-1))*w, rep(xma, ncol), ymi+(1:ncol)*w, col = c("grey95",cols), border = c("grey95",cols))
  text(xma+0.01, ymi, lab = lmi,  adj = 0, cex = 0.8)
  text(xma+0.01, yma, lab = lma, adj = 0, cex = 0.8)
}
