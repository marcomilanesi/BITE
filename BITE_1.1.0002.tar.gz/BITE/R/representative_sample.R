#Script: representative.sample
#License: GPLv3 or later
#Written by: Marco Milanesi, Elia Vajana, Stefano Capomaccio, Lorenzo Bomba
#Contact: marco.milanesi.mm@gmail.com, vajana.elia@gmail.com, capemaster@gmail.com, lory.bomb@gmail.com
#Description: Representative subsampling of large dataset exploiting genomic structure
#Modification date: 2017-04-11

representative.sample = function(
  in.file, 
  out.file="tmp",
  pheno.file=NULL,
  dir.name="RepresentativeSampling_plots",
  n.subsample=1, 
  threshold=0.75,
  n.k=3,
  n.trials=100,
  excluded.pop=NULL,
  id.cr=0.95,
  ibs.thr=0.95,
  ibs.marker=3000,
  ibs.excl="lower",
  obshet.fdr=0.01
){
 
  ##### Log file #####
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  tped <- paste(in.file,"tped",sep=".")
  tfam <- paste(in.file,"tfam",sep=".")
  if (file.exists(tped) & file.exists(tfam)){
    cat(paste("Input file:",in.file,"\n"))
  }else{
    sink()
    cat("Input file not found. Please check! \n")
    stop("Exit",call. = F)
  }
  cat(paste("Output file:",out.file,"\n"))
  cat("Options used:\n")
  cat(paste("   Number of items to choose:",n.subsample,"\n"))
  cat(paste("   Similarity threshold:",threshold,"\n"))
  cat(paste("   Number of components used:",n.k,"\n"))
  cat(paste("   Number of markers used:",ibs.marker,"\n"))
  cat(paste("   QC parameters: ID call rate:",id.cr,"; IBS threshold:",ibs.thr,"(",ibs.excl,"); Obs.Het FDR:",obshet.fdr,"\n\n"))
  sink()
  
  # PhenoFile
  if (is.null(pheno.file)){
    tmp <- read.table(tfam)
    tmpsex<-tmp[,5]
    tmpsex[tmpsex!=1] <- 0
    tmppheno <- cbind(tmp[,1:2],tmpsex,rep(-9,nrow(tmp)))
    colnames(tmppheno)<-c("pop","id","sex","pheno")
    write.table(tmppheno, file = "phenotype.txt", quote = F, row.names = F, col.names = T, sep="\t")
    rm(tmp,tmpsex,tmppheno)
    pheno.file="phenotype.txt"
  }else{
    if (!file.exists(pheno.file)){
      cat("Phenotypes file not found. Please check! \n")
      stop("Exit",call. = F)
    }
  }

  # Import data using GenABEL
  cat("Importing and checking data before analyses starting. \n")
  tmplog <- capture.output({
    convert.snp.tped(tpedfile=tped,tfamfile=tfam,strand = "u", bcast = 10000, outfile="gwa.raw")
    MyData<-load.gwaa.data(phenofile = pheno.file, genofile = 'gwa.raw' , force=F)
  })
  
  # create plot directory
  MDS<-dir.name
  dir.create(MDS)
  
  # Population analysed
  uniqpop<-as.vector(unique(MyData@phdata$pop))
  if(length(excluded.pop) == 0){
    sink(file=paste(out.file,".log",sep=""), append = T)
    cat(paste("Population subsampled:\n",paste(uniqpop, collapse = " "),"\n\n"))
    sink()
  }else{
    sink(file=paste(out.file,".log",sep=""), append = T)
    uniqpop <- uniqpop[-which(uniqpop %in% excluded.pop)]
    cat(paste("Population excluded:",paste(excluded.pop, collapse = " "),"\n"))
    cat(paste("Population subsampled:\n",paste(uniqpop, collapse = " "),"\n\n"))
    sink()
  }
  
  ##### Per breed analyses #####
  cat("Subsampling procedure started.\n") 
  cat("   ... The procedure uses IBS matrix. The matrix creation can take several minutes ... please wait\n")
  for (i in uniqpop){
    
    cat(paste("  Population investigated:",i,"\n"))
    Datatemp<-MyData[(MyData@phdata$pop==i), ]
    n.ind.ori <- nrow(Datatemp@phdata)
    sink(file=paste(out.file,".log",sep=""), append = T)
    cat(paste("  Population investigated",i,"\n"))
    cat(paste("Number of individuals - original:",n.ind.ori,"\n"))
    sink()
    
    # Number of individual less than subsample size choosen
    if (n.ind.ori<=n.subsample){
      sink(file=paste(out.file,".log",sep=""), append = T)
      cat("   *** The number of individual is less than subsample size choosen. All included in the final list ***\n\n\n")
      sink()
      # write out a subject list
      write.table(Datatemp@phdata[,c(1,2)],file=paste(out.file,"txt",sep="."), 
                  quote=FALSE, row.names=FALSE, col.names=FALSE, append=T) 
      
    }else{
      # The number is higher than the threshold 
      # SNP subsampling
      if (length(autosomal(Datatemp)) <= ibs.marker){
        ibs.marker <- length(autosomal(Datatemp))
      }
      selectedSnps <- sample(autosomal(Datatemp),ibs.marker,replace=FALSE)
      
      # QC procedure
      tmplog <- capture.output({
        possibleError <- tryCatch(
          qcall<-check.marker(Datatemp, extr.call=0, extr.perid.call=0, 
                              callrate=0, perid.call=id.cr, 
                              ibs.threshold = ibs.thr, ibs.mrk = ibs.marker, ibs.exclude=ibs.excl, 
                              het.fdr=obshet.fdr,
                              maf = 0, p.level=0, imphetasmissing=TRUE),
          error=function(e) e
        )
      })
      
      # Error checking in the QC procedure
      if(!inherits(possibleError, "error")){
        
        # clean dataset
        MyDataclean <- Datatemp[qcall$idok,qcall$snpok]
        n.ind.qc <- nrow(MyDataclean@phdata)
        
        # QC stats
        sink(file=paste(out.file,".log",sep=""), append = T)
        cat(paste("Number of individuals - after QC:",n.ind.qc,"\n"))
        if (length(qcall$ibsfail) != 0){
          cat(paste("   Individuals removed for IBS (",length(qcall$ibsfail),"):\n     ",paste(qcall$ibsfail, collapse = ", "),"\n",sep=""))
        }
        if (length(qcall$idnocall) != 0){
          cat(paste("   Individuals removed for ID no call (",length(qcall$idnocall),"):\n     ",paste(qcall$idnocall, collapse = ", "),"\n",sep=""))
        }
        if (length(qcall$hetfail) != 0){
          cat(paste("   Individuals removed for high Obs.Het (",length(qcall$hetfail),"):\n     ",paste(qcall$hetfail, collapse = ", "),"\n",sep=""))
        }
        cat("\n")
        sink()
        
        # if the number of the individual left is less than subsample size choosen
        if (n.ind.qc<=n.subsample){
          sink(file=paste(out.file,".log",sep=""), append = T)
          cat("   *** After QC, the number of individual is less than subsample size choosen. All included in the final list ***\n\n\n")
          sink()
          # write out the subject list
          write.table(MyDataclean@phdata[,c(1,2)],file=paste(out.file,"txt",sep="."), 
                      quote=FALSE, row.names=FALSE, col.names=FALSE, append=T) 
        }else{
          
          # kinship matrix in the complete dataset
          MyDataclean.gkin <- ibs(data = MyDataclean,snpsubset = selectedSnps,weight="freq")
          MyDataclean.dist <- as.dist(0.5-MyDataclean.gkin)
          MyDataclean.mds <- cmdscale(MyDataclean.dist,k=n.k)
          
          # Supervised sampling starting
          tmptrial <- 0
          for (a in 1:n.trials) {
            # print(a)
            # Subset the individuals using sample function 
            subjectsubset <- sample(as.vector(MyDataclean@phdata[,2]),n.subsample,replace = FALSE)
            
            # kinship matrix in the subsetted dataset
            MyDatacleansub.gkin <- ibs(data = MyDataclean,snpsubset = selectedSnps,weight="freq",idsubset=subjectsubset)
            MyDatacleansub.dist <- as.dist(0.5-MyDatacleansub.gkin)
            MyDatacleansub.mds <- cmdscale(MyDatacleansub.dist,k=n.k)
            
            ### Wilcoxon test to compare structure
            t.mds <- rep(0, n.k)
            for (b in 1:n.k){
              tmp.test <- ks.test(MyDataclean.mds[,b],MyDatacleansub.mds[,b], alternative = "two.sided")
              t.mds[b] <- tmp.test$p.value
            }
            
            if (min(t.mds) >= threshold){
              sink(file=paste(out.file,".log",sep=""), append = T)
              cat("   *** After",b,"iterations a subset with a similar structure to the original one was found\n\n\n")
              sink()
              tmptrial <- 1
              # print("WELL DONE!")
              break()
            }
          }
          
          if (tmptrial == 0){
            sink(file=paste(out.file,".log",sep=""), append = T)
            cat("   *** After",n.trials,"iterations a subset with a similar structure to the original one was NOT found! \nPlease revise the parameters!!!\n\n\n")
            sink()
          }else{
            # Out file
            fileprint<-MyDataclean@phdata[is.element(MyDataclean@phdata$id,subjectsubset),c(1,2)]
            write.table(fileprint,file=paste(out.file,"txt",sep="."), 
                        quote=FALSE, row.names=FALSE, col.names=FALSE, append=T)
            
            
            ### Plotting ###
            # Original MDS only subset subjects
            sub.MyDataclean.mds <- MyDataclean.mds[is.element(rownames(MyDataclean.mds),subjectsubset),]
            
            # Cheching if there is an inversion in the PCs
            for (b in 1:n.k){
              if (ks.test(sub.MyDataclean.mds[,b], (MyDatacleansub.mds[,b]))$p.value < ks.test(sub.MyDataclean.mds[,b], (-MyDatacleansub.mds[,b]))$p.value){
                MyDatacleansub.mds[,b] <- -MyDatacleansub.mds[,b]
                # cat(b,"INV \n")\
              }
            }
            
            # plotting
            comb<-combn(n.k,2)
            for (j in 1:ncol(comb)){
              one <- comb[1,j]
              two <- comb[2,j]
              
              maxX=max(max(MyDatacleansub.mds[,one]),max(MyDataclean.mds[,one]))
              maxY=max(max(MyDatacleansub.mds[,two]),max(MyDataclean.mds[,two]))
              minX=min(min(MyDatacleansub.mds[,one]),min(MyDataclean.mds[,one]))
              minY=min(min(MyDatacleansub.mds[,two]),min(MyDataclean.mds[,two]))
              
              pdf(paste(MDS,"/SupervisedSampling_",i,"_PC",one,"-vs-PC",two,".pdf",sep=""))
              # ALL + SubSample
              plot(0,0,xlim=range(minX,maxX),ylim=range(minY,maxY),
                   xlab=paste("PC",one), ylab=paste("PC",two),
                   pch="",main=paste("MDS ",i))
              points(MyDataclean.mds[,c(one,two)],col="grey",pch=2, cex=0.7)
              points(sub.MyDataclean.mds[,c(one,two)],col="purple",pch=2, cex=0.7)
              points(MyDatacleansub.mds[,c(one,two)],col="blue",pch=1)
              
              # ALL
              plot(0,0,xlim=range(minX,maxX),ylim=range(minY,maxY),
                   xlab=paste("PC",one), ylab=paste("PC",two),
                   pch="",main=paste("MDS ",i))
              points(MyDataclean.mds[,c(one,two)],col="grey",pch=2, cex=0.7)
              points(sub.MyDataclean.mds[,c(one,two)],col="purple",pch=2, cex=0.7)
              
              # SubSample
              plot(0,0,xlim=range(minX,maxX),ylim=range(minY,maxY),
                   xlab=paste("PC",one), ylab=paste("PC",two),
                   pch="",main=paste("MDS ",i))
              points(MyDatacleansub.mds[,c(one,two)],col="blue",pch=1)
              
              dev.off()
            }
          }
        }
      }
    }
  }
  cat("The procedure has finished\n")
}


