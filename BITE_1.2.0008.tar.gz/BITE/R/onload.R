.onAttach <- function(libname, pkgname) {
  mymsg <- "Loading required package: BITE\n\n\n"
  mymsg <- paste(mymsg,"Thanks for using BITE v1.2.0008!\n")
  mymsg <- paste(mymsg,"For more information use: help(package = 'BITE')\n")
  mymsg <- paste(mymsg,"                          browseVignettes(package = 'BITE')\n\n")
  mymsg <- paste(mymsg,"Citation:\n")
  mymsg <- paste(mymsg,"  Authors: Milanesi M, Capomaccio S, Vajana E, Bomba L, Garcia JF, Ajmone-Marsan P and Colli L.\n")
  mymsg <- paste(mymsg,"  Title: BITE: an R package for biodiversity analyses.\n")
  mymsg <- paste(mymsg,"  Preprint on BioRxiv.\n")
  mymsg <- paste(mymsg,"  DOI: https://doi.org/10.1101/181610.\n\n")
  packageStartupMessage(mymsg)
}
