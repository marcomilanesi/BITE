


################################################################################
################################### BITE PCA ###################################
################################################################################



bite.pca <- function(gds.path, out.dir = NULL, out.name = "pca_tmp", n.k= 2, snp.random.subset = NULL, samples = NULL, snps= NULL, plot.res = FALSE, plotFormat = "pdf", legend.in = FALSE, ...) {

  ### CHECK PARAMS
  formats <- c("pdf", "png", "jpeg")
  if (!(plotFormat %in% formats)) {
    cat("Invalid format\n")
    stop("Exit", call. = F)
  }

  ### GDS IN
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  ### OUT DIR
  out.path <- paste(out.dir, "/", out.name, sep="")

  if (!file.exists(out.path)) {
    dir.create(out.path)
  }

  # take data
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.num <- length(snp.id)
  sample.num <- length(sample.id)

  ##### CHECK SNP.RANDOM.SUBSET #####
  if (is.null(snp.random.subset)) {

    # check num of snps
    if (snp.num >= 200000 & sample.num >= 500) {
      # warning message
      cat(paste("Warning: ", basename(gds.in$filename), " contains ", snp.num, " snps & ", sample.num, " individuals.\n", sep=""))
      cat("Bite.pca() may take a long time.\nConsider the idea of using only a random subset of snps for PCA analysis:\n")
      cat("- Yes (1)\n")
      cat("- No (2)\n")

      choice <- readline()

      if (choice == 1) {
        cat("Enter the number of snps to consider: ")
        snp.random.subset <- readline()
        snp.random.subset <- as.numeric(snp.random.subset)

        if (snp.random.subset >= snp.num || snp.random.subset <= 0) {
          cat("Invalid value!\n")
          stop("Exit", call.=F)
        }
      } else if (choice == 2) {
        snp.random.subset <- snp.num
      } else {
        cat("Invalid selection .... \n")
        stop("Exit", call.=F)
      }
    }
  }

  if (snp.random.subset == snp.num || is.null(snp.random.subset)) {
    snp.sample <- snp.id
  } else {
    snp.sample <- sample(snp.id, snp.random.subset, replace = F)
  }

  ## check snp.id and sample.id
  if (!is.null(samples)) {
    sample.id <- samples
  }
  if (!is.null(snps)) {
    snp.sample <- snps
  }

  cat("Running ...\n")
  #### SNPRelate PCA ####
  pca <- snpgdsPCA(gds.in, verbose=FALSE, snp.id = snp.sample, sample.id = sample.id, eigen.cnt = n.k)

  pc.percent <- pca$varprop*100
  pcperc <- data.frame(perc = round(pc.percent, 2), pc = factor(paste("PC", 1:length(pc.percent), sep="")))

  fam <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  to_take <- which(fam$id %in% sample.id)
  fam <- fam[to_take, ]
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))
  tab <- as.data.frame(pca$eigenvect)
  #tab$id <- fam$id
  tab$pop <- fam$pop

  ### PLOT

  if (plot.res) {
    if (is.null(out.dir)) {
      cat("Please enter the out.dir parameter!\n")
    } else {
      comb <- combn(n.k, 2)
      for (i in 1:dim(comb)[2]) {
        ggplot(data=tab, aes(x=0, y=0)) +
          geom_point(aes(x=tab[, comb[1, i]],y=tab[,comb[2,i]], color=pop, shape=pop, label=pop)) +
          scale_shape_manual(values=ordermatrix$V3) +
          labs(x=paste("Pcs ",comb[1,i]," (", round(pc.percent[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
               y=paste("Pcs ",comb[2,i]," (", round(pc.percent[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
               title="Principal Component Analysis") +
          geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
          geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
          scale_color_manual(values = ordermatrix$V2) +
          theme_bw() +
          if (!legend.in) {
            theme(axis.text.x = element_blank(), legend.position = "none")
          } else {
            theme(axis.text.x = element_blank())
          }
        ggsave(paste(out.path,"/",out.name,"_PC_",comb[1,i],"-vs-",comb[2,i],".", plotFormat,sep=""), width = 12, height = 9)
      }

      # Pop ID
      pcaMean <- aggregate(. ~ pop, data = tab, mean)
      pcaMean <- pcaMean %>% relocate(pop, .after = last_col())

      for (i in 1:dim(comb)[2]) {
        ggplot(data=tab, aes(x=tab[, comb[1, i]], y=tab[,comb[2,i]], shape=pop, color=pop)) +
          geom_point() +
          geom_label_repel(data = pcaMean, aes(x=pcaMean[, comb[1, i]],y=pcaMean[,comb[2,i]], label=pop), max.overlaps = 20) +
          labs(x=paste("Pcs ",comb[1,i]," (", round(pc.percent[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
               y=paste("Pcs ",comb[2,i]," (", round(pc.percent[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
               title="Principal Component Analysis") +
          geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
          geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
          scale_color_manual(values = ordermatrix$V2) +
          scale_shape_manual(values=ordermatrix$V3) +
          theme_bw() +
          theme(axis.text.x = element_blank(), legend.position = "none")

        ggsave(paste(out.path,"/",out.name,"_PC_",comb[1,i],"-vs-",comb[2,i],"_POP.", plotFormat,sep=""), width = 12, height = 9)
      }
    }
  }

  if (!legend.in & plot.res) {
    pdf(paste(out.path, "/", out.name, "_PopCode.pdf",sep=""), width = 18, height = 9)
    tmp <- ceiling(sqrt(length(ordermatrix[,1])))
    plot(0,0,type="n",xlim=c(0,tmp*7), ylim=c(0,tmp*7),yaxt="n", xaxt="n", frame.plot=F, xlab="", ylab="")
    legend(0,tmp*7,ordermatrix[,1], ncol=floor(tmp/2), col=ordermatrix[,2], lty=0,pch=as.numeric(ordermatrix[,3]), cex=0.75)
    garbage <- dev.off()
  }

  outlist <- list()
  outlist$pcperc <- pcperc
  outlist$eigenvect <- tab

  return (outlist)
}



