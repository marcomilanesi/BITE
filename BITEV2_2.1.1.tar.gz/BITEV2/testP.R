

library(BITEV2)

##### BITE TRIALDATA
out.dir <- "/Users/paololitta/Desktop/BITE/new_package/testing"
setwd(out.dir)


################################################################################
#################################### PLINK FUN #################################
################################################################################

bite.trialdata(type = "plink")

##### BITE OPEN
gds.in <- bite.open("HapMap3_chr2_subsample.bed", out.dir)
gds.path <- gds.in$filename

##### BITE BIOSTAT
bite.biostat(gds.path, out.dir)

##### BITE QC
qc.gds <- bite.qc(gds.path, out.dir)
gds.path <- qc.gds$filename

##### SHINY PCA
bite.shinyPCA(gds.path)

##### SUPERVISED PCA
bite.supervisedPCA(gds.path, out.dir, outPop = "JPT")

##### PCA
res.pca <- bite.pca(gds.path, out.dir, n.k = 3, plot.res = T)


##### REMOVE / SELECT
noJPT <- bite.remove(gds.path, out.dir, outPOP = "JPT", gds.out = "noJPT.gds")
onlyJPT <- bite.select(gds.path, out.dir, inPOP = "JPT", gds.out = "onlyJPT.gds")


##### SUBSAMPLING
cl.subsamp <- bite.representative.sampling(gds.path, out.dir, n.subsample = 30, n.iter = 20)
km.subsamp <- bite.kmeans.subsampling(gds.path, out.dir, n.subsample = 30)

##### RANDOM SUBSET
random.subsamp <- bite.randomSubset(gds.path, out.dir, dim.id = 200, dim.snp = 2000)

##### TRANSLATE
bite.translate(gds.path, out.dir, out.name = "post_qc")


################################################################################
################################ MEMBERCOEFF FUN ###############################
################################################################################

dir.create(paste0(out.dir, "/membercoeff"))
res.dir <- paste0(out.dir, "/membercoeff")

setwd(res.dir)
bite.trialdata("admixture")

##### CIRCOS FUN
membercoeff.circos("HapMap3_chr2_subsample", paste0(res.dir, "/res"), maxK = 10, K.to.plot = c(2,4,6,8,10))

##### CV
membercoeff.cv("log", paste0(res.dir, "/res"), maxK = 10, K.to.plot = c(2,4,6,8,10))

##### PLOT
membercoeff.plot("HapMap3_chr2_subsample", paste0(res.dir, "/res"), maxK = 10)

################################################################################
################################## TREEMIX FUN #################################
################################################################################

dir.create(paste0(out.dir, "/treemix"))
res.dir <- paste0(out.dir, "/treemix")

setwd(res.dir)
bite.trialdata("treemix")

##### PLOT COVARIANCE & MODELCOV
pdf("Test_Treemix_cov_4.pdf",12,7)
par(mar=c(4,2,1,2),mfrow=c(1,2), oma=c(3,2,1,2))
# Plot Variance
plot_cov(stem = "HapMap3_chr2_subsample_treemix_4", pop_order = "PopOrdCol.txt",
         cex = 0.6, wcols = "")
# Plot model Covariance
plot_modelcov(stem = "HapMap3_chr2_subsample_treemix_4", pop_order = "PopOrdCol.txt",
              cex = 0.6)
dev.off()

##### PLOT TREEMIX TREE
pdf("Test_Treemix_tree_4.pdf", 12,7)
par(mar=c(4,2,1,2),mfrow=c(1,2), oma=c(3,2,1,2))

# Plot tree
plot_tree("HapMap3_chr2_subsample_treemix_4",
          o = "PopOrdCol.txt",
          arrow=0.1, ybar=.25, xmin=0, disp=0, flip=1, mbar=T, lwd=0.5, plotnames=T, cex=0.6)

# Plot residual
plot_resid("HapMap3_chr2_subsample_treemix_4","PopOrdCol.txt", cex=0.6, wcols="")

dev.off()

#### DRIFT AS HEATMAP
pdf("Test_Treemix_drift.pdf")
treemix.drift(in.file = "HapMap3_chr2_subsample_treemix_4",
              pop.order.color = "PopOrdCol.txt", cex = 1)
dev.off()

#### FIT
treemix.fit(in.file = "HapMap3_chr2_subsample_treemix_", out.file = "test", m.start = 0, m.end = 5)


################################################################################
############################# TREEMIX BOOTSTRAP FUN ############################
################################################################################

dir.create(paste0(out.dir, "/treemix_bootstrap"))
res.dir <- paste0(out.dir, "/treemix_bootstrap")

setwd(res.dir)

bite.trialdata("Treemix_bootstrap")

##### PLOT TREEMIX TREE WITH 4 MIGRATIONS AND THE BOOTSTRAP VALUES
pdf("Test_Treemix_bootstrap.pdf", 10, 7)
treemix.bootstrap(in.file = "HapMap3_chr2_subsample_treemix_bootstrap",
                  out.file = "test",
                  phylip.file = "HapMap3_chr2_subsample_treemix_bootstrap_outtree.newick",
                  pop.color.file = "PopOrdCol.txt", nboot = 100,
                  cex=0.5, xmin = -0.005, disp = 0.001,
                  boot.legend.location = "top", xbar = 0.05)
dev.off()




