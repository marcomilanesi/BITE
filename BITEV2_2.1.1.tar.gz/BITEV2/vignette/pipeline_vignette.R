##### LIB
library(BITEV2)


##### DATA
out.dir <- "/Users/capemaster/Desktop/prova"
setwd(out.dir)
bite.trialdata(type = "plink")

##### BITE OPEN
gds.in <- bite.open(in.file = "HapMap3_chr2_subsample.bed", out.dir = out.dir,
                    gds.out = "HapMap3_chr2_subsample.gds", num_autosomes = 29)


##### BITE BIOSTAT

# with default params
bite.biostat(gds.path = gds.in$filename, out.dir = out.dir)


##### BITE QC

# with default parameters
gds.qc <- bite.qc(gds.path = gds.in$filename, out.dir = out.dir)

##### DIM REDUCTION

### PCA
# plot res in out.dir
res.pca <- bite.pca(gds.path = gds.qc$filename, out.dir = out.dir, plot.res = TRUE)

### SHINY PCA

bite.shinyPCA(gds.path = gds.qc$filename)

### SUPERVISED PCA

bite.supervisedPCA(gds.path = gds.qc$filename, out.dir = out.dir, outID = c("NA19777", "NA19679",
                                                                            "NA19759", "NA19719"))

##### SUBSAMPLING
# with def params

### Classic
cl.subsamp <- bite.representative.sampling(gds.path = gds.qc$filename, out.dir = out.dir,
                                           n.subsample = 30)

## K means
km.subsamp <- bite.kmeans.subsampling(gds.path = gds.qc$filename, out.dir = out.dir,
                                      n.subsample = 30)

##### RANDOM / SELECT / REMOVE

## Random
random.subset <- bite.randomSubset(gds.path = gds.qc$filename, out.dir = out.dir,
                                   dim.id = 400, dim.snp = 1000)

## Select
# puoi specificare più pop inserendo un vect in inPOP (stessa cosa per id)
select.subset <- bite.select(gds.path = gds.qc$filename, out.dir = out.dir,
                             inPOP = "CHB")

## Remove
remove.subset <- bite.remove(gds.path = gds.qc$filename, out.dir = out.dir,
                             outID = c("NA19777", "NA19777"))


##### TRANSLATE

bite.translate(gds.path = gds.qc$filename, out.dir = out.dir, out.format = "ped")


