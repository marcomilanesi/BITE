#Script: bite.qc
#License: GPLv3 or later
#Modification date: 2017-05-16
#Written by: Marco Milanesi
#Contact: marco.milanesi.mm@gmail.com
#Description: Functions to run QC 

bite.qc <-  function (
  in.file,
  out.file="tmp",
  pheno.file=NULL,
  snp.cr=0.95,
  id.cr=0.95,
  snp.maf=0.05,
  hweq=0,
  obshet.fdr=0.01,
  ibs.thr=0.95,
  ibs.marker=5000,
  ibs.excl="lower",
  imphetasmissing=TRUE,
  ws.save=FALSE,
  ...
){
  
  #################################
  # Pre-requisites & Log file #
  cat("Importing and checking data before analyses starting. \n")
  options(stringsAsFactors=FALSE)
  
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  tped <- paste(in.file,"tped",sep=".")
  tfam <- paste(in.file,"tfam",sep=".")
  if (file.exists(tped) & file.exists(tfam)){
    cat(paste("Input file:",in.file,"\n"))
  }else{
    sink()
    cat("Input file not found. Please check! \n")
    stop("Exit",call. = F)
  }
  cat(paste("Output file:",out.file,"\n"))
  cat("\n")
  cat(paste("QC parameters:",
            "\n SNP Call rate: ",snp.cr,
            "\n SNP MAF: ",snp.maf,
            "\n H-W eq: ",hweq,
            "\n ID call rate: ",id.cr,
            "\n IBS threshold: ",ibs.thr," (excluded ",ibs.excl," - used ",ibs.marker," markers)",
            "\n Obs.Het - FDR: ",obshet.fdr,"\n\n", sep=""))
  sink()
  
  # PhenoFile
  if (is.null(pheno.file)){
    tmp <- read.table(tfam)
    tmpsex<-tmp[,5]
    tmpsex[tmpsex!=1] <- 0
    tmppheno <- cbind(tmp[,1:2],tmpsex,rep(-9,nrow(tmp)))
    colnames(tmppheno)<-c("pop","id","sex","pheno")
    write.table(tmppheno, file = "phenotype.txt", quote = F, row.names = F, col.names = T, sep="\t")
    rm(tmp,tmpsex,tmppheno)
    pheno.file="phenotype.txt"
  }else{
    if (!file.exists(pheno.file)){
      cat("Phenotypes file not found. Please check! \n")
      stop("Exit",call. = F)
    }
  }
  
  # Importing  
  tmplog <- capture.output({
    convert.snp.tped(tpedfile=tped,tfamfile=tfam,strand = "u", bcast = 10000, outfile="gwa.raw")
    MyData<-load.gwaa.data(phenofile = pheno.file, genofile = 'gwa.raw' , force=F)
  })
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(out.file,"_ws.RData",sep=""))
  }
  
  # Starting QC
  cat("Quality Control: running\n")
  
  sink(file=paste(out.file,".log",sep=""), append = T)
  cat(" ***** Quality Control Procedure ***** \n")
  
  set.seed(1986)
  qcall<-check.marker(MyData, 
                      extr.call=0, extr.perid.call=0, 
                      callrate=snp.cr, perid.call=id.cr, 
                      ibs.threshold = ibs.thr, ibs.mrk = ibs.marker, ibs.exclude=ibs.excl, 
                      maf = snp.maf, p.level=hweq, het.fdr=obshet.fdr, 
                      imphetasmissing=imphetasmissing)
  
  # Print results
  sumlog=summary(qcall)
  cat("\n\n ***** Quality Control Stats ***** \n")
  cat("Per-subject fails statistics\n")
  print(sumlog$'Per-person fails statistics')
  cat('\n')
  cat("Per-SNP fails statistics\n")
  print(sumlog$'Per-SNP fails statistics')
  cat('\n\n')
  
  # Create clean dataset
  MyDataclean <- MyData[qcall$idok,qcall$snpok]
  
  # Dataset stats
  cat("Original dataset: ",nrow(MyData@phdata)," subject(s) and ",length(MyData@gtdata@snpnames)," SNPs \n")
  cat("Quality controlled dataset: ",nrow(MyDataclean@phdata)," subject(s) and ",length(MyDataclean@gtdata@snpnames)," SNPs \n")
  sink()
  
  # Dataset stats
  cat("Original dataset: ",nrow(MyData@phdata)," subject(s) and ",length(MyData@gtdata@snpnames)," SNPs \n")
  cat("Quality controlled dataset: ",nrow(MyDataclean@phdata)," subject(s) and ",length(MyDataclean@gtdata@snpnames)," SNPs \n")
  
  # Export IDs and SNPs excluded
  if (length(qcall$nofreq) != 0){
    write.table(qcall$nofreq, file = paste(out.file,"_excluded_SNP_freq.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  if (length(qcall$nocall) != 0){
    write.table(qcall$nocall, file = paste(out.file,"_excluded_SNP_call.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  if (length(qcall$nohwe) != 0){
    write.table(qcall$nohwe, file = paste(out.file,"_excluded_SNP_hwe.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  if (length(qcall$hetfail) != 0){
    write.table(MyData@phdata[which(MyData@phdata$id %in% qcall$hetfail),1:2], 
                file = paste(out.file,"_excluded_ID_het.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  if (length(qcall$idnocall) != 0){
    write.table(MyData@phdata[which(MyData@phdata$id %in% qcall$idnocall),1:2], 
                file = paste(out.file,"_excluded_ID_call.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  if (length(qcall$ibsfail) != 0){
    write.table(MyData@phdata[which(MyData@phdata$id %in% qcall$ibsfail),1:2], 
                file = paste(out.file,"_excluded_ID_ibs.txt",sep=""), 
                quote=F, row.names=F, col.names=F)
  }
  
  # Export IDs and SNPs passed QC
  write.table(MyDataclean@phdata[,c(1,2)], file = paste(out.file,"_listIDOK.txt",sep=""), 
              quote=F, row.names=F, col.names=F)
  write.table(MyDataclean@gtdata@snpnames, file = paste(out.file,"_listSNPOK.txt",sep=""), 
              quote=F, row.names=F, col.names=F)
  
  if (ws.save == TRUE){
    save(list = objects(), file = paste(out.file,"_ws.RData",sep=""))
  }
  
}


