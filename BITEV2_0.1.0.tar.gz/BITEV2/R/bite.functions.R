##############################################
################# FUNCTIONS ##################
##############################################

############## FORMAT TAB ###################
printTab <- function(tmp, breaks) {
  string <- ""
  string <- paste(string, "range          value\n", sep="")
  string <- paste(string, "-------------------------\n", sep="")
  for (i in seq(1, length(tmp), 1)) {
    string <- paste(string, sprintf("%-15s", paste(breaks[i], "-", breaks[i+1], sep="")), round(tmp[i], 4), "\n", sep="") # aggiunta di sprintf per allineare i valori di breaks
  }
  string <- paste(string, "-------------------------\n", sep="")
  return(string)
}

############## CATABLE GENABEL ##############
#### summary table for quantitative data ####
catable <- function(data, categories, cumulative = F) {
  cut_var <- cut(data, breaks = categories)
  freq_table <- table(cut_var)
  if (cumulative == T) {
    cumulative_table <- cumsum(freq_table)
    return(printTab(prop.table(cumulative_table), categories))
  }
  else {
    return(printTab(prop.table(freq_table), categories))
  }
}

############## CHECK POP ORDER COLOR FILE ##############
# return popord & popcol
checkPopOrdColor <- function(pop.order.color.file, uniqpop) {
  popcol <- NULL
  if (length(pop.order.color.file) != 0){
    if (file.exists(pop.order.color.file)){
      popord<-read.table(file=pop.order.color.file, stringsAsFactors = F, comment.char = "", quote = "")

      if (ncol(popord) > 2){
        cat("The format of populations order file is not correct. Please check! \n")
        stop("Exit",call. = F)
      }else{
        if (ncol(popord) == 2){
          popcol <- popord[,2]
          cat(paste("Population order and custom colors from ",pop.order.color.file," file.\n",sep=""))
        }else{
          cat(paste("Population order from ",pop.order.color.file," file & colors are automatically assigned\n",sep=""))
        }
        popord <- popord[,1]
        if (!setequal(x = uniqpop, y = popord)){
          cat("File with population order and colors doesn't match with the population in the dataset. Please check! \n")
          stop("Exit",call. = F)
        }
      }
    }else{
      cat("Population order file not found. Please check! \n")
      stop("Exit",call. = F)
    }
  }else{
    popord <- sort(uniqpop)
    cat("Population are alphebetical ordered and colors are automatically assigned.\n")
  }
  out <- list(popord, popcol)
  names(out) <- c("popord", "popcol")
  return(out)
}

################# SET COLOR #################
setColor <- function(tmpp) {
  if (length(tmpp$popcol) == 0){
    #Mycol1<-c("red","darkblue","#e3c92e","green3","orange","purple","hotpink3","brown","gray50","blue2","darkgoldenrod3", "coral2","cornflowerblue", "darkolivegreen","cyan2", "darkgreen", "pink", "darkorange2", "deeppink", "deepskyblue", "dodgerblue2", "firebrick3", "gold", "indianred1", "khaki3", "lightsalmon", "lightslateblue", "mediumorchid1", "mediumpurple1", "royalblue1")
    # 46 principal colors from colorBlindness

    Mycol1 <- c("#004949", "#009292", "#ff6db6", "#ffb6db", "#490092", "#006ddb",
                "#b66dff", "#6db6ff", "#b6dbff", "#920000", "#924900", "#db6d00",
                "#24ff24", "#ffff6d", "#005000", "#500050", "#BBFFBB", "#FFAD72",
                "#F76D5E", "#D82632", "#264DFF", "#290AD8", "#99EAFF", "#D8152F",
                "#FFCC00", "#FF6600", "#FFFF00", "#51C3CC", "#662700", "#00CCCC",
                "#99FF99", "#6565FF", "#F2DACD", "#32E3FF", "#331900", "#996035",
                "#999999", "#FF5500", "#CCBFFF", "#6B990F", "#6551CC", "#B22C2C")

    set.seed(3)
    numcol<-length(tmpp$popord)
    Mycol2<-NULL
    for (i in 1:numcol){
      red<-toupper(as.hexmode(sample(16:255,1)))
      green<-toupper(as.hexmode(sample(16:255,1)))
      blue<-toupper(as.hexmode(sample(16:255,1)))
      Mycol2[i]<-paste("#",red,green,blue,sep="")
    }
    Mycol<-c(Mycol1,Mycol2)
    rm(Mycol1,Mycol2,red,green,blue,numcol,i)
  }else{
    Mycol <- tmpp$popcol
  }
  return(Mycol)
}

############ MAF / CRATE / HWE P for SNPs data ############
# snpStats <- function(gds.in, out.dir, nfile.snp) {
#   geno <- snpgdsGetGeno(gds.in, with.id = TRUE, verbose = 0)
#   cat("SNPs stats: running ...\n")
#   SNP<-paste(out.dir , "/SNP",sep="")
#   if (file.exists(SNP) == FALSE) {
#     dir.create(SNP)
#   } else {
#     cat(paste(basename(SNP), " directory already exists!\n", sep=""))
#   }
#
#   # maf
#   maf <- snpgdsSNPRateFreq(gds.in)
#   maf <- maf$MinorFreq
#   # crateSNP
#   valid <- apply(geno$genotype, 2, function(x) sum(!is.na(x)))
#   total <- nrow(geno$genotype)
#   crateSNP <- valid / total
#
#   # crate / maf matr
#   SNPstats <- as.data.frame(cbind(maf, crateSNP))
#   rownames(SNPstats) <- geno$snp.id
#   colnames(SNPstats) <- c("maf", "Call.rate")
#   write.table(SNPstats,file=nfile.snp, quote=F, row.names = T, sep = "\t")
#
#   # hwe p
#   SNPstats$HWE_p <- snpgdsHWE(gds.in)
#   return(SNPstats)
# }

snpStats <- function(gds.in, out.dir, nfile.snp) {
  geno <- snpgdsGetGeno(gds.in, with.id = TRUE, verbose = 0)
  cat("SNPs stats: running ...\n")
  SNP<-paste(out.dir , "/SNP",sep="")
  if (file.exists(SNP) == FALSE) {
    dir.create(SNP)
  } else {
    cat(paste(basename(SNP), " directory already exists!\n", sep=""))
  }

  # maf
  maf <- snpgdsSNPRateFreq(gds.in)
  maf <- maf$MinorFreq
  # crateSNP
  no.na.colsCount <- colSums(!is.na(geno$genotype))
  total <- nrow(geno$genotype)
  crateSNP <- no.na.colsCount / total

  # hwe p
  hwe_p <- snpgdsHWE(gds.in)

  # SNPstats
  SNPstats <- as.data.frame(cbind(maf, crateSNP, hwe_p))
  rownames(SNPstats) <- geno$snp.id
  colnames(SNPstats) <- c("maf", "Call.rate", "HWE_p")
  write.table(SNPstats,file=nfile.snp, quote=F, row.names = T, sep = "\t")

  return (SNPstats)
}


############### CRATE / HET (miss / no miss) for INDs data ###############
# idStats <- function(gds.in, out.dir, nfile.ind) {
#   geno <- snpgdsGetGeno(gds.in, with.id = TRUE, verbose = 0)
#   cat("IDs stats: running ...\n")
#   IND<-paste(out.dir,"/IND",sep="")
#   if (file.exists(IND) == FALSE) {
#     dir.create(IND)
#   } else {
#     cat(paste(basename(IND), " directory already exists!\n", sep=""))
#   }
#   # call rate
#   valid2 <- apply(geno$genotype, 1, function(x) sum(!is.na(x)))
#   total2 <- ncol(geno$genotype)
#   crateID <- valid2 / total2
#   # Het
#   different <- apply(geno$genotype, 1, function(x) sum(x == 1 & !is.na(x)))
#   total <- apply(geno$genotype,1, function(x) sum(!is.na(x)))
#   het <- different / total
#
#   # Het considering missing val
#   different2 <- apply(geno$genotype, 1, function(x) sum(x == 1 & !is.na(x)))
#   total2 <- ncol(geno$genotype)
#   hetTot <- different2 / total2
#   hetTot
#
#   IDstats <- data.frame(cbind(crateID, het, hetTot))
#   rownames(IDstats) <- geno$sample.id
#   colnames(IDstats) <- c("Call.rate", "HetObs.call", "HetObs.all")
#
#   write.table(IDstats,file=nfile.ind, quote=F, row.names = T, sep = "\t")
#
#   return (IDstats)
# }

idStats <- function(gds.in, out.dir, nfile.ind) {
  geno <- snpgdsGetGeno(gds.in, with.id = TRUE, verbose = 0)
  cat("IDs stats: running ...\n")
  IND<-paste(out.dir,"/IND",sep="")
  if (file.exists(IND) == FALSE) {
    dir.create(IND)
  } else {
    cat(paste(basename(IND), " directory already exists!\n", sep=""))
  }
  # call rate
  #valid2 <- apply(geno$genotype, 1, function(x) sum(!is.na(x)))
  no.na.rowsCount <- rowSums(!is.na(geno$genotype))
  col.num <- ncol(geno$genotype)
  crateID <- no.na.rowsCount / col.num

  # Het
  #different <- apply(geno$genotype, 1, function(x) sum(x == 1 & !is.na(x)))
  het.noNa <- rowSums(geno$genotype == 1, na.rm = TRUE)
  het <- het.noNa / no.na.rowsCount

  # Het considering missing val
  #different2 <- apply(geno$genotype, 1, function(x) sum(x == 1 & !is.na(x)))
  #total2 <- ncol(geno$genotype)
  hetTot <- het.noNa / col.num
  hetTot

  IDstats <- data.frame(cbind(crateID, het, hetTot))
  rownames(IDstats) <- geno$sample.id
  colnames(IDstats) <- c("Call.rate", "HetObs.call", "HetObs.all")

  write.table(IDstats,file=nfile.ind, quote=F, row.names = T, sep = "\t")

  return (IDstats)
}

############### MDS PLOTS ###############
mdsAnalysis <- function(mds, n.k, perctempeig, fam, ordermatrix, out.dir, filename, plotFormat) {
  # qui potrebbe non servire "fam"
  mdsMean <- aggregate(. ~ BRD, data = mds, mean)
  comb<-combn(n.k,2)
  for (i in 1:dim(comb)[2]){
    # Plot: IDs
    p <- ggplot(data=mds, aes(x=0, y=0)) +
      geom_point(aes(x=mds[, comb[1,i]],y=mds[,comb[2,i]], color=BRD, shape=BRD)) +
      scale_shape_manual(values = ordermatrix$V3) +
      labs(x=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
           y=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
           title="MultiDimensional Scaling") +
      geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
      geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
      scale_color_manual(values = ordermatrix$V2) +
      theme_bw() +
      if (length(ordermatrix[,1]) > 54) {
        theme(axis.text.x = element_blank(), legend.position = "none")
      } else {
        theme(axis.text.x = element_blank())
      }
    ggsave(paste(out.dir,"/MDS/",filename,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],".", plotFormat,sep=""), width = 12, height = 9)
  }

  for (i in 1:dim(comb)[2]){
    # Plot: ID pop
    p <- ggplot(mdsMean, aes(x = mdsMean[, (paste("V", comb[1,i], sep=""))], y = mdsMean[, (paste("V", comb[2,i], sep=""))], color=BRD, label = BRD))+
      geom_text(size=4, show.legend = FALSE) +
      scale_color_manual(values = ordermatrix$V2) +
      labs(x=paste("Pcs ",comb[1,i]," (", round(perctempeig[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
           y=paste("Pcs ",comb[2,i]," (", round(perctempeig[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
           title="MultiDimensional Scaling") +
      geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
      geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
      theme_bw()
    ggsave(paste(out.dir,"/MDS/",filename,"_MDS_PC_",comb[1,i],"-vs-",comb[2,i],"_pop.", plotFormat,sep=""), width = 12, height = 9)
  }


  # MDS ELLIPSES
  colNam <- colnames(mds)
  colNam <- head(colNam, -1)
  comb <- combn(colNam, 2)
  for (i in 1:dim(comb)[2]) {
    labx <- substr(comb[1,i], 2, nchar(comb[1,i]))
    laby <- substr(comb[2,i], 2, nchar(comb[2,i]))

    # check errors
    possibleError <- tryCatch({
      ggplot(data = mds, aes(x=mds[,comb[1,i]], y=mds[,comb[2,i]], color=BRD)) +
        stat_ellipse(level=0.95) +
        geom_point(data = mdsMean, aes(x=mdsMean[,comb[1,i]], y=mdsMean[,comb[2,i]], color=BRD)) +
        theme_bw()
    },
    error=function(e) e)

    if(!inherits(possibleError, "error")){
      p <- ggplot(data = mds, aes(x=mds[,comb[1,i]], y=mds[,comb[2,i]], color=BRD)) +
        stat_ellipse(level=0.95) +
        geom_point(data = mdsMean, aes(x=mdsMean[,comb[1,i]], y=mdsMean[,comb[2,i]], color=BRD, shape=BRD)) +
        scale_shape_manual(values = ordermatrix$V3) +
        geom_text_repel(data = mdsMean, aes(x=mdsMean[,comb[1,i]], y=mdsMean[,comb[2,i]], label=BRD)) +
        scale_color_manual(values = ordermatrix$V2) +
        labs(x=paste("Pcs ",labx," (", round(perctempeig[as.numeric(labx)], digits=2), "%)", sep=""),
             y=paste("Pcs ",laby," (", round(perctempeig[as.numeric(laby)], digits=2), "%)", sep=""),
             title="MultiDimensional Scaling") +
        geom_hline(yintercept = 0, color = "grey", size = 0.5) +
        geom_vline(xintercept = 0, color = "grey", size = 0.5) +
        theme_bw() +
        theme(legend.position = "none")
      ggsave(paste(out.dir,"/MDS/",filename,"_MDS_PC_",labx,"-vs-",laby,"_popCI.", plotFormat,sep=""), width = 24, height = 18)
    } else {
      # If dataset complete doesn't work remove breed with low number of animals
      tableMds<-table(mds[,"BRD"])
      for (minnum in c(2:50)){
        tormv <- as.vector(names(tableMds)[which(tableMds<=minnum)])
        tmp.MyData.mds <- mds[-(which(mds[,"BRD"] %in% tormv)),]
        tmp.ordermatrix <-  ordermatrix[-(which(ordermatrix[,1] %in% tormv)),]
        tmp.mdsMean <- mdsMean[-(which(mdsMean[,"BRD"] %in% tormv)),]

        possibleError <- tryCatch({
          ggplot(data = tmp.MyData.mds, aes(x=tmp.MyData.mds[,comb[1,i]], y=tmp.MyData.mds[,comb[2,i]], color=BRD)) +
            stat_ellipse(level=0.95) +
            geom_point(data = tmp.mdsMean, aes(x=tmp.mdsMean[,comb[1,i]], y=tmp.mdsMean[,comb[2,i]], color=BRD)) +
            theme_bw()},
          error=function(e) e)
        if(!inherits(possibleError, "error")){
          p <- ggplot(data = tmp.MyData.mds, aes(x=tmp.MyData.mds[,comb[1,i]], y=tmp.MyData.mds[,comb[2,i]], color=BRD)) +
            stat_ellipse(level=0.95) +
            geom_point(data = tmp.mdsMean, aes(x=tmp.mdsMean[,comb[1,i]], y=tmp.mdsMean[,comb[2,i]], color=BRD, shape=BRD)) +
            scale_shape_manual(values=ordermatrix$V3) +
            geom_text_repel(data = tmp.mdsMean, aes(x=tmp.mdsMean[,comb[1,i]], y=tmp.mdsMean[,comb[2,i]], label=BRD)) +
            scale_color_manual(values = tmp.ordermatrix$V2) +
            labs(x=paste("Pcs ",labx," (", round(perctempeig[as.numeric(labx)], digits=2), "%)", sep=""),
                 y=paste("Pcs ",laby," (", round(perctempeig[as.numeric(laby)], digits=2), "%)", sep=""),
                 title="MultiDimensional Scaling") +
            geom_hline(yintercept = 0, color = "grey", size = 0.5) +
            geom_vline(xintercept = 0, color = "grey", size = 0.5) +
            theme_bw() +
            theme(legend.position = "none")
          ggsave(paste(out.dir,"/MDS/",filename,"_MDS_PC_",labx,"-vs-",laby,"_popCI.", plotFormat,sep=""), width = 24, height = 18)
          break
        }else{
          if (minnum == 50){
            sink(file=logname, append=T)
            cat("\nIt's not possible create an MDS with ellipse with this PCs combination \n")
            print(possibleError,"\n")
            sink()
          }
        }
      }
    }
  }
}


pcaAnalysis <- function(tab, n.k, pc.percent, fam, ordermatrix, out.dir, filename, plotFormat) {
  # qui potrebbe non servire fam
  newTab <- tab[, 1:n.k]
  colnames(newTab) <- paste("PC", 1:n.k, sep="")
  newTab$BRD <- tab$pop
  comb<-combn(n.k,2)


  for (i in 1:dim(comb)[2]){
    # Plot: IDs
    p <- ggplot(data=newTab, aes(x=0, y=0)) +
      geom_point(aes(x=newTab[, comb[1, i]],y=newTab[,comb[2,i]], color=BRD, shape=BRD)) +
      scale_shape_manual(values=ordermatrix$V3) +
      labs(x=paste("Pcs ",comb[1,i]," (", round(pc.percent[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
           y=paste("Pcs ",comb[2,i]," (", round(pc.percent[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
           title="Principal Component Analysis") +
      geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
      geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
      scale_color_manual(values = ordermatrix$V2) +
      theme_bw() +
      if (length(ordermatrix[,1]) > 54) {
        theme(axis.text.x = element_blank(), legend.position = "none")
      } else {
        theme(axis.text.x = element_blank())
      }
    ggsave(paste(out.dir,"/PCA/",filename,"_PCA_PC_",comb[1,i],"-vs-",comb[2,i],".", plotFormat,sep=""), width = 12, height = 9)
  }


  pcaMean <- aggregate(. ~ BRD, data = newTab, mean)
  pcaMean <- pcaMean %>% relocate(BRD, .after = last_col())

  for (i in 1:dim(comb)[2]){
    # Plot: ID pop
    p <- ggplot(pcaMean, aes(x = pcaMean[, comb[1,i]], y = pcaMean[, comb[2,i]], color=BRD, label = BRD))+
      geom_text(size=4, show.legend = FALSE) +
      scale_color_manual(values = ordermatrix$V2) +
      labs(x=paste("Pcs ",comb[1,i]," (", round(pc.percent[as.numeric(comb[1,i])], digits=2), "%)", sep=""),
           y=paste("Pcs ",comb[2,i]," (", round(pc.percent[as.numeric(comb[2,i])], digits=2), "%)", sep=""),
           title="Principal Component Analysis") +
      geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +
      geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +
      theme_bw()
    ggsave(paste(out.dir,"/PCA/",filename,"_PCA_PC_",comb[1,i],"-vs-",comb[2,i],"_pop.", plotFormat,sep=""), width = 12, height = 9)

  }

  # PCA ELLIPSES
  colNam <- colnames(newTab)
  colNam <- head(colNam, -1)
  comb <- combn(colNam, 2)

  for (i in 1:dim(comb)[2]) {
    labx <- substr(comb[1,i], 3, nchar(comb[1,i]))
    laby <- substr(comb[2,i], 3, nchar(comb[2,i]))

    # check errors
    possibleError <- tryCatch({
      ggplot(data = newTab, aes(x=newTab[,comb[1,i]], y=newTab[,comb[2,i]], color=BRD)) +
        stat_ellipse(level=0.95) +
        geom_point(data = pcaMean, aes(x=pcaMean[,comb[1,i]], y=pcaMean[,comb[2,i]], color=BRD)) +
        theme_bw()
    },
    error=function(e) e)

    if(!inherits(possibleError, "error")){
      p <- ggplot(data = newTab, aes(x=newTab[,comb[1,i]], y=newTab[,comb[2,i]], color=BRD)) +
        stat_ellipse(level=0.95) +
        geom_point(data = pcaMean, aes(x=pcaMean[,comb[1,i]], y=pcaMean[,comb[2,i]], color=BRD, shape=BRD)) +
        scale_shape_manual(values = ordermatrix$V3) +
        geom_text_repel(data = pcaMean, aes(x=pcaMean[,comb[1,i]], y=pcaMean[,comb[2,i]], label=BRD)) +
        scale_color_manual(values = ordermatrix$V2) +
        labs(x=paste("Pcs ",labx," (", round(pc.percent[as.numeric(labx)], digits=2), "%)", sep=""),
             y=paste("Pcs ",laby," (", round(pc.percent[as.numeric(laby)], digits=2), "%)", sep=""),
             title="Principal Component Analysis") +
        geom_hline(yintercept = 0, color = "grey", size = 0.5) +
        geom_vline(xintercept = 0, color = "grey", size = 0.5) +
        theme_bw() +
        theme(legend.position = "none")
      ggsave(paste(out.dir,"/PCA/",filename,"_PCA_PC_",labx,"-vs-",laby,"_popCI.", plotFormat,sep=""), width = 24, height = 18)
    } else {
      # If dataset complete doesn't work remove breed with low number of animals
      tablePca<-table(newTab[,"BRD"])
      for (minnum in c(2:50)){
        tormv <- as.vector(names(tablePca)[which(tablePca<=minnum)])
        tmp.MyData.pca <- newTab[-(which(newTab[,"BRD"] %in% tormv)),]
        tmp.ordermatrix <-  ordermatrix[-(which(ordermatrix[,1] %in% tormv)),]
        tmp.pcaMean <- pcaMean[-(which(pcaMean[,"BRD"] %in% tormv)),]

        possibleError <- tryCatch({
          ggplot(data = tmp.MyData.pca, aes(x=tmp.MyData.pca[,comb[1,i]], y=tmp.MyData.pca[,comb[2,i]], color=BRD)) +
            stat_ellipse(level=0.95) +
            geom_point(data = tmp.pcaMean, aes(x=tmp.pcaMean[,comb[1,i]], y=tmp.pcaMean[,comb[2,i]], color=BRD)) +
            theme_bw()},
          error=function(e) e)
        if(!inherits(possibleError, "error")){
          p <- ggplot(data = tmp.MyData.pca, aes(x=tmp.MyData.pca[,comb[1,i]], y=tmp.MyData.pca[,comb[2,i]], color=BRD)) +
            stat_ellipse(level=0.95) +
            geom_point(data = tmp.pcaMean, aes(x=tmp.pcaMean[,comb[1,i]], y=tmp.pcaMean[,comb[2,i]], color=BRD, shape=BRD)) +
            scale_shape_manual(values=ordermatrix$V3) +
            geom_text_repel(data = tmp.pcaMean, aes(x=tmp.pcaMean[,comb[1,i]], y=tmp.pcaMean[,comb[2,i]], label=BRD)) +
            scale_color_manual(values = tmp.ordermatrix$V2) +
            labs(x=paste("Pcs ",labx," (", round(pc.percent[as.numeric(labx)], digits=2), "%)", sep=""),
                 y=paste("Pcs ",laby," (", round(pc.percent[as.numeric(laby)], digits=2), "%)", sep=""),
                 title="Principal Component Analysis") +
            geom_hline(yintercept = 0, color = "grey", size = 0.5) +
            geom_vline(xintercept = 0, color = "grey", size = 0.5) +
            theme_bw() +
            theme(legend.position = "none")
          ggsave(paste(out.dir,"/PCA/",filename,"_PCA_PC_",labx,"-vs-",laby,"_popCI.", plotFormat,sep=""), width = 24, height = 18)
          break
        }else{
          if (minnum == 50){
            sink(file=logname, append=T)
            cat("\nIt's not possible create an PCA with ellipse with this PCs combination \n")
            print(possibleError,"\n")
            sink()
          }
        }
      }
    }
  }
}

################# MEAN IMPUTATION #################
# Mean imputation of missing data
meanImputation <- function(geno) {
  to_rm <- c()
  n <- ncol(geno)
  for (i in 1:n) {
    if (all(is.na(geno[,i])) == TRUE) {
      to_rm <- c(to_rm, i)
    }
    # get the current col
    column_i <- geno[,i]
    # get the mean of the current col
    mean_i <- mean(column_i, na.rm=T)
    # get the NA in the current col
    NAs_i <- which(is.na(column_i))
    # replace the NAs in the current col
    column_i[NAs_i] <- mean_i
    # replace the original col
    geno[,i] <- column_i
  }

  if (length(to_rm) != 0) {
    geno <- geno[,-to_rm]
    cat("Several columns contain only NA values. Removed\n")
  }
  return(geno)
}

################# EXPLAINED VARIATION #################
# return explained variation
varPCA <- function(PCAsumm) {
  varExp <- PCAsumm$importance[2,]*100
  varExp <- round(varExp,2)
  return(varExp)
}

################# CHOOSE LOAD OR RECREATE GDS #################
interactiveGDS <- function(gds.out) {
  # return basic info
  temp <- snpgdsOpen(gds.out, readonly = FALSE, allow.duplicate = TRUE)
  cat(paste(basename(temp$filename), " already exists!\n", sep=""))
  cat("***********************\n")
  sam <- length(read.gdsn(index.gdsn(temp, "sample.id")))
  sn <- length(read.gdsn(index.gdsn(temp, "snp.id")))
  cat(paste(sam, " samples x ", sn, " SNPs\n", sep=""))
  ordmatr <- read.gdsn(index.gdsn(temp, "ordermatrix"))
  cat("pop:", ordmatr$V1)
  cat("\n***********************\n")
  cat("Select an option: \n")
  cat(paste("1: Load ", basename(temp$filename), "\n", sep=""))
  cat(paste("2: Delete ", basename(temp$filename), " and recreate a new gds\n", sep=""))
  choice <- readline()
  showfile.gds(closeall=TRUE, verbose = FALSE)
  return (choice)
}

########## UPDATE GDS FILE ##########
update.gds <- function(new.gds.in, sample.id = NULL, snp.chromosome = NULL, snp.id = NULL,
                       snp.position = NULL, snp.allele = NULL, genotype = NULL, phenotype = NULL, ordermatrix = NULL) {

  if (!is.null(sample.id)) {
    add.gdsn(new.gds.in, "sample.id", sample.id, replace = TRUE, check = TRUE)
  }

  if (!is.null(snp.chromosome)) {
    # take snp.chromosome attr
    attr.tmp <- get.attr.gdsn(index.gdsn(new.gds.in, "snp.chromosome"))

    add.gdsn(new.gds.in, "snp.chromosome", snp.chromosome, replace=TRUE, compress = "LZMA_RA", check = TRUE)

    # get snp.chromosome index
    attr.tmp.index <- index.gdsn(new.gds.in, "snp.chromosome")
    # put attr
    put.attr.gdsn(attr.tmp.index, "autosome.start", attr.tmp$autosome.start)
    put.attr.gdsn(attr.tmp.index, "autosome.end", attr.tmp$autosome.end)
    put.attr.gdsn(attr.tmp.index, "X", attr.tmp$X)
    put.attr.gdsn(attr.tmp.index, "Y", attr.tmp$Y)
    put.attr.gdsn(attr.tmp.index, "XY", attr.tmp$XY)
    put.attr.gdsn(attr.tmp.index, "MT", attr.tmp$MT)
    put.attr.gdsn(attr.tmp.index, "M", attr.tmp$M)
  }

  if (!is.null(snp.id)) {
    add.gdsn(new.gds.in, "snp.id", snp.id, replace=TRUE, compress = "LZMA_RA", closezip = TRUE)
  }

  if (!is.null(snp.position)) {
    add.gdsn(new.gds.in, "snp.position", snp.position, replace=TRUE, compress = "LZMA_RA", closezip = TRUE)
  }

  if (!is.null(snp.allele)) {
    add.gdsn(new.gds.in, "snp.allele", snp.allele, replace=TRUE, compress = "LZMA_RA", closezip = TRUE)
  }

  if (!is.null(genotype)) {
    # update genotype
    genotype <- replace(genotype, is.na(genotype), 3)
    add.gdsn(new.gds.in, "genotype", genotype, replace = TRUE, storage = "bit2", check = TRUE)
    ### necessario per consentire apertura gds se già esiste ###
    eggs <- index.gdsn(new.gds.in, "genotype")
    put.attr.gdsn(eggs, "sample.order", val=NULL)
  }

  if (!is.null(phenotype)) {
    add.gdsn(new.gds.in, "phenotype", phenotype, replace = TRUE, closezip = TRUE)
    sample.annot <- phenotype[,c(-2,-1)]
    add.gdsn(new.gds.in, "sample.annot", sample.annot, replace = TRUE, compress = "LZMA_RA", closezip = TRUE)
  }

  if (!is.null(ordermatrix)) {
    add.gdsn(new.gds.in, "ordermatrix", ordermatrix, replace = TRUE, closezip = TRUE)
  }
}


########## SNP CALLRATE FILTERING ##########
snp.callrate.filtering <- function(genotype, snp.id, snp.callrate, output) {

  # calculate call rate
  valid <- apply(genotype, 2, function(x) sum(!is.na(x)))
  total <- nrow(genotype)
  crateSNP <- valid / total
  snp.crate <- data.frame(snp.id, crateSNP)

  # to_rm
  snp.cr.ok <- snp.crate[crateSNP >= snp.callrate, ]
  snp.cr.notok <- snp.crate[crateSNP < snp.callrate, ]

  # report
  cat("*** Missingness of SNPs ***\n")
  cat(paste("SNP ok: ", length(snp.cr.ok$snp.id), "\n", "SNP not ok: ",
            length(snp.cr.notok$snp.id), "\nTotal: ", length(snp.id), "\n", sep=""))
  cat("***************************\n")

  # txt with snp.cr.notok
  write.table(snp.cr.notok, file=paste(output, "/snp.cr.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
  # txt with snp.cr.ok
  write.table(snp.cr.ok, file=paste(output, "/snp.cr.ok.txt", sep=""), col.names = TRUE, quote=FALSE)

  return (snp.cr.notok)
}


########## SNP MAF FILTERING ##########
snp.maf.filtering <- function(new.gds.in, snp.id, maf, output, sample.id) {

  # calculate maf
  mafSNP <- snpgdsSNPRateFreq(new.gds.in, snp.id = snp.id, sample.id)
  mafSNP <- mafSNP$MinorFreq
  snp.maf <- data.frame(snp.id, mafSNP)

  # to_rm
  snp.maf.ok <- snp.maf[mafSNP >= maf, ]
  snp.maf.notok <- snp.maf[mafSNP < maf, ]

  # report
  cat("*** MAF treshold ***\n")
  cat(paste("SNPs ok: ", length(snp.maf.ok$snp.id), "\n", "SNPs not ok: ",
            length(snp.maf.notok$snp.id), "\nTotal: ", length(snp.id), "\n", sep=""))
  cat("********************\n")

  # txt with snp.cr.notok
  write.table(snp.maf.notok, file=paste(output, "/snp.maf.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
  # txt with snp.cr.ok
  write.table(snp.maf.ok, file=paste(output, "/snp.maf.ok.txt", sep=""), col.names = TRUE, quote=FALSE)

  return (snp.maf.notok)
}

########## SNP HWE FILTERING ##########
snp.hwe.filtering <- function(new.gds.in, snp.id, hwe.p, output, sample.id) {

  # calculate hwe
  hweSNP <- snpgdsHWE(new.gds.in, snp.id = snp.id, sample.id)

  snp.hwe <- data.frame(snp.id, hweSNP)

  # to_rm
  snp.hwe.ok <- snp.hwe[hweSNP >= hwe.p, ]
  snp.hwe.notok <- snp.hwe[hweSNP < hwe.p, ]

  # report
  cat("*** HWE treshold ***\n")
  cat(paste("SNPs ok: ", length(snp.hwe.ok$snp.id), "\n", "SNPs not ok: ",
            length(snp.hwe.notok$snp.id), "\nTotal: ", length(snp.id), "\n", sep=""))
  cat("********************\n")

  # txt with snp.cr.notok
  write.table(snp.hwe.notok, file=paste(output, "/snp.hwe.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
  # txt with snp.cr.ok
  write.table(snp.hwe.ok, file=paste(output, "/snp.hwe.ok.txt", sep=""), col.names = TRUE, quote=FALSE)

  return (snp.hwe.notok)
}

########## IND CALLRATE FILTERING ##########
ind.callrate.filtering <- function(genotype, sample.id, ind.callrate, output) {

  # call rate
  valid<- apply(genotype, 1, function(x) sum(!is.na(x)))
  total <- ncol(genotype)
  crateID <- valid / total
  ind.crate <- data.frame(sample.id, crateID)

  # to_rm
  ind.cr.ok <- ind.crate[crateID >= ind.callrate, ]
  ind.cr.notok <- ind.crate[crateID < ind.callrate, ]

  # report
  cat("*** Missingness of INDs ***\n")
  cat(paste("IND ok: ", length(ind.cr.ok$sample.id), "\n", "IND not ok: ",
            length(ind.cr.notok$sample.id), "\nTotal: ", length(sample.id), "\n", sep=""))
  cat("***************************\n")

  # txt with ind.cr.notok
  write.table(ind.cr.notok, file=paste(output, "/ind.cr.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
  # txt with ind.cr.ok
  write.table(ind.cr.ok, file=paste(output, "/ind.cr.ok.txt", sep=""), col.names = TRUE, quote=FALSE)

  return (ind.cr.notok)
}

########## IND HET FILTERING ##########
ind.het.filtering <- function(genotype, HetObs.all, sample.id, het.min, het.max, output) {
  # calculate het level (considering missing val)
  diff <- apply(genotype, 1, function(x) sum(x == 1 & !is.na(x)))

  # check HetObs.all val
  if (HetObs.all == FALSE) {
    total <- apply(genotype, 1, function(x) sum(!is.na(x)))
  } else if (HetObs.all == TRUE) {
    total <- ncol(genotype)
  }

  het.level <- diff / total
  ind.het <- data.frame(sample.id, het.level)

  # het.min & het.max == default
  if (het.min == "default" & het.max == "default") {
    # mean
    het.mean <- mean(het.level)
    # sd
    het.sd <- sd(het.level)
    # calculate het.min & het.max
    het.min <- as.numeric(het.mean - 3*het.sd)
    het.max <- as.numeric(het.mean + 3*het.sd)
  }

  # check het values
  pos_to_rm <- vector()
  for (i in 1:length(ind.het$sample.id)) {
    tmp <- ind.het$het.level[i]
    if (tmp < het.min | tmp > 0.45) {
      pos_to_rm <- c(pos_to_rm, i)
    }
  }

  # ind.het.ok
  if (length(pos_to_rm) == 0) {
    ind.het.ok <- ind.het
    ind.het.notok <- NULL
  } else {
    ind.het.ok <- ind.het[-pos_to_rm, ]
    ind.het.notok <- ind.het[pos_to_rm, ]
  }

  # report
  cat("*** Het Threshold ***\n")
  cat(paste("IND ok: ", length(ind.het.ok$sample.id), "\n", "IND not ok: ",
            length(ind.het.notok$sample.id), "\nTotal: ", length(ind.het$sample.id), "\n", sep=""))
  cat("***************************\n")

  # write.table
  write.table(ind.het.ok, file=paste(output, "/ind.het.ok.txt", sep=""), col.names = TRUE, quote=FALSE)
  write.table(ind.het.notok, file=paste(output, "/ind.het.notok.txt", sep=""), col.names = TRUE, quote=FALSE)

  return (ind.het.notok)
}


















