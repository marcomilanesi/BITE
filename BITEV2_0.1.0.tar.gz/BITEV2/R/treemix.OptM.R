




################################################################################
################################ TREEMIX OPTM ##################################
################################################################################


##### OptM: treemix best m #####

# folder: path della cartella con gli output di Treemix.
# method: metodo a scelta fra "Evanno", "linear", or "SiZer"
# name: nome dei file di output (*.tsv con i valori e *.pdf con i grafici)

#N.B: funziona solo se nella cartella c'è più di una iterazione per ogni m.
# https://cran.r-project.org/web/packages/OptM/OptM.pdf


treemix.OptM <- function(in.dir, method, out.name = "treemix_OptM_plot") {
  test.optM <- optM(folder = in.dir, method = method, tsv = paste(out.name, ".tsv", sep = ""))
  plot_optM(test.optM, method = method, plot = TRUE, paste(out.name, ".pdf", sep = ""))
}

















