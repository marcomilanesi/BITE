


################################################################################
########################### BITE SUPERVISED PCA ################################
################################################################################

source("R/bite.functions.R", local = TRUE)

bite.supervisedPCA <- function(gds.path, out.dir, outID = NULL, outPop = NULL, snp.random.subset = NULL, ...) {

  ### GDS in
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  ##### CHECK SNP.RANDOM.SUBSET #####
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.num <- length(snp.id)
  sample.num <- length(sample.id)

  if (is.null(snp.random.subset)) {

    # check num of snps
    if (snp.num >= 200000 & sample.num >= 500) {
      # warning message
      cat(paste("Warning: ", basename(gds.in$filename), " contains ", snp.num, " snps & ", sample.num, " individuals.\n", sep=""))
      cat("Bite.supervisedPCA() may take a long time.\nConsider the idea of using only a random subset of snps for PCA analysis:\n")
      cat("- Yes (1)\n")
      cat("- No (2)\n")

      choice <- readline()

      if (choice == 1) {
        cat("Enter the number of snps to consider: ")
        snp.random.subset <- readline()
        snp.random.subset <- as.numeric(snp.random.subset)

        if (snp.random.subset >= snp.num || snp.random.subset <= 0) {
          cat("Invalid value!\n")
          stop("Exit", call.=F)
        }
      } else if (choice == 2) {
        snp.random.subset <- snp.num
      } else {
        cat("Invalid selection .... \n")
        stop("Exit", call.=F)
      }
    }
  }

  if (snp.random.subset == snp.num || is.null(snp.random.subset)) {
    snp.sample <- snp.id
  } else {
    snp.sample <- sample(snp.id, snp.random.subset, replace = F)
  }

  ##### CHECK OUTID & OUTPOP #####
  if (is.null(outID) && is.null(outPop)) {
    cat("Please add one of the two fields\n")
    stop("Exit", call.=F) }
  if(!is.null(outID) && !is.null(outPop)) {
    cat("Please only one of the two fields\n")
    stop("Exit", call.=F)
  }

  cat("Running .....\n")

  ##### FILENAME #####
  filename <- str_sub(basename(gds.in$filename), start = 1, end=-5)

  ##### OUT.DIR #####
  out <- paste(out.dir, "/supervisedPCA_", filename, sep="")
  dir.create(out)

  ##### EXTRACT GENO/PHENO/PLOTINFO #####
  genoAll <- snpgdsGetGeno(gds.in, verbose = FALSE, snp.id = snp.sample)
  phenoAll <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))

  ##### IMPUTE GENO MISSINGVAL #####
  NaCount <- sum(is.na(genoAll))
  if (NaCount != 0) {
    genoAll <- meanImputation(genoAll)
  }

  ##### CHECK CONTENT OF OUTID OR OUTPOP #####
  if (!is.null(outID)) {
    # check if 1/more exists
    if (length(outID) != 1) {
      check <- TRUE
      for (i in range(1, length(outID))) {
        if (!(outID[i] %in% phenoAll$id)){
          check <- FALSE
        }
      }
      if (check == FALSE) {
        cat("IDs not in gds.in\n")
        stop("Exit", call. = FALSE)
      }
    } else {
      if (!(outID %in% phenoAll$id))
      {
        cat("ID not in gds.in\n")
        stop("Exit", call.=FALSE)
      }
    }
    # to_rm list
    to_rm <- list()
    to_rm$torm <- outID
    to_rm$type <- "id"
    to_rm$index <- which(phenoAll$id %in% to_rm$torm)

  } else if (!is.null(outPop)) {
    # check if 1/more exists
    if (length(outPop) != 1) {
      check <- TRUE
      for (i in range(1, length(outPop))) {
        if (!(outPop[i] %in% phenoAll$pop)){
          check <- FALSE
        }
      }
      if (check == FALSE) {
        cat("POPs not in gds.in\n")
        stop("Exit", call. = FALSE)
      }
    } else {
      # se è una stringa controlla che il singolo valore sia contenuto in pheno
      if (!(outPop %in% phenoAll$pop))
      {
        cat("POP not in gds.in\n")
        stop("Exit", call.=FALSE)
      }
    }

    # to_rm list
    to_rm <- list()
    to_rm$torm <- outPop
    to_rm$type <- "pop"
    to_rm$index <- which(phenoAll$pop %in% to_rm$torm)
  }

  ##### REMOVE POP / ID #####
  if (to_rm$type == "id") {
    boolCond <- !phenoAll$id %in% to_rm$torm
    phenoNoOut <- phenoAll[boolCond, ]
    genoNoOut <- genoAll[boolCond, ]
    ordermatrixNoOut <- ordermatrix
  } else if (to_rm$type == "pop") {
    boolCond <- !phenoAll$pop %in% to_rm$torm
    phenoNoOut <- phenoAll[boolCond, ]
    genoNoOut <- genoAll[boolCond, ]
    ordermatrixNoOut <- ordermatrix[!ordermatrix$V1 %in% to_rm$torm, ]
  }

  ##### UNSUPERVISED PCA #####
  pca.NoOut = prcomp(genoNoOut)

  # tab
  tab <- as.data.frame(pca.NoOut$x[,1:2])
  tab$pop <- phenoNoOut$pop

  # var exp
  pcperc.NoOut <- varPCA(summary(pca.NoOut))

  # plot
  ggplot(tab, aes(x=0, y=0)) +
    geom_point(aes(x=PC1, y=PC2, color=pop, shape=pop)) +
    scale_shape_manual(values=ordermatrixNoOut$V3) +
    labs(x=paste("PC1 "," (", round(pcperc.NoOut[1], digits=2), "%)", sep=""),
         y=paste("PC2 "," (", round(pcperc.NoOut[2], digits=2), "%)", sep=""),
         title="Principal Component Analysis") +
    scale_color_manual(values = ordermatrixNoOut$V2) +
    theme_bw() +
    if (length(ordermatrixNoOut[,1]) > 54) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }
  ggsave(paste(out,"/", filename,"_PCA_PC1_vs_PC2.pdf", sep=""), width = 12, height = 9)

  ##### SUPERVISED PCA #####
  pca.supervised = predict(pca.NoOut, genoAll)


  # newTab
  newTab <- as.data.frame(pca.supervised[,1:2])
  newTab$pop <- phenoAll$pop

  # outliers flag
  newTab$flag <- "normal"
  newTab$flag[to_rm$index] <- "outlier"

  # standard plot
  ggplot(newTab, aes(x=0, y=0)) +
    geom_point(aes(x=PC1, y=PC2, color=pop, shape=pop)) +
    scale_shape_manual(values=ordermatrix$V3) +
    labs(x=paste("SPC1 "," (", round(pcperc.NoOut[1], digits=2), "%)", sep=""),
         y=paste("SPC2 "," (", round(pcperc.NoOut[2], digits=2), "%)", sep=""),
         title="Supervised Principal Component Analysis") +
    scale_color_manual(values = ordermatrix$V2) +
    theme_bw() +
    if (length(ordermatrix[,1]) > 54) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }
  ggsave(paste(out, "/", filename,"_supervisedPCA_PC1_vs_PC2.pdf", sep=""), width = 12, height = 9)

  # outlier / normal plot
  ggplot(newTab, aes(x=0, y=0)) +
  geom_point(aes(x=PC1, y=PC2, color=flag, shape=pop)) +
  scale_color_manual(values=c("#006ddb", "#D8152F")) +
  scale_shape_manual(values = ordermatrix$V3) +
  labs(x=paste("SPC1 "," (", round(pcperc.NoOut[1], digits=2), "%)", sep=""),
       y=paste("SPC2 "," (", round(pcperc.NoOut[2], digits=2), "%)", sep=""),
       title="Supervised Principal Component Analysis") +
  theme_bw() +
  guides(shape = FALSE)
  ggsave(paste(out, "/", filename,"_outliers_supervisedPCA_PC1_vs_PC2.pdf", sep=""), width = 12, height = 9)

  ##### BREED CODE ######
  pdf(paste(out,"/",filename,"_PopCode.pdf",sep=""))
  tmp <- ceiling(sqrt(length(ordermatrix[,1])))
  plot(0,0,type="n",xlim=c(0,tmp*7), ylim=c(0,tmp*7),yaxt="n", xaxt="n", frame.plot=F, xlab="", ylab="")
  legend(0,tmp*7,ordermatrix[,1], ncol=floor(tmp/2), col=ordermatrix[,2], lty=0,pch=as.numeric(ordermatrix[,3]), cex=0.75)
  garbage <- dev.off()
}






