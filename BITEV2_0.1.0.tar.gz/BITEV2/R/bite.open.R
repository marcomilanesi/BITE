
options(stringsAsFactors = FALSE)
################################################################################
################################### BITE OPEN ##################################
################################################################################



bite.open <- function(in.file, out.dir, gds.out = NULL, pheno.file = NULL, pop.order.color.file = NULL, open.option=FALSE, num_autosomes = 22, ...) {

  options(warn=-1)
  cat("Running.....\n")
  start <- proc.time()
  if (is.null(gds.out)) {
    logname <- "open_tmp.log"
  } else {
    logname <- paste("open_", str_sub(gds.out, start=1, end=-5), ".log", sep="")
  }
  ##### OUT DIR & LOG FILE #####
  if (!file.exists(out.dir)) {
    dir.create(out.dir)
  }
  setwd(out.dir)
  sink(file=logname)
  cat("**************** BITE.OPEN ****************\n")
  cat(date(), "\n")
  cat(paste("Output dir: ", out.dir, "\n", sep=""))
  sink()
  ##### CLOSE GDS FILES #####
  showfile.gds(closeall=TRUE, verbose = FALSE)

  #########################
  ##### CHECK IN.FILE #####
  #########################

  if (is.character(in.file) == TRUE && length(in.file) > 1) {
    check <- TRUE
    for (i in in.file) {
      f <- str_sub(i, start=-4)
      indir <- dirname(i)
      if (f == ".vcf") {
        if (!file.exists(i)) {
          check <- FALSE
        }
      }
    }
    if (check==FALSE) {
      cat("Not .vcf files")
      stop("Exit", call.=F)
    }

    ##### VCF FILES #####
    sink(file=logname, append=T)
    cat("VCF files: \n")
    sink()
    for (i in in.file) {
      sink(file=logname, append=T)
      cat(basename(i))
      cat("\n")
      sink()

      ##### CHECK CHROM #####
      chrom.col <- fread(i, skip = "#CHROM", select = 1)
      # unique.chr val
      unique.chr <- unique(chrom.col)
      # convert in numeric val
      unique.chr <- as.numeric(unique.chr)
      # check NA
      if (NA %in% unique.chr) {
        cat("Non-numerical chromosomes were detected!\nPlease convert X, Y, XY, MT, M chromosomes to numerical values\n")
        stop("Exit", call. = F)
      }
    }

    ##### CHECK PHENO.FILE #####
    sink(file=logname, append=T)
    if (is.null(pheno.file)) {
      cat("Pheno.file not found .... \n")
      stop("Exit", call.=F)
    }
    cat(paste("Pheno.file: ", basename(pheno.file), "\n", sep=""))
    sink()
    ##### CHECK AND CREATE GDS FILE #####
    if (is.null(gds.out)) {
      gds.out <- "tmp.gds"
    }
    if (file.exists(gds.out)) {
      if (open.option == 1) {
        choice <- 1
      } else if (open.option == 2) {
        choice <- 2
      } else if (open.option == FALSE) {
        choice <- as.numeric(interactiveGDS(gds.out))
      } else {
        cat("Invalid open.option ....\n")
        stop("Exit", call. = FALSE)
      }
      if (choice == 1) {
        sink(file=logname, append=T)
        cat("Load existing gds file\n")
        cat(paste("GDS file: ", gds.out, "\n", sep=""))
        sink()
        genofile <- snpgdsOpen(gds.out, readonly = FALSE, allow.duplicate = TRUE)
      } else if (choice == 2) {
        file.remove(gds.out)
        sink(file=logname, append=T)
        cat("Remove existing gds file and reopen\n")
        cat(paste("GDS file: ", gds.out, "\n", sep=""))
        sink()
        snpgdsVCF2GDS(in.file, gds.out, method = "biallelic.only", verbose = FALSE)
        genofile <- snpgdsOpen(gds.out, readonly = FALSE)
      } else {
        cat("Invalid selection ....\n")
        stop("Exit", call. = F)
      }

    } else {
      snpgdsVCF2GDS(in.file, gds.out, method = "biallelic.only", verbose = FALSE)
      genofile <- snpgdsOpen(gds.out, readonly = FALSE)
      sink(file=logname, append=T)
      cat("GDS file creation .... \n")
      cat("Done! \n")
      sink()
    }
    sink(file=logname, append=T)
    cat(paste("GDS file: ", gds.out, "\n", sep=""))
    sink()
  } else {
    ##### CHECK FORMAT #####
    indir <- dirname(in.file)
    format <- str_sub(in.file, start=-4)
    filename <- str_sub(in.file, start=1, end=-5)
    if (format == ".bed") {
      bed <- paste(filename, ".bed", sep="")
      bim <- paste(filename, ".bim", sep="")
      fam <- paste(filename, ".fam", sep="")
      if (file.exists(bed) == TRUE & file.exists(bim) == TRUE & file.exists(fam) == TRUE) {
        sink(file=logname, append=T)
        cat(paste("BED file: ", basename(bed), "\n", sep=""))
        cat(paste("BIM file: ", basename(bim), "\n", sep=""))
        cat(paste("FAM file: ", basename(fam), "\n", sep=""))
        sink()
      } else {
        cat("In.file not found .... \n")
        stop("Exit", call. = F)
      }

      ##### CHECK BIM FILE #####

      # read bim.file
      bim.file <- read.table(bim)
      # unique.chr val
      unique.chr <- unique(bim.file[,1])
      # convert in numeric val
      unique.chr <- as.numeric(unique.chr)
      # check NA
      if (NA %in% unique.chr) {
        cat("Non-numerical chromosomes were detected!\nPlease use the function 'bite.convert_chromosomes()'\nto convert X, Y, XY, MT, M chromosomes to numerical values\n")
        stop("Exit", call. = F)
      }

      ##### CHECK PHENO.FILE #####
      if (is.null(pheno.file)) {
        sink(file=logname, append=T)
        cat("Pheno.file creation ... \n")
        sink()
        tmp <- read.table(fam)
        tmpsex<-tmp[,5]
        tmpsex[tmpsex!=1] <- 0
        tmppheno <- cbind(tmp[,1:2],tmpsex,rep(-9,nrow(tmp)))
        colnames(tmppheno)<-c("pop","id","sex","pheno")
        write.table(tmppheno, file = paste(indir,"/phenotype.txt", sep=""), quote = F, row.names = F, col.names = T, sep="\t")
        rm(tmp,tmpsex,tmppheno)
        pheno.file=paste(indir, "/phenotype.txt", sep="")
      } else {
        if (!file.exists(pheno.file)) {
          cat("Pheno.file not found \n")
          stop("Exit", call. = F)
        }
      }
      sink(file=logname, append=T)
      cat(paste("Pheno.file: ", basename(pheno.file), "\n", sep=""))
      sink()
      ##### CHECK AND CREATE GDS FILE #####
      if (is.null(gds.out)) {
        gds.out <- "tmp.gds"
      }
      if (file.exists(gds.out)) {
        if (open.option == 1) {
          choice <- 1
        } else if (open.option == 2) {
          choice <- 2
        } else if (open.option == FALSE) {
          choice <- as.numeric(interactiveGDS(gds.out))
        } else {
          cat("Invalid open.option ....\n")
          stop("Exit", call. = FALSE)
        }
        if (choice == 1) {
          sink(file=logname, append=T)
          cat("Load existing gds file\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          genofile <- snpgdsOpen(gds.out, readonly = FALSE, allow.duplicate = TRUE)
        } else if (choice == 2) {
          file.remove(gds.out)
          sink(file=logname, append=T)
          cat("Remove existing gds file and reopen\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          snpgdsBED2GDS(bed, fam, bim, gds.out, verbose = FALSE)
          genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        } else {
          cat("Invalid selection ....\n")
          stop("Exit", call. = F)
        }

      } else {
        snpgdsBED2GDS(bed, fam, bim, gds.out, verbose = FALSE)
        genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        sink(file=logname, append=T)
        cat("GDS file creation .... \n")
        cat(paste("GDS file: ", gds.out, "\n", sep=""))
        sink()
      }
    } else if (format == ".vcf") {
      if (!file.exists(in.file)) {
        cat("In.file not found .... \n")
        stop("Exit", call. = F)
      } else {
        sink(file=logname, append=T)
        cat(paste("VCF file: ", basename(in.file), sep=""))
        sink()
      }

      ##### CHECK CHROM #####
      chrom.col <- fread(in.file, skip = "#CHROM", select = 1)
      # unique.chr val
      unique.chr <- unique(chrom.col)
      # convert in numeric val
      unique.chr <- as.numeric(unique.chr)
      # check NA
      if (NA %in% unique.chr) {
        cat("Non-numerical chromosomes were detected!\nPlease convert X, Y, XY, MT, M chromosomes to numerical values\n")
        stop("Exit", call. = F)
      }

      #### CHECK PHENO.FILE ####
      if (is.null(pheno.file)){
        cat("\nPheno.file not found .... \n")
        stop("Exit", call.=F)
      }
      sink(file=logname, append=T)
      cat(paste("\nPheno.file: ", basename(pheno.file), "\n", sep=""))
      sink()
      ##### CHECK AND CREATE GDS FILE #####
      if (is.null(gds.out)) {
        gds.out <- "tmp.gds"
      }
      if (file.exists(gds.out)) {
        if (open.option == 1) {
          choice <- 1
        } else if (open.option == 2) {
          choice <- 2
        } else if (open.option == FALSE) {
          choice <- as.numeric(interactiveGDS(gds.out))
        } else {
          cat("Invalid open.option ....\n")
          stop("Exit", call. = FALSE)
        }
        if (choice == 1) {
          sink(file=logname, append=T)
          cat("Load existing gds file\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          genofile <- snpgdsOpen(gds.out, readonly = FALSE, allow.duplicate = TRUE)
        } else if (choice == 2) {
          file.remove(gds.out)
          sink(file=logname, append=T)
          cat("Remove existing gds file and reopen\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          snpgdsVCF2GDS(in.file, gds.out, method = "biallelic.only", verbose = FALSE)
          genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        } else {
          cat("Invalid selection ....\n")
          stop("Exit", call. = F)
        }
      } else {
        snpgdsVCF2GDS(in.file, gds.out, method = "biallelic.only", verbose = FALSE)
        genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        sink(file=logname, append=T)
        cat("GDS file creation .... \n")
        cat("Done! \n")
        cat(paste("GDS file: ", gds.out, "\n", sep=""))
        sink()
      }
    } else if (format == ".ped") {
      ped <- paste(filename, ".ped", sep="")
      map <- paste(filename, ".map", sep="")
      if (file.exists(ped) == TRUE & file.exists(map) == TRUE) {
        sink(file=logname, append=T)
        cat(paste("PED file: ", basename(ped), "\n", sep=""))
        cat(paste("MAP file: ", basename(map), "\n", sep=""))
        sink()
      } else {
        cat("In.file not found .... \n")
        stop("Exit", call. = F)
      }

      ##### CHECK MAP FILE #####

      # read bim.file
      map.file <- read.table(map)
      # unique.chr val
      unique.chr <- unique(map.file[,1])
      # convert in numeric val
      unique.chr <- as.numeric(unique.chr)
      # check NA
      if (NA %in% unique.chr) {
        cat("Non-numerical chromosomes were detected!\nPlease use the function 'bite.convert_chromosomes()'\nto convert X, Y, XY, MT, M chromosomes to numerical values\n")
        stop("Exit", call. = F)
      }

      ##### CHECK PHENO.FILE #####
      if (is.null(pheno.file)) {
        sink(file=logname, append=T)
        cat("Pheno.file creation ... \n")
        sink()
        tmp <- fread(ped,select = paste0("V", 1:6))
        tmppheno <- as.data.frame(tmp[, c(1,2,5,6)])
        colnames(tmppheno)<-c("pop","id","sex","pheno")
        write.table(tmppheno, file = paste(indir,"/phenotype.txt", sep=""), quote = F, row.names = F, col.names = T, sep="\t")
        rm(tmp,tmppheno)
        pheno.file=paste(indir, "/phenotype.txt", sep="")
      } else {
        if (!file.exists(pheno.file)) {
          cat("Pheno.file not found \n")
          stop("Exit", call. = F)
        }
      }
      sink(file=logname, append=T)
      cat(paste("Pheno.file: ", basename(pheno.file), "\n", sep=""))
      sink()
      ##### CHECK AND CREATE GDS FILE #####
      if (is.null(gds.out)) {
        gds.out <- "tmp.gds"
      }
      if (file.exists(gds.out)) {
        if (open.option == 1) {
          choice <- 1
        } else if (open.option == 2) {
          choice <- 2
        } else if (open.option == FALSE) {
          choice <- as.numeric(interactiveGDS(gds.out))
        } else {
          cat("Invalid open.option ....\n")
          stop("Exit", call. = FALSE)
        }
        if (choice == 1) {
          sink(file=logname, append=T)
          cat("Load existing gds file\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          genofile <- snpgdsOpen(gds.out, readonly = FALSE, allow.duplicate = TRUE)
        } else if (choice == 2) {
          file.remove(gds.out)
          sink(file=logname, append=T)
          cat("Remove existing gds file and reopen\n")
          cat(paste("GDS file: ", gds.out, "\n", sep=""))
          sink()
          snpgdsPED2GDS(ped, map, gds.out, verbose = FALSE)
          genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        } else {
          cat("Invalid selection ....\n")
          stop("Exit", call. = F)
        }

      } else {
        snpgdsPED2GDS(ped, map, gds.out, verbose = FALSE)
        genofile <- snpgdsOpen(gds.out, readonly = FALSE)
        sink(file=logname, append=T)
        cat("GDS file creation .... \n")
        cat(paste("GDS file: ", gds.out, "\n", sep=""))
        sink()
      }
    } else {
      cat("In.file not found .... \n")
      stop("Exit", call. = F)
    }
  }
  ############# POP ORDER COLOR FILE #############
  pheno <- read.table(pheno.file, header = T)
  colnames(pheno) <- c("pop", "id", "sex", "pheno")

  uniqpop <- unique(pheno$pop)
  sink(file=logname, append=T)
  tmpp <- checkPopOrdColor(pop.order.color.file, uniqpop)
  sink()
  ## ORDINAMENTO PHENO ##
  newPheno <- pheno[order(factor(pheno$pop, levels = tmpp$popord)), ]
  rownames(newPheno) <- NULL
  ## ORDINAMENTO GENO ##
  geno <- read.gdsn(index.gdsn(genofile, "genotype"))

  sink(file=logname, append=T)
  cat("***** INFO *****\n")
  cat(paste("N° of samples: ", dim(geno)[1], "\n", sep=""))
  cat(paste("N° of SNPs: ", dim(geno)[2], "\n", sep=""))
  cat("****************\n")
  sink()

  sample.id.original.order <- read.gdsn(index.gdsn(genofile, "sample.id"))
  rownames(geno) <- sample.id.original.order
  geno <- geno[match(newPheno$id, rownames(geno)), ]

  #### REPLACE GENO WITH SORTED GENO ####
  rownames(geno) <- NULL
  add.gdsn(genofile, "genotype", geno, replace = TRUE, storage = "bit2", check = TRUE)
  ### necessario per consentire apertura gds se già esiste ###
  eggs <- index.gdsn(genofile, "genotype")
  put.attr.gdsn(eggs, "sample.order", val=NULL)
  ###

  #### CHANGE SAMPLE.ID ####
  add.gdsn(genofile, "sample.id", newPheno$id, replace=TRUE)

  #### ADD PHENO.INFO ####
  add.gdsn(genofile, "phenotype", newPheno, replace = TRUE)

  ### COLOR ###
  Mycol <- setColor(tmpp)

  ### ORDERMATRIX ###
  # set point
  #Mypointraw<- c(1:20,97:101,c(35,42,64,94,121,119,122))
  Mypointraw <- c(0:19)
  Mypoint<-rep(Mypointraw,round(length(tmpp$popord)/length(Mypointraw),0)+1)
  rm(Mypointraw)

  # Create matrix colors/points
  ordermatrix<-as.data.frame(cbind(tmpp$popord,Mycol[1:length(tmpp$popord)],Mypoint[1:length(tmpp$popord)]))
  ordermatrix[,3]<-as.numeric(ordermatrix[,3])

  ### ADD ORDERMATRIX ###
  add.gdsn(genofile, "ordermatrix", ordermatrix, replace = TRUE)

  ### SNPGDSOPTION ###

  # define options file
  option <- snpgdsOption()
  option$autosome.end <- num_autosomes
  option$chromosome.code$X <- num_autosomes +1
  option$chromosome.code$Y <- num_autosomes +2
  option$chromosome.code$XY <- num_autosomes + 3
  option$chromosome.code$M <- num_autosomes + 4
  option$chromosome.code$MT <- num_autosomes + 4

  # node index
  var.chr <- index.gdsn(genofile, "snp.chromosome")

  # define new options in gds
  put.attr.gdsn(var.chr, "autosome.start", option$autosome.start)
  put.attr.gdsn(var.chr, "autosome.end", option$autosome.end)
  for (i in 1:length(option$chromosome.code)) {
    put.attr.gdsn(var.chr, names(option$chromosome.code)[i],
                  option$chromosome.code[[i]])
  }


  #### RETURN GDS CLASS ####
  end <- proc.time()
  elapsed <- end - start
  sink(file=logname, append=T)
  cat(paste("Runtime: ", elapsed["elapsed"], sep=""))
  cat("\n*******************************************\n")
  sink()
  return(genofile)
}






























