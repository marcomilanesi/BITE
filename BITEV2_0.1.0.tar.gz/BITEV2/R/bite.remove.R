
################################################################################
################################# BITE REMOVE ##################################
################################################################################




bite.remove <- function(gds.path, out.dir, outID = NULL, outPOP = NULL, gds.out = "select_tmp.gds") {
  ########## OPEN GDS FILE ##########
  showfile.gds(closeall = T, verbose = F)
  gds.temp <- snpgdsOpen(gds.path)

  ########## CREATE QC.GDS.IN ##########
  temp <- basename(gds.temp$filename)
  select.pre <- str_sub(temp, start = 1, end = -5)
  select.path <- paste(out.dir, "/",gds.out, sep="")

  file.copy(gds.path, select.path, overwrite = TRUE)

  # close orig gds file & open qc gds file
  showfile.gds(closeall=TRUE, verbose = FALSE)
  gds.in <- snpgdsOpen(select.path, readonly = FALSE)

  ########## EXTRACT INFO ##########
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  genotype <- snpgdsGetGeno(gds.in, verbose = FALSE)
  phenotype <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))

  ##### CHECK ID & POP #####
  if (is.null(outID) && is.null(outPOP)) {
    cat("Please add one of the two fields\n")
    stop("Exit", call.=F) }
  if(!is.null(outID) && !is.null(outPOP)) {
    cat("Please only one of the two fields\n")
    stop("Exit", call.=F)
  }

  ##### CHECK CONTENT OF OUTID OR OUTPOP #####
  if (!is.null(outID)) {
    # check if 1/more exists
    if (length(outID) != 1) {
      check <- TRUE
      for (i in range(1, length(outID))) {
        if (!(outID[i] %in% phenotype$id)){
          check <- FALSE
        }
      }
      if (check == FALSE) {
        cat("IDs not in gds.in\n")
        stop("Exit", call. = FALSE)
      }
    } else {
      if (!(outID %in% phenotype$id))
      {
        cat("ID not in gds.in\n")
        stop("Exit", call.=FALSE)
      }
    }
    # to_rm list
    to_rm <- list()
    to_rm$torm <- outID
    to_rm$type <- "id"
    to_rm$index <- which(phenotype$id %in% to_rm$torm)

  } else if (!is.null(outPOP)) {
    # check if 1/more exists
    if (length(outPOP) != 1) {
      check <- TRUE
      for (i in range(1, length(outPOP))) {
        if (!(outPOP[i] %in% phenotype$pop)){
          check <- FALSE
        }
      }
      if (check == FALSE) {
        cat("POPs not in gds.in\n")
        stop("Exit", call. = FALSE)
      }
    } else {
      # se è una stringa controlla che il singolo valore sia contenuto in pheno
      if (!(outPOP %in% phenotype$pop))
      {
        cat("POP not in gds.in\n")
        stop("Exit", call.=FALSE)
      }
    }

    # to_rm list
    to_rm <- list()
    to_rm$torm <- outPOP
    to_rm$type <- "pop"
    to_rm$index <- which(phenotype$pop %in% to_rm$torm)
  }

  ##### REMOVE POP / ID #####
  if (to_rm$type == "id") {
    boolCond <- !phenotype$id %in% to_rm$torm
    newPhenotype <- phenotype[boolCond, ]
    newGenotype <- genotype[boolCond, ]
    newSample.id <- sample.id[boolCond]
    newOrdermatrix <- ordermatrix
  } else if (to_rm$type == "pop") {
    boolCond <- !phenotype$pop %in% to_rm$torm
    newPhenotype <- phenotype[boolCond, ]
    newGenotype <- genotype[boolCond, ]
    newSample.id <- sample.id[boolCond]
    newOrdermatrix <- ordermatrix[!ordermatrix$V1 %in% to_rm$torm, ]
  }
  update.gds(gds.in, sample.id=newSample.id, genotype = newGenotype, phenotype = newPhenotype,
             ordermatrix = newOrdermatrix)

  return(gds.in)
}

