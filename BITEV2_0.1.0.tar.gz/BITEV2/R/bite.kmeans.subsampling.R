

################################################################################
############################# BITE KMEANS SUBSAMPLING ##########################
################################################################################


bite.kmeans.subsampling <- function(gds.path, out.dir, gds.out = "bite_km_subsample.gds", n.iter = 10, n.subsample, nstart = 100, ...) {

  ##### SINK & OUT.DIR
  out.name <- str_sub(gds.out, start = 1, end = -5)
  out.path <- paste(out.dir, "/", out.name, sep="")

  if (!file.exists(out.path)) {
    dir.create(out.path)
  }

  logname <- paste(out.path, "/km_", out.name, ".log", sep="")

  sink(logname)
  cat("***** BITE KMEANS SAMPLING *****\n")
  cat("Parameters:\n")
  cat(paste("- Gds path: ", gds.path, "\n", "- Out dir: ", out.path, "\n", "- Gds out: ", gds.out, "\n",
            "- n.subsample: ", n.subsample, "\n", "- nstart: ", nstart, "\n", "- n.iter: ", n.iter, "\n", sep=""))
  cat("********************************\n")

  sink()

  ##### SET ENV
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))
  pop <- ordermatrix[,1]
  fam <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  geno <- snpgdsGetGeno(gds.in, verbose = F)

  final.subset <- c()
  cat("Runinng ....\n")

  ##### IMPUTE GENO
  imputed.geno <- meanImputation(geno)

  ##### SUBSAMPLING
  sink(logname, append = T)
  cat("\n***** START *****")
  sink()
  for (n.breed in 1:length(pop)) {

    sink(logname, append = T)
    cat("\n\nKmeans subsampling for:", pop[n.breed], "\n")
    sink()
    ind.ori <- fam$id[fam$pop == pop[n.breed]]

    if (length(ind.ori) <= n.subsample) {
      final.subset <- c(final.subset, ind.ori)
      sink(logname, append = T)
      cat(" Number of individuals less than or equal to the required subset size\n")
      cat(" All individuals in the", pop[n.breed],"poulation were considered\n")
      sink()
    } else {
      # geno subset
      pop_index <- which(fam$id %in% ind.ori)
      pop_geno <- imputed.geno[pop_index, ]

      # pca
      res.pca <- prcomp(pop_geno, retx = TRUE)
      exp.var <- varPCA(summary(res.pca))

      # kmeans subsample
      sink(logname, append = T)
      pop.find <- kmeans.subsamp(res.pca, n.subsample, ind.ori, n.iter, nstart)
      sink()
      final.subset <- c(final.subset, pop.find)

      # plot res for pop
      eigenvect <- as.data.frame(res.pca$x[,1:2])
      eigenvect$ind <- ind.ori
      eigenvect$pop <- pop[n.breed]
      eigenvect$km_rs <- ifelse(eigenvect$ind %in% pop.find, 1, 0)

      ggplot(data = eigenvect, aes(x=PC1, y=PC2)) +
        geom_point(alpha = 0.5, color = ordermatrix$V2[n.breed]) +
        geom_point(data = subset(eigenvect, km_rs == 1), aes(x = PC1, y = PC2), color = ordermatrix$V2[n.breed]) +
        geom_text_repel(data = subset(eigenvect, km_rs==1), aes(label=ind), min.segment.length = 0, size = 2, color="black") +
        labs(x = paste("PC1:", round(exp.var[1], 2), "%", sep = ""), y = paste("PC2:", round(exp.var[2], 2), "%", sep = "")) +
        theme_bw()
      ggsave(paste(out.path, "/", pop[n.breed], "_", out.name, ".pdf", sep=""), width = 18, height = 9)
    }
  }

  #### FINAL PLOT
  tot.res.pca <- prcomp(imputed.geno)
  tot.eigenvect <- as.data.frame(tot.res.pca$x[,1:2])
  tot.exp.var <- varPCA(summary(res.pca))
  tot.eigenvect$ind <- fam$id
  tot.eigenvect$pop <- fam$pop
  tot.eigenvect$km_rs <- ifelse(tot.eigenvect$ind %in% final.subset, 1, 0)

  ggplot(data = tot.eigenvect, aes(x=PC1, y=PC2, color = pop, label = pop)) +
    geom_point(alpha = 0.6) +
    geom_point(data = subset(tot.eigenvect, km_rs == 1), aes(x = PC1, y = PC2)) +
    #geom_text_repel(data = subset(tot.eigenvect, km_rs==1), aes(label=ind), min.segment.length = 0, size = 2, color="black") +
    labs(x = paste("PC1:", round(tot.exp.var[1], 2), "%", sep = ""), y = paste("PC2:", round(tot.exp.var[2], 2), "%", sep = "")) +
    scale_color_manual(values = ordermatrix$V2) +
    theme_bw()
  ggsave(paste(out.path, "/", out.name, "_final_res.pdf", sep=""), , width = 18, height = 9)

  sink(logname, append = T)
  cat("\n***** END *****\n")
  sink()


  #### bite select
  return(bite.select(gds.path, out.dir, inID = final.subset, gds.out = gds.out))
}




############## SINGLE POP SUBSAMP ##############
kmeans.subsamp <- function(res.pca, n.subsample, ind.ori, n.iter, nstart) {

  # running kmeans n.iter times
  cat(paste("Running Kmeans ", n.iter, " times to maximise intercluster\ndistance and minimise intracluster distance ....\n", sep=""))
  for (i in 1:n.iter) {
    kmeans_result <- kmeans(res.pca$x, centers = n.subsample, nstart = nstart)
    if (i == 1) {
      tot.with <- kmeans_result$tot.withinss
      betw <- kmeans_result$betweenss
      final_res <- kmeans_result
    } else {
      if (kmeans_result$betweenss > betw && kmeans_result$tot.withinss < tot.with) {
        tot.with <- kmeans_result$tot.withinss
        betw <- kmeans_result$betweenss
        final_res <- kmeans_result
      }
    }
  }
  cat(paste("Final res:\n","tot.with: ", tot.with, "\n", "betw: ", betw, "\n"))

  # distances
  eigenvect <- as.data.frame(res.pca$x[,1:2])
  eigenvect$ind <- ind.ori
  eigenvect$clust <- kmeans_result$cluster

  centroids <- as.data.frame(kmeans_result$centers[,1:2])
  centroids$clust <- 1:n.subsample

  # ordina righe eigenvect in base a clust
  eigenvect.ord <- arrange(eigenvect, clust)

  # calcola dist
  dist.res <- c()
  for (i in 1:length(eigenvect.ord$clust)) {
    tmp1 <- eigenvect.ord[i,]
    tmp2 <- centroids[centroids$clust == tmp1$clust, ]
    a <- c(tmp1$PC1, tmp1$PC2)
    b <- c(tmp2$PC1, tmp2$PC2)
    dist.res <- c(dist.res, as.numeric(dist(rbind(a,b))))
  }

  distance.result <- data.frame(eigenvect.ord$ind, eigenvect.ord$clust, dist.res)
  colnames(distance.result) <- c("ind", "centroid", "distance")

  # prendi ind con distanza minore
  subsampling.res <- distance.result %>%
    group_by(centroid) %>%
    slice_min(distance)

  # se 2 o più ind ind hanno la stessa distanza dal centroide
  if (length(subsampling.res$centroid) != length(unique(subsampling.res$centroid))) {
    tmp <- c() # ind
    tmpp <- c() # clust
    for (i in 1:length(subsampling.res$ind)) {
      if (!(subsampling.res$centroid[i] %in% tmpp)) {
        tmpp <- c(tmpp, subsampling.res$centroid[i])
        tmp <- c(tmp, subsampling.res$ind[i])
      }
    }

    subsampling.res <- subsampling.res[subsampling.res$ind %in% tmp, ]
  }

  eigenvect.ord$min <- ifelse(eigenvect.ord$ind %in% subsampling.res$ind, 1, 0)

  #### OTTIMIZZAZIONE
  # per ciascun rapresentative sample (x) calcola la distanza da ciascun altro rapresentative sample (i)
  # se questa distanza è minore rispetto alla distanza fra x è il punto più vicino appartentente al medesimo
  # cluster, sposta x

  cat("Optimize the result obtained with the kmeans ....\n")
  #eigenvect.ord$already_min <- 0
  subsamp <- subsampling.res$ind
  n.iter <- 0
  while(TRUE) {
    n.iter <- n.iter + 1
    num_of_changes <- 0
    for (i in 1:length(subsamp)) {
      # prendi coordinate di ciascun i-esimo
      tmp <- eigenvect.ord[eigenvect.ord$ind == subsamp[i], ]
      #cat(paste("Cluster: ", i," subsamp attuale: ", tmp$ind, "\n", sep=""))
      # calcola la distanza di ciascun i-esimo da tutti gli altri punti
      subsamp.dist <- c()
      for (j in 1:length(subsamp)) {
        if (j != i) {
          tmpp <- eigenvect.ord[eigenvect.ord$ind == subsamp[j], ]
          a <- c(tmp$PC1, tmp$PC2)
          b <- c(tmpp$PC1, tmpp$PC2)
          subsamp.dist <- c(subsamp.dist, as.numeric(dist(rbind(a,b))))
        }
      }

      #cat("Subsamp dist: \n")
      #print(subsamp.dist)
      #cat("\n")

      # calcola la distanza fra l'individuo i-esimo e l'individuo ad esso vicino
      clust.subset <- subset(eigenvect.ord, clust == i & min != 1)

      if (length(clust.subset$ind) !=0) {
        clust.dist <- c()
        for (k in 1:length(clust.subset$ind)) {
          tmppp <- clust.subset[k, ]
          c <- c(tmp$PC1, tmp$PC2)
          d <- c(tmppp$PC1, tmppp$PC2)
          clust.dist <- c(clust.dist, as.numeric(dist(rbind(c,d))))
        }
        # trova per ciascun cluster la distanza fra i-esimo e ind più vicino
        clust.min <- min(clust.dist)
        clust.nn <- clust.subset[which.min(clust.dist), ]
        clust.nn <- clust.nn$ind
        #cat(paste("Clust Min: ", clust.min, " Con: ", clust.nn, "\n", sep=""))

        # se in subsamp.dist è presente una distanza inferiore a clust.min
        # assegna 1 clust.nn e 0 a tmp$ind
        for (l in 1:length(subsamp.dist)) {
          #if (subsamp.dist[l] < clust.min & eigenvect.ord$already_min[eigenvect.ord$ind == clust.nn] != 1 & eigenvect.ord$already_min[eigenvect.ord$ind == tmp$ind] != 1) {
          if (subsamp.dist[l] < clust.min) {
            #cat(paste(clust.nn, " diventa il nuovo subsamp del cluster ", clust.subset$clust, " al posto di ", tmp$ind, "\n", sep=""))
            eigenvect.ord$min[eigenvect.ord$ind == clust.nn] <- 1
            eigenvect.ord$already_min[eigenvect.ord$ind == clust.nn] <- 1
            eigenvect.ord$min[eigenvect.ord$ind == tmp$ind] <- 0
            eigenvect.ord$already_min[eigenvect.ord$ind == tmp$ind] <- 1
            # sostituisci anche subsampling res
            subsamp[i] <- clust.nn
            #cat("Nuovo subsamp: \n")
            #print(subsamp)
            num_of_changes <- num_of_changes + 1
            break
          }
        }
      }
    }
    if (num_of_changes == 0) {
      break
    }
    # evita loop infiniti
    if (n.iter == 20) {
      break
    }
  }


  pop.subset <- subset(eigenvect.ord, min == 1)
  subset.ind <- pop.subset$ind
  return (subset.ind)
}





