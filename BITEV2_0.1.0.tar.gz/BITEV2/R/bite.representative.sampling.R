
################################################################################
################### BITE CLASSIC RAPRESENTATIVE SAMPLING #######################
################################################################################




bite.representative.sampling <- function(gds.path, out.dir, gds.out = "bite_cl_subsample.gds", n.subsample, n.k = 2, threshold = 0.5, n.iter = 10, red.perc = c(4,3,2,1), ...) {
  ### SINK & out.dir
  out.name <- str_sub(gds.out, start = 1, end = -5)
  out.path <- paste(out.dir, "/", out.name, sep="")

  if (!file.exists(out.path)) {
    dir.create(out.path)
  }

  logname <- paste(out.path, "/cl_", out.name, ".log", sep="")

  sink(logname)
  cat("***** BITE REPRESENTATIVE SAMPLING *****\n")
  cat("Parameters:\n")
  cat(paste("- Gds path: ", gds.path, "\n", "- Out dir: ", out.path, "\n", "- Gds out: ", gds.out, "\n",
            "- n.subsample: ", n.subsample, "\n- n.k: ", n.k, "\n", "- Threshold: ", threshold, "\n",
            "- n.iter: ", n.iter, "\n", sep=""))
  cat("- Reduction: ", red.perc[1], "ind, ", red.perc[2], "ind,", red.perc[3], "ind,", red.perc[4], "ind", "\n")
  cat("****************************************\n")
  sink()


  ### check dei params
  if (n.subsample <= 1) {
    cat("Invalid n.subsample parameter.\n")
    stop("Exit", call. = F)
  }

  ##### SET ENV
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))
  pop <- ordermatrix[,1]
  fam <- read.gdsn(index.gdsn(gds.in, "phenotype"))

  final.subset <- c()
  cat("Running ....\n")

  ##### SUBSAMPLING
  sink(logname, append = T)
  cat("\n***** START *****")
  sink()
  for (n.breed in 1:length(pop)) {
    sink(logname, append = T)
    cat("\n\nBite representative sampling for:", pop[n.breed], "\n")
    sink()
    ind.ori <- fam$id[fam$pop == pop[n.breed]]
    if (length(ind.ori) <= n.subsample) {
      final.subset <- c(final.subset, ind.ori)
      sink(logname, append = T)
      cat(" Number of individuals less than or equal to the required subset size\n")
      cat(" All individuals in the", pop[n.breed],"poulation were considered\n")
      sink()
    } else {
      sink(logname, append = T)
      cat("- Direct.Subsampling for:", pop[n.breed], "\n")
      sink()

      ### pca sul subset totale ###
      subset.pca <- snpgdsPCA(gds.in, sample.id = ind.ori, eigen.cnt = n.k, verbose = F)
      subset.eigen <- subset.pca$eigenvect
      subset.varprop <- subset.pca$varprop[1:n.k]*100

      ### direct subsamp
      check.subsamp <- NULL
      for (i in 1:n.iter) {
        res <- direct.subsamp(gds.in, ind.ori, n.subsample, n.k, threshold, subset.eigen)
        if (!is.null(res)) {
          check.subsamp <- res
          sink(logname, append = T)
          cat("   After", i, "iteractions a direct.subset with a similar structure to the\n")
          cat("   original was found!\n")
          sink()
          final.subset <- c(final.subset, check.subsamp)

          # ggplot
          subset.eigen <- as.data.frame(subset.eigen)
          subset.eigen$ind <- ind.ori
          subset.eigen$pop <- pop[n.breed]
          subset.eigen$cl_rs <- ifelse(subset.eigen$ind %in% check.subsamp,1,0)

          ggplot(data = subset.eigen, aes(x=V1, y=V2)) +
            geom_point(alpha = 0.5, color = ordermatrix$V2[n.breed]) +
            geom_point(data = subset(subset.eigen, cl_rs == 1), aes(x = V1, y = V2), color = ordermatrix$V2[n.breed]) +
            geom_text_repel(data = subset(subset.eigen, cl_rs==1), aes(label=ind), min.segment.length = 0, size = 2, color="black") +
            labs(x = paste("PC1:", round(subset.varprop[1], 2), "%", sep = ""), y = paste("PC2:", round(subset.varprop[2], 2), "%", sep = "")) +
            theme_bw()
          ggsave(paste(out.path, "/", pop[n.breed],"_", out.name, ".pdf", sep=""), width = 18, height = 9)

          break
        }
      }
      if (is.null(check.subsamp)) {
        sink(logname, append = T)
        cat("  After", n.iter, "iterations a direct.subset with a similar structure to the\n")
        cat("  original was not found..\n")

        cat("- StepByStep.Subsampling for:", pop[n.breed], "\n")
        tot.ind <- ind.ori
        tot.ind.length <- length(tot.ind)
        cat("  Number of individuals - original:", tot.ind.length,"\n")
        sink()
        check.while <- TRUE

        tmp.pca <- snpgdsPCA(gds.in, sample.id = tot.ind, verbose = F)
        tmp.eigen <- tmp.pca$eigenvect

        while (TRUE) {
          #cat("Vuoi cominciare il ciclo while?")
          #tmp <- readline()

          # check status
          if (!check.while) {
            stop("Exit", call. = F)
            break
          }

          # check res
          if (tot.ind.length == n.subsample) {
            sink(logname, append = T)
            cat("  A subset with a similar structure to the original was found!\n")
            cat("  Number of individuals - subset:", tot.ind.length, "\n")
            sink()
            final.subset <- c(final.subset, tot.ind)

            # ggplot
            subset.eigen <- as.data.frame(subset.eigen)
            subset.eigen$ind <- ind.ori
            subset.eigen$pop <- pop[n.breed]
            subset.eigen$cl_rs <- ifelse(subset.eigen$ind %in% tot.ind,1,0)

            ggplot(data = subset.eigen, aes(x=V1, y=V2)) +
              geom_point(alpha = 0.5, color = ordermatrix$V2[n.breed]) +
              geom_point(data = subset(subset.eigen, cl_rs == 1), aes(x = V1, y = V2), color = ordermatrix$V2[n.breed]) +
              geom_text_repel(data = subset(subset.eigen, cl_rs==1), aes(label=ind), min.segment.length = 0, size = 2, color="black") +
              labs(x = paste("PC1:", round(subset.varprop[1], 2), "%", sep = ""), y = paste("PC2:", round(subset.varprop[2], 2), "%", sep = "")) +
              theme_bw()
            ggsave(paste(out.path, "/", pop[n.breed], "_", out.name, ".pdf", sep=""), width = 18, height = 9)
            break
          }

          # check res for min values
          ## !! QUESTA COSA VA RIMOSSA
          if (tot.ind.length < n.subsample) {
            sink(logname, append = T)
            cat("   A subset with", tot.ind.length, "individuals with a similar structure\n")
            cat("   to the original was found!\n")
            cat(" Number of individuals - subset:", tot.ind.length, "\n")
            sink()
            final.subset <- c(final.subset, tot.ind)

            # ggplot
            subset.eigen <- as.data.frame(subset.eigen)
            subset.eigen$ind <- ind.ori
            subset.eigen$pop <- pop[n.breed]
            subset.eigen$cl_rs <- ifelse(subset.eigen$ind %in% tot.ind,1,0)

            ggplot(data = subset.eigen, aes(x=V1, y=V2)) +
              geom_point(alpha = 0.5, color = ordermatrix$V2[n.breed]) +
              geom_point(data = subset(subset.eigen, cl_rs == 1), aes(x = V1, y = V2), color = ordermatrix$V2[n.breed]) +
              geom_text_repel(data = subset(subset.eigen, cl_rs==1), aes(label=ind), min.segment.length = 0, size = 2, color="black") +
              labs(x = paste("PC1:", round(subset.varprop[1], 2), "%", sep = ""), y = paste("PC2:", round(subset.varprop[2], 2), "%", sep = "")) +
              theme_bw()
            ggsave(paste(out.path, "/", pop[n.breed],"_", out.name, ".pdf", sep=""), width = 18, height = 9)

            break
          }

          # reduction with red.perc[1]
          #cat("riduzione di 4:")
          #tmp <- readline()

          if (!((tot.ind.length - red.perc[1]) < n.subsample)) {
            for (i in 1:n.iter) {
              res1 <- stepbystep.subsamp(gds.in, tot.ind, tot.ind.length, red.perc[1], n.k, threshold, tmp.eigen)
              if (!is.null(res1)) {
                tot.ind <- res1
                tot.ind.length <- length(tot.ind)

                tmp.pca <- snpgdsPCA(gds.in, sample.id = tot.ind, verbose = F)
                tmp.eigen <- tmp.pca$eigenvect

                break
              }
            }
          } else {
            #cat("Così finisci sotto n.subsample..\n")
            res1 <- NULL
          }

          if (is.null(res1)) {
            # reduction with red.perc[2]
            #cat("riduzione di 3:")
            #tmp <- readline()

            if (!((tot.ind.length - red.perc[2]) < n.subsample)) {
              for (i in 1:n.iter) {
                res2 <- stepbystep.subsamp(gds.in, tot.ind, tot.ind.length, red.perc[2], n.k, threshold, tmp.eigen)
                if (!is.null(res2)) {
                  tot.ind <- res2
                  tot.ind.length <- length(res2)

                  tmp.pca <- snpgdsPCA(gds.in, sample.id = tot.ind, verbose = F)
                  tmp.eigen <- tmp.pca$eigenvect

                  break
                }
              }
            } else {
              #cat("Così finisci sotto n.subsample..\n")
              res2 <- NULL
            }

            if (is.null(res2)) {
              # reduction with red.perc[3]
              #cat("riduzione di 2:")
              #tmp <- readline()

              if (!((tot.ind.length - red.perc[3]) < n.subsample)) {
                for (i in 1:n.iter) {
                  res3 <- stepbystep.subsamp(gds.in, tot.ind, tot.ind.length, red.perc[3], n.k, threshold, tmp.eigen)
                  if (!is.null(res3)) {
                    tot.ind <- res3
                    tot.ind.length <- length(tot.ind)

                    tmp.pca <- snpgdsPCA(gds.in, sample.id = tot.ind, verbose = F)
                    tmp.eigen <- tmp.pca$eigenvect

                    break
                  }
                }
              } else {
                #cat("Così finisci sotto n.subsample..\n")
                res3 <- NULL
              }
              if (is.null(res3)) {
                # reduction with red.perc[4]
                #cat("riduzione di 1:")
                #tmp <- readline()

                if (!((tot.ind.length - red.perc[4]) < n.subsample)) {
                  for (i in 1:n.iter) {
                    res4 <- stepbystep.subsamp(gds.in, tot.ind, tot.ind.length, red.perc[4], n.k, threshold, tmp.eigen)
                    if (!is.null(res4)) {
                      tot.ind <- res4
                      tot.ind.length <- length(tot.ind)

                      tmp.pca <- snpgdsPCA(gds.in, sample.id = tot.ind, verbose = F)
                      tmp.eigen <- tmp.pca$eigenvect

                      break
                    }
                  }
                } else {
                  sink(logname, append = T)
                  cat("It was not possible to obtain a subset with the parameters you specified ..\n")
                  cat("It is recommended to set a value of", tot.ind.length, "as n.subsamp\n")
                  sink()
                  cat("It was not possible to obtain a subset with the parameters you specified ..\n")
                  cat("It is recommended to set a value of", tot.ind.length, "as n.subsamp\n")
                  check.while <- FALSE
                }

                if (is.null(res4)) {
                  sink(logname, append = T)
                  cat("It was not possible to obtain a subset with the parameters you specified ..\n")
                  cat("It is recommended to set a value of", tot.ind.length, "as n.subsamp\n")
                  sink()
                  cat("It was not possible to obtain a subset with the parameters you specified ..\n")
                  cat("It is recommended to set a value of", tot.ind.length, "as n.subsamp\n")
                  check.while <- FALSE
                }
              }
            }
          }
        }
      }
    }
  }


  #cat("Subset finale:", length(final.subset), "\n")
  #### PLOT REPRESENTATIVE SAMPLES

  pca.res <- snpgdsPCA(gds.in, verbose = F)
  eigen <- as.data.frame(pca.res$eigenvect)
  pcperc <- round(pca.res$varprop*100, 2)
  eigen$pop <- fam$pop
  eigen$id <- fam$id

  pos <- which(eigen$id %in% final.subset)
  eigen$rapresentative <- 0
  eigen$rapresentative[pos] <- 1

  ggplot(data = eigen, aes(x=V1, y=V2, color = pop, label = pop)) +
    geom_point(alpha = 0.6) +
    geom_point(data = subset(eigen, rapresentative == 1), aes(x = V1, y = V2)) +
    #geom_text_repel(data = subset(eigen, rapresentative==1), aes(label=id), min.segment.length = 0, size = 2, color="black") +
    labs(x = paste("PC1:", pcperc[1], "%", sep = ""), y = paste("PC2:", pcperc[2], "%", sep = "")) +
    scale_color_manual(values = ordermatrix$V2) +
    theme_bw()
  ggsave(paste(out.path, "/", out.name, "_final_res.pdf", sep=""), width = 18, height = 9)

  sink(logname, append = T)
  cat("\n***** END *****\n")
  sink()

  ##### FINAL SUBSET #####
  path <- gds.in$filename
  return(bite.select(path, out.dir, inID = final.subset, gds.out = gds.out))
}





########### SUBSAMPLING FUNCTIONS ###########

stepbystep.subsamp <- function(gds.in, tot.ind, tot.ind.length, to_rm, n.k, threshold, tmp.eigen) {
  #to_rm <- tot.ind.length * perc
  #to_rm <- round(to_rm, digits = 0)
  #cat("Individui da rimuovere",to_rm, "\n")

  # controllo di to_rm
  if (to_rm == 0) {
    return (NULL)
  }

  to_keep <- tot.ind.length - to_rm
  ind.tokeep <- sample(tot.ind, to_keep, replace = F)

  ####

  ####

  # subset pca
  rec.pca <- snpgdsPCA(gds.in, sample.id = ind.tokeep, eigen.cnt = n.k, verbose = F)
  rec.eigenvect <- rec.pca$eigenvect
  # wilcoxon test
  ws.pval <- rep(0, n.k)
  for (b in 1:n.k) {
    tmp.test <- ks.test(tmp.eigen[,b], rec.eigenvect[,b], alternative = "two.sided")
    ws.pval[b] <- tmp.test$p.value
  }
  #cat("pvalue:", min(ws.pval, na.rm=T),"\n")
  # check
  if (min(ws.pval, na.rm = T) >= threshold) {
    # crea la lista di output
    return (ind.tokeep)
  } else {
    return (NULL)
  }
}





direct.subsamp <- function(gds.in, ind.ori, n.subsample, n.k, threshold, subset.eigen) {

  ### direct subsamp  ###
  dsample.ind <- sample(ind.ori, n.subsample, replace = F)

  # pca
  dsample.pca <- snpgdsPCA(gds.in, sample.id = dsample.ind, eigen.cnt = n.k, verbose = F)
  dsample.eigen <- dsample.pca$eigenvect
  dsample.varprop <- dsample.pca$varprop[1:n.k]*100

  # wilcoxon test
  ws.pval <- rep(0, n.k)
  for (b in 1:n.k) {
    tmp.test <- ks.test(subset.eigen[,b], dsample.eigen[,b], alternative = "two.sided")
    ws.pval[b] <- tmp.test$p.value
  }

  # check ws pval
  if (min(ws.pval, na.rm = T) >= threshold) {
    return (dsample.ind)
  } else {
    return (NULL)
  }
}



