source("R/bite.functions.R", local = TRUE)
################################################################################
############################### BITE SHINY PCA #################################
################################################################################

bite.shinyPCA <- function(gds.path, snp.random.subset = NULL, ...) {
  options(warn = -1)

  ### GDS IN
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  # take data
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.num <- length(snp.id)
  sample.num <- length(sample.id)

  ##### CHECK SNP.RANDOM.SUBSET #####
  if (is.null(snp.random.subset)) {

    # check num of snps
    if (snp.num >= 200000 & sample.num >= 500) {
      # warning message
      cat(paste("Warning: ", basename(gds.in$filename), " contains ", snp.num, " snps & ", sample.num, " individuals.\n", sep=""))
      cat("Bite.shinyPCA() may take a long time.\nConsider the idea of using only a random subset of snps for PCA analysis:\n")
      cat("- Yes (1)\n")
      cat("- No (2)\n")

      choice <- readline()

      if (choice == 1) {
        cat("Enter the number of snps to consider: ")
        snp.random.subset <- readline()
        snp.random.subset <- as.numeric(snp.random.subset)

        if (snp.random.subset >= snp.num || snp.random.subset <= 0) {
          cat("Invalid value!\n")
          stop("Exit", call.=F)
        }
      } else if (choice == 2) {
        snp.random.subset <- snp.num
      } else {
        cat("Invalid selection .... \n")
        stop("Exit", call.=F)
      }
    }
  }

  if (snp.random.subset == snp.num || is.null(snp.random.subset)) {
    snp.sample <- snp.id
  } else {
    snp.sample <- sample(snp.id, snp.random.subset, replace = F)
  }

  cat("Running ....\n")

  ##### EXTRACT GENO/PHENO/ORDERMATRIX FROM GDS.IN #####
  pheno <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))

  ##### PCA SNPRELATE #####
  pca <- snpgdsPCA(gds.in, verbose = FALSE, snp.id = snp.sample)

  pc.percent <- pca$varprop*100

  # delete NaN values
  pc.percent <- pc.percent[!is.na(pc.percent)]
  pc.percent <- data.frame(perc = round(pc.percent,2), pc = factor(paste("PC", 1:length(pc.percent), sep="")))

  # tab
  tab <- as.data.frame(pca$eigenvect)
  colnames(tab) <- paste0(pc.percent$pc, ": ", pc.percent$perc, "%")
  tab$id <- pheno$id
  tab$pop <- factor(pheno$pop, levels = ordermatrix$V1)

  ##### SHINY PCA #####

  # Shiny App Interface
  ui <- fluidPage(
    headerPanel('PCA Exploration Tool'),
    sidebarPanel(
      width = 3,
      # Scelta PCA
      selectInput("xcol", "X-Axis", choices = colnames(tab)[1:(length(colnames(tab))-2)], selected = colnames(tab)[1]),
      selectInput("ycol", "Y-Axis", choices = colnames(tab)[1:(length(colnames(tab))-2)], selected = colnames(tab)[2]),
      sliderInput("slider", label="Point Size:", min = 0.1, max = 10, value = 3, step = 0.1),
      plotlyOutput("p"),
      verbatimTextOutput("event")
    ), # end sidebarPanel()
    mainPanel(
      width = 9,
      plotlyOutput("plot",  height = "700px")
    ) # end mainPanel()

  ) # end fluidPage()

  # Server function
  server <- function(input, output, session) {
    # calls the column to be plotted in X
    x <- reactive({tab[,input$xcol]})
    # calls the column to be plotted in Y
    y <- reactive({tab[,input$ycol]})
    # get slider value to define new marker size
    pointsize <- reactive({ as.numeric(c(input$slider))})

    pca <- tab %>% ggplot(aes(x=x(), y=y(), color = pop, shape=pop, ID=id, POP=pop)) + geom_point() + scale_color_manual(values=ordermatrix$V2) + scale_shape_manual(values=ordermatrix$V3) + geom_hline(yintercept = 0, color = "grey", linewidth = 0.5) +  geom_vline(xintercept = 0, color = "grey", linewidth = 0.5) +  theme_bw() + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
    output$plot <- renderPlotly(ggplotly(pca + geom_point(size = pointsize(), alpha=0.75), tooltip = c("ID", "POP")))

  } # end server function

  shinyApp(ui,server)
}

