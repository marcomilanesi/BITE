#Script: membercoeff.cv
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Marco Milanesi, Elia Vajana, Lorenzo Bomba
#Contact: marco.milanesi.mm@gmail.com, vajana.elia@gmail.com, lory.bomb@gmail.com
#Description: Plot CV, iteration and other statistics from ancestral assignment results


#### outdf[,1] outdf[,2] sono i valori di x_values e y_values

membercoeff.cv <- function(
    in.file,
    out.file="tmp",
    software="Admixture",
    minK=2,
    maxK=2,
    K.to.plot=NULL,
    plot.format="pdf",
    plot.width=30,
    plot.height=10,
    plot.res=100,
    plot.cex.axis.y=1,
    plot.cex.axis.x=1,
    plot.cex.lab.y=1,
    plot.cex.lab.x=1,
    ...
){

  cat("Running ....\n")

  ##### Options and parameters
  ### Number of Ks to plot ###
  n.k <- maxK - minK + 1

  ### Create the log file ###
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  if (software %in% c("Admixture","ADMIXTURE","admixture","FastStructure","faststructure","FASTSTRUCTURE", "Faststructure", "sNMF")){
    cat(paste("Software used:",software,"\n"))
  }else{
    sink()
    cat("Allows software (Admixture, FastStructure and sNMF) not found. Please check! \n")
    stop("Exit",call. = F)
  }
  if (plot.format %in% c("pdf","png","tiff","tif")){
    cat(paste("Format of output file:",plot.format,"\n\n"))
    sink()
  }else{
    sink()
    cat("Allows plot format not found. Please check! \n")
    stop("Exit",call. = F)
  }

  ### Infile checking ###
  for (k in minK:maxK){
    fname <- paste(in.file,".",k,".log",sep="")
    if (file.exists(fname) == FALSE){
      cat(paste("Log files ",fname," not found. Please check the name of your logfile and change the name in according to the manual! \n",sep=""))
      stop("Exit",call. = F)
    }
  }

  # Open the file
  width.in<-plot.width/2.54
  height.in<-plot.height/2.54

  if (plot.format == "pdf"){
    pdf(paste(out.file,"_CV.pdf",sep=""),width=width.in,height=height.in)
  }else{
    if (plot.format == "png"){
      png(paste(out.file,"_CV.png",sep=""),width=width.in*plot.res,height=height.in*plot.res, res=plot.res)
    }else{
      if (plot.format == "tiff" | plot.format == "tif"){
        tiff(paste(out.file,"_CV.tif",sep=""), width=width.in*plot.res,height=height.in*plot.res, units="px", res=plot.res, compress="lzw")
      }else{
        cat("Allows plot format not found. Please check! \n")
        stop("Exit",call. = F)
      }
    }
  }

  #########################
  ####### Admixture #######
  #########################
  if (software %in% c("Admixture","ADMIXTURE","admixture")){
    ### Out df ###
    outdf <- as.data.frame(matrix(NA, ncol=3, nrow=n.k))
    colnames(outdf) <- c("K","CV","Iters")
    outdf[,1] <- minK:maxK

    ### CV and iteration importing ###
    for (k in minK:maxK){
      fname <- paste(in.file,".",k,".log",sep="")
      FileInput = readLines(fname)
      pos <- which(outdf[,1] == k)

      if (length(FileInput[grep(pattern = "ADMIXTURE",FileInput)]) == 0){
        cat(paste("Log files ",fname," found but not from Admixture. Please check the software argument used! \n",sep=""))
        stop("Exit",call. = F)
      }

      ### CV ###
      outdf[pos,2] <- as.numeric(unlist(strsplit(x = FileInput[grep(pattern = "CV",FileInput)], split = ":"))[2])

      ### Iters ###
      tmp <- unlist(strsplit(x = FileInput[grep(pattern = "Converged in",FileInput)], split = "\\("))[1]
      outdf[pos,3] <-as.numeric(gsub(pattern = " iterations ", replacement = "", x = gsub(pattern = "Converged in ", replacement = "", x = tmp)))
      rm(tmp)
    }

    write.table(x = outdf, file = paste(out.file,"_CVdata.txt",sep=""), sep = "\t", row.names = F, col.names = T, quote = F)


    ### Plot ###
    par(mfrow=c(2,1))


    to_add <- elbow_finder(outdf[,1], outdf[,2])
    # CV
    plot(outdf[,1], outdf[,2], type="b", col="red",
         xlab="", ylab="", #main= "Prediction error (CV error)",
         axes = FALSE,
         xlim=c(as.numeric(minK),as.numeric(maxK)))
    mtext("Prediction error (CV error)", side=2, line=2.7, cex=plot.cex.lab.y)
    mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.lab.x)
    axis(2, cex.axis=plot.cex.axis.y)
    axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)
    points(outdf[which(outdf[,2] %in% min(outdf[,2])),c(1,2)], col="purple", pch=4, cex=2)
    if (length(K.to.plot) != 0){
      points(outdf[which(outdf[,1] %in% K.to.plot),c(1,2)],col="red", pch=19)
    }

    # Iters
    plot(outdf[,1], outdf[,3], type="b", col="blue",
         xlab="", ylab="", # main= "Number of iterations",
         axes = FALSE,
         xlim=c(as.numeric(minK),as.numeric(maxK)))
    mtext("Number of iterations", side=2, line=2.7, cex=plot.cex.lab.y)
    mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.lab.x)
    axis(2, cex.axis=plot.cex.axis.y)
    axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)
    points(outdf[which(outdf[,3] %in% min(outdf[,3])),c(1,3)], col="purple", pch=4, cex =2)
    abline(v=to_add, col="red", lty= "dashed")
    if (length(K.to.plot) != 0){
      points(outdf[which(outdf[,1] %in% K.to.plot),c(1,3)],col="blue", pch=19)
    }
    garbage <- dev.off()


  }else{

    ##########################
    ##### FastStructure ######
    ##########################
    if (software %in% c("FastStructure","faststructure","FASTSTRUCTURE", "Faststructure")){

      ### Infile checking ###
      for (k in minK:maxK){
        fname <- paste(in.file,".",k,".meanQ",sep="")
        if (file.exists(fname) == FALSE){
          cat(paste("Q file ",fname," not found. Please check the names! \n",sep=""))
          stop("Exit",call. = F)
        }
      }

      ### Out df ###
      outdf <- as.data.frame(matrix(NA, ncol=6, nrow=n.k))
      colnames(outdf) <- c("K","CV","CV_sd","Iters", "Marginal_Likelihood", "Structure")
      outdf[,1] <- minK:maxK

      ### Best K ###
      bestK <- rep(NA, n.k)
      names(bestK) <- minK:maxK
      bestlh <- rep(NA, n.k)
      names(bestlh) <- minK:maxK

      ##### CV, iteration, Marginal Likelihood and best K #####
      for (k in minK:maxK){
        fname.log <- paste(in.file,".",k,".log",sep="")
        fname.q <- paste(in.file,".",k,".meanQ",sep="")

        # .log file analyses #
        FileInput = readLines(fname.log)
        pos <- which(outdf[,1] == k)

        if (length(FileInput[grep(pattern = "Marginal",FileInput)]) == 0){
          cat(paste("Log files ",fname," found but not from FastStructure Please check the software argument used! \n",sep=""))
          stop("Exit",call. = F)
        }

        ### CV ###
        outdf[pos,2] <- as.numeric(unlist(strsplit(gsub(x = FileInput[grep(pattern = "CV error",FileInput)], pattern = "CV error = ", replacement = ""), split = ",")))[1]
        outdf[pos,3] <- as.numeric(unlist(strsplit(gsub(x = FileInput[grep(pattern = "CV error",FileInput)], pattern = "CV error = ", replacement = ""), split = ",")))[2]

        ### Iters ###
        outdf[pos,4] <- as.numeric(gsub(x = FileInput[grep(pattern = "Total iterations",FileInput)], pattern = "Total iterations = ", replacement = ""))

        ### Marginal likelihood ###
        outdf[pos,5] <- as.numeric(gsub(x = FileInput[grep(pattern = "Marginal Likelihood",FileInput)], pattern = "Marginal Likelihood = ", replacement = ""))
        bestlh[pos] <- outdf[pos,5]

        ### Model components used to explain structure in data ###
        Q <- read.table(fname.q, h=F, stringsAsFactors = F)
        Q <- Q/(rowSums(Q))
        N <- nrow(Q)
        C <- cumsum(sort(colSums(Q), decreasing = T))
        bestK[pos] <- sum(C<(N-1))+1
      }

      maxlh <- names(which(bestlh == max(bestlh)))
      maxstruc <- names(which(table(bestK) == max(table(bestK))))
      sink(file=paste(out.file,".log",sep=""), append = T)
      cat("\n")
      cat(paste("Model complexity that maximizes marginal likelihood = ",paste(maxlh, collapse = ", ")," \n",sep=""))
      cat(paste("Model components used to explain structure in data = ",paste(maxstruc, collapse = ", "),"\n",sep=""))
      sink()

      outdf[,6] <- rep("", nrow(outdf))
      outdf[which(outdf$K %in% as.numeric(maxstruc)),6] <- "best"

      write.table(x = outdf, file = paste(out.file,"_CVdata.txt",sep=""), sep = "\t", row.names = F, col.names = T, quote = F)


      ##### Plot #####
      par(mfrow=c(3,1))

      # CV

      to_add <- elbow_finder(outdf[,1], outdf[,2])

      cvlow <- outdf[,2] - outdf[,3]
      cvup <- outdf[,2] + outdf[,3]
      plot(outdf[,1], outdf[,2], type="b", col="red",
           xlab="", ylab="", # main= "CV error",
           axes = FALSE,
           xlim=c(as.numeric(minK),as.numeric(maxK)),
           ylim=c(min(cvlow)-0.01, max(cvup)+0.01))
      segments(outdf[,1], cvlow, outdf[,1], cvup, col="gray")
      mtext("Prediction error (CV error)", side=2, line=2.7, cex=plot.cex.lab.y)
      mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.lab.x)
      axis(2, cex.axis=plot.cex.axis.y)
      axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)


      points(outdf[which(outdf[,2] %in% min(outdf[,2])),c(1,2)], col="purple", pch=4, cex=2) # min CV
      points(outdf[which(outdf[,1] %in% as.numeric(maxstruc)),c(1,2)], col="purple", pch=5, cex=2) # Model components used to explain structure in data

      if (length(K.to.plot) != 0){
        points(outdf[which(outdf[,1] %in% K.to.plot),c(1,2)],col="red", pch=19)
      }


      # Iters
      plot(outdf[,1], outdf[,4], type="b", col="blue",
           xlab="", ylab="", #main= "Number of iterations",
           axes = FALSE,
           xlim=c(as.numeric(minK),as.numeric(maxK)))
      mtext("Number of iterations", side=2, line=2.7, cex=plot.cex.lab.y)
      mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.lab.x)
      axis(2, cex.axis=plot.cex.axis.y)
      axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)
      abline(v=to_add, col="red", lty="dashed")
      points(outdf[which(outdf[,4] %in% min(outdf[,4])),c(1,4)], col="purple", pch=4, cex =2)

      if (length(K.to.plot) != 0){
        points(outdf[which(outdf[,1] %in% K.to.plot),c(1,4)],col="blue", pch=19)
      }


      # Marginal likelihood
      plot(outdf[,1], outdf[,5], type="b", col="green4",
           xlab="", ylab="", #main= "Marginal likelihood",
           axes = FALSE,
           xlim=c(as.numeric(minK),as.numeric(maxK)))
      mtext("Marginal likelihood", side=2, line=2.7, cex=plot.cex.lab.y)
      mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.axis.x)
      axis(2, cex.axis=plot.cex.axis.y)
      axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)

      points(outdf[which(outdf[,5] %in% max(outdf[,5])),c(1,5)], col="purple", pch=4, cex =2)

      if (length(K.to.plot) != 0){
        points(outdf[which(outdf[,1] %in% K.to.plot),c(1,5)],col="green4", pch=19)
      }

      garbage <- dev.off()


    }else{

      ###############
      ##### sNMF ####
      ###############
      if (software == "sNMF"){
        ### Out df ###
        outdf <- as.data.frame(matrix(NA, ncol=4, nrow=n.k))
        colnames(outdf) <- c("K","CE(all)","CE(masked)","Iters")
        outdf[,1] <- minK:maxK

        ### CE and iteration importing ###
        for (k in minK:maxK){
          fname <- paste(in.file,".",k,".log",sep="")
          FileInput = readLines(fname)
          pos <- which(outdf[,1] == k)

          if (length(FileInput[grep(pattern = "sNMF",FileInput)]) == 0){
            cat(paste("Log files ",fname," found but not from sNMF Please check the software argument used! \n",sep=""))
            stop("Exit",call. = F)
          }

          ### CE ###
          ## all ##
          tmp <- FileInput[grep(pattern = "Cross-Entropy",FileInput)]
          outdf[pos,2] <- as.numeric(unlist(strsplit(x = tmp[grep(pattern = "(all data)",tmp)], split = "\t "))[2])
          ## masked ##
          outdf[pos,3] <- as.numeric(unlist(strsplit(x = tmp[grep(pattern = "(masked data)",tmp)], split = "\t "))[2])
          rm(tmp)

          ### Iters ###
          outdf[pos,4] <-as.numeric(unlist(strsplit(x = FileInput[grep(pattern = "Number of iterations",FileInput)], split = ":"))[2])

        }

        write.table(x = outdf, file = paste(out.file,"_CVdata.txt",sep=""), sep = "\t", row.names = F, col.names = T, quote = F)


        ### Plot ###
        par(mfrow=c(2,1))

        # CV

        to_add <- elbow_finder(outdf[,1], outdf[,2])

        plot(outdf[,1], outdf[,3], type="b", col="red",
             xlab="", ylab="", #main= "Cross-Entropy criterion",
             axes = FALSE,
             xlim=c(as.numeric(minK),as.numeric(maxK)))
        mtext("Cross-Entropy criterion (masked data)", side=2, line=2.7, cex=plot.cex.lab.y)
        mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.axis.x)
        axis(2, cex.axis=plot.cex.axis.y)
        axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)
        points(outdf[which(outdf[,3] %in% min(outdf[,3])),c(1,3)], col="purple", pch=4, cex=2)
        if (length(K.to.plot) != 0){
          points(outdf[which(outdf[,1] %in% K.to.plot),c(1,2)],col="red", pch=19)
        }

        # Iters
        plot(outdf[,1], outdf[,4], type="b", col="blue",
             xlab="", ylab="",# main= "Number of iterations",
             axes = FALSE,
             xlim=c(as.numeric(minK),as.numeric(maxK)))
        mtext("Number of iterations", side=2, line=2.7, cex=plot.cex.lab.y)
        mtext("Model complexity (K)", side=1, line=2.7, cex=plot.cex.lab.x)
        axis(2, cex.axis=plot.cex.axis.y)
        axis(1,at=minK:maxK,labels= minK:maxK, tick= T, cex.axis=plot.cex.axis.x)
        abline(v=to_add, col = "red", lty = "dashed")
        points(outdf[which(outdf[,4] %in% min(outdf[,4])),c(1,4)], col="purple", pch=4, cex =2)
        if (length(K.to.plot) != 0){
          points(outdf[which(outdf[,1] %in% K.to.plot),c(1,3)],col="blue", pch=19)
        }

        garbage <- dev.off()

      }
    }
  }
}

elbow_finder <- function(x_values, y_values, plot=FALSE) {
  # Max values to create line
  max_y_y <- max(y_values)
  max_y_x <- x_values[which.max(y_values)]
  max_x_y <- min(y_values)
  max_x_x <- x_values[which.min(y_values)]
  max_df <- data.frame(x = c(max_y_x, max_x_x), y = c(max_y_y, max_x_y))
  y_valuesORI <- y_values
  x_valuesORI <- x_values
  y_values <- y_valuesORI[1:which(y_valuesORI == max_x_y)]
  x_values <- x_valuesORI[1:which(x_valuesORI == max_x_x)]

  # Creating straight line between the max values
  fit <- lm(max_df$y ~ max_df$x)

  # Distance from point to line
  distances <- c()
  for(i in 1:length(x_values)) {
    distances <- c(distances, abs(coef(fit)[2]*x_values[i] - y_values[i] + coef(fit)[1]) / sqrt(coef(fit)[2]^2 + 1^2))
  }

  # Max distance point
  x_max_dist <- x_values[which.max(distances)]
  y_max_dist <- y_values[which.max(distances)]

  if (plot==TRUE){
    plot(x=x_valuesORI, y = y_valuesORI, type="l")
    abline(fit, col="red")
    points(x = x_max_dist, y = y_max_dist, pch=19, cex=2, col="blue")
  }

  #return(c(x_max_dist, y_max_dist))
  return((x_max_dist))
}
