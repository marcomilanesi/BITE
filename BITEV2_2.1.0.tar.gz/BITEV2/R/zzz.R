.onAttach <- function(libname, pkgname) {
  mymsg <- "Loading required package: BITEV2\n\n"
  mymsg <- paste(mymsg, "************************** BITE V2 **************************\n\n")
  mymsg <- paste(mymsg, "Thanks for using BITEV2!\n\n")
  mymsg <- paste(mymsg,"For more information use: help(package = 'BITEV2')\n")
  mymsg <- paste(mymsg,"                          browseVignettes(package = 'BITEV2')\n\n")
  mymsg <- paste(mymsg,"Citation:\n")
  mymsg <- paste(mymsg,"  Authors: Milanesi M, Litta P, Vajana E, Somenzi E,\n\t    Bomba L, Pietrucci D, Ajmone-Marsan P, Chillemi G,\n\t   Capomaccio S, Colli L.\n")
  mymsg <- paste(mymsg,"  Title: BITEV2: an R package for biodiversity analyses.\n")
  mymsg <- paste(mymsg,"  Preprint on BioRxiv.\n")
  mymsg <- paste(mymsg,"  DOI: https://doi.org/10.1101/181610.\n\n")
  mymsg <- paste(mymsg, "Dependencies: 'OptM', 'RCircos', 'SNPRelate', 'data.table', 'dplyr',\n\t       'gdsfmt', 'ggplot2', 'ggrepel', 'gridExtra', 'plotly',\n\t       'poolfstat', 'shiny','stringr'\n\n")
  mymsg <- paste(mymsg, "*************************************************************\n\n")

  packageStartupMessage(mymsg)
}

.onAttach()
