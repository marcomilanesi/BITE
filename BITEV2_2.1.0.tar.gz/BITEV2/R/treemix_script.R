#Function: treemix.scripts
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Marco Milanesi, Elia Vajana
#Contact: marco.milanesi.mm@gmail.com, vajana.elia@gmail.com
#Description: the function creates a copy of TREEMIX scripts to run the software with BITE

treemix.scripts<-function(){

  #Copy scripts to run treemix to current directory
  file.copy(system.file("scripts","treemix_scripts.tar.bz2", package = "BITEV2"), "treemix_scripts.tar.bz2")
  untar("treemix_scripts.tar.bz2")
  file.remove("treemix_scripts.tar.bz2")
}
