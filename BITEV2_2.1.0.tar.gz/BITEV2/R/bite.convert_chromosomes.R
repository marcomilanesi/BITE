

################################################################################
########################## BITE CONVERT_CHROMOSOMES ############################
################################################################################

##### BITE.CONVERT_CHROMOSOMES
# Prende in input il file bim/map e converte all'interno dello stesso file tutti
# i cromosomi X, Y, XY, MT/M
#
# Parametri:
# file = map / bim path
# num_autosomes = a seconda della specie (default = 22)


bite.convert_chromosomes <- function(file, num_autosomes = 22) {

  cat(paste("Bite.convert_chromosomes() will modify the file ", basename(file),
            ". Continue?\n- Yes (1)\n- No (2)\n", sep=""))
  choiche <- readline()
  if (choiche == 2) {
    stop("Exit", call. = F)
  }

  cat("Running ....\n")
  # open file
  tmp.file <- read.table(file)

  # new file
  #new.basename <- str_sub(basename(file))
  #new.path <- dirname(file)
  #if (is.null(new.file)) {
  #  new.file = paste(new.path, "/modified_", new.basename, sep="")
  #}

  # change X, Y, XY and MT/M
  for (i in 1:length(tmp.file[,1])) {
    if (tmp.file[i, 1] == "X") {
      tmp.file[i, 1] <- num_autosomes + 1
    } else if ((tmp.file[i, 1] == "Y")) {
      tmp.file[i, 1] <- num_autosomes + 2
    } else if ((tmp.file[i, 1] == "XY")) {
      tmp.file[i, 1] <- num_autosomes + 3
    } else if (tmp.file[i, 1] %in% c("M", "MT")) {
      tmp.file[i, 1] <- num_autosomes + 4
    }
  }

  write.table(tmp.file, file, quote = F, row.names = F, col.names = F)
}

