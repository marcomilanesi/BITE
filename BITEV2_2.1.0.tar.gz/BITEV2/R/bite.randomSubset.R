

################################################################################
############################# BITE RANDOM SUBSET ###############################
################################################################################

bite.randomSubset <- function(gds.path, out.dir, gds.out = "randomSubset.gds", dim.id = NULL, dim.snp = NULL) {
  cat("Running ....\n")

  ########## COPY ##########
  randomSub.gds.path <- paste(out.dir, "/", gds.out, sep="")
  file.copy(gds.path, randomSub.gds.path, overwrite = TRUE)

  ########## OPEN ##########
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(randomSub.gds.path)

  ########## INFO ##########
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  snp.position <- read.gdsn(index.gdsn(gds.in, "snp.position"))
  snp.chromosome<- read.gdsn(index.gdsn(gds.in, "snp.chromosome"))
  snp.allele <- read.gdsn(index.gdsn(gds.in, "snp.allele"))
  genotype <- snpgdsGetGeno(gds.in, verbose = F)
  phenotype <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))

  ########## CHECK DIM.ID / DIM.SNP ##########
  if (!is.null(dim.id)) {
    # prendi un campione random di dimensioni dim.id dal dataset
    new.sample.id <- sample(sample.id, dim.id, replace = F)

    # da sample id devi aggiornare genotype, phenotype e ordermatrix
    id.bool <- sample.id %in% new.sample.id
    new.genotype <- genotype[id.bool, ]

    new.phenotype <- phenotype[id.bool, ]
    rownames(new.phenotype) <- NULL

    pop.bool <- ordermatrix$V1 %in% unique(new.phenotype$pop)
    new.ordermatrix <- ordermatrix[pop.bool, ]
    rownames(new.ordermatrix) <- NULL
  } else {
    new.genotype <- genotype
    new.sample.id <- sample.id
    new.phenotype <- phenotype
    new.ordermatrix <- ordermatrix
  }

  if (!is.null(dim.snp)) {
    new.snp.id <- sample(snp.id, dim.snp, replace = F)

    # da snp.id devi aggiornare snp.chromosome, snp.allele, snp.pos, genotype
    snp.index <- snp.id %in% new.snp.id
    new.snp.chromosome <- snp.chromosome[snp.index]
    new.snp.position <- snp.position[snp.index]
    new.snp.allele <- snp.allele[snp.index]
    new.genotype  <- new.genotype[, snp.index]
  } else {
    new.snp.id <- snp.id
    new.snp.chromosome <- snp.chromosome
    new.snp.position <- snp.position
    new.snp.allele <- snp.allele
  }

  ########### AGGIORNA IL GDS ###########

  showfile.gds(closeall = T, verbose = F)

  gds.in <- snpgdsOpen(randomSub.gds.path, readonly = F)
  update.gds(gds.in, new.sample.id, new.snp.chromosome, new.snp.id, new.snp.position, new.snp.allele,
             new.genotype, new.phenotype, new.ordermatrix)

  return (gds.in)
}
