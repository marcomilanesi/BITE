#Script: treemix.fit
#License: GPLv3 or later
#Modification date: 2017-05-10
#Written by: Elia Vajana, Marco Milanesi
#Contact: vajana.elia@gmail.com, marco.milanesi.mm@gmail.com
#Description: Model fitting variance of treemix trees

treemix.fit = function(
    in.file,
    out.file="tmp",
    m.start=0,
    m.end=0
){

  # Number of migrations tested
  n.mig <- (m.end - m.start) + 1
  mig <- m.start:m.end

  ##### Log file #####
  sink(file=paste(out.file,".log",sep=""))
  cat(date(),"\n\n")
  cat(paste("Input file:",in.file,"\n"))
  cat(paste("Output file:",out.file,"\n"))
  cat(paste("Migrations analysed: from",m.start,"to",m.end,"\n"))
  sink()

  ### Dataframe where results for each m are stored ###
  overall <- as.data.frame(matrix(NA, ncol=6, nrow=n.mig))
  colnames(overall) <- c("m","Var.expl","msign","perc","llik_0","llik_m")


  ##### Migration edges evaluation #####
  for (pos in (1:n.mig)){
    # find the migration
    n <- mig[pos]
    tmpfile <- paste(in.file,n,sep="")
    overall[pos,1] <- n

    ##### Information on migration edges #####
    ### Only m > 0 are evaluated ###
    if (n != 0){
      ### Import .treeout file ###
      df <- read.table(paste(tmpfile,".treeout.gz",sep=""), skip = 1, sep=" ", h=F, stringsAsFactors = F)
      ### Create output dataframe ###
      outdf <- as.data.frame(matrix(NA, ncol=6, nrow = nrow(df)))
      colnames(outdf) <- c("stree.don", "stree.rec", "edge.weight", "edge.weight.jk", "jk.st.err", "pvalue")
      ### import information from the input file ###
      outdf[,3:6] <- df[,1:4]
      outdf[,6] <- as.numeric(gsub(pattern = "<", replacement = "", x = outdf[,6]))

      ### To report donor and receiving pops, extra infos are removed
      ### DONOR GROUPS ###
      donor <- df[,5]
      for (a in 1:length(donor)){
        # Split the file
        tmp <- unlist(strsplit(donor[a], split = ":"))
        # Check if there is "," or "(" [more than one pops]
        posd <- length(grep(pattern = "\\(", x = tmp)) + length(grep(pattern = ",", x = tmp))
        if (posd >= 1){
          rm(posd)
          listdonor <- NULL
          # Only string with "," or "(" are kept because the name of the population is there [string with populations' names] (per me NON CHIARO)
          tmp2 <- unique(c(tmp[grep(",", x = tmp)], tmp[grep("\\(", x = tmp)]))
          # Name extraction
          for (b in 1:length(tmp2)){
            posd <- length(grep(pattern = "\\(", x = tmp2[b]))
            if (posd >= 1){
              ppp <- unlist(strsplit(tmp2[b], split = "\\("))
              listdonor <- c(listdonor,ppp[length(ppp)])
            }else{
              ppp <- unlist(strsplit(tmp2[b], split = ","))
              listdonor <- c(listdonor,ppp[length(ppp)])
            }
            rm(posd)
          }
          # Write the donor list in the file
          # outdf[a,1] <- paste(listdonor, collapse = ", ")
          outdf[a,1] <- listdonor[1]
        }else{
          outdf[a,1] <- tmp[1]
        }
      }

      ### RECEIVING GROUPS ###
      receiving <- df[,6]
      for (a in 1:length(receiving)){
        # Split the file
        tmp <- unlist(strsplit(receiving[a], split = ":"))
        # Check if there is "," or "(" [more than one pops]
        posr <- length(grep(pattern = "\\(", x = tmp)) + length(grep(pattern = ",", x = tmp))
        if (posr >= 1){
          rm(posr)
          listdonor <- NULL
          # Only string with "," or "(" are kept becuase the name of the population is there [string with populations' names] (VEDI SOPRA)
          tmp2 <- unique(c(tmp[grep(",", x = tmp)], tmp[grep("\\(", x = tmp)]))
          # Name extraction
          for (b in 1:length(tmp2)){
            posr <- length(grep(pattern = "\\(", x = tmp2[b]))
            if (posr >= 1){
              ppp <- unlist(strsplit(tmp2[b], split = "\\("))
              listdonor <- c(listdonor,ppp[length(ppp)])
            }else{
              ppp <- unlist(strsplit(tmp2[b], split = ","))
              listdonor <- c(listdonor,ppp[length(ppp)])
            }
            rm(posr)
          }
          # Write the donor list in the file
          # outdf[a,2] <- paste(listdonor, collapse = ", ")
          outdf[a,2] <- listdonor[1]
        }else{
          outdf[a,2] <- tmp[1]
        }
      }

      # Write outfile
      write.table(x = outdf, file = paste(out.file,"_m",n,".txt",sep=""), quote = F, sep = "\t", row.names = F, col.names = T)
    }


    ##### Variance #####
    ### Import observed and expected covariance matrices ###
    Wobs <- read.table(gzfile(paste(tmpfile, ".cov.gz", sep="")), as.is=T, head=T, quote="", comment.char="")
    Wexp <- read.table(gzfile(paste(tmpfile, ".modelcov.gz", sep="")), as.is=T, head=T, quote="", comment.char="")
    names(Wobs) <- rownames(Wobs)
    names(Wexp) <- rownames(Wexp)
    Wobs <- Wobs[order(names(Wobs)), order(names(Wobs))]
    Wexp <- Wexp[order(names(Wexp)), order(names(Wexp))]

    ### Matrix of residual ###
    R <- Wobs - Wexp
    mod.res <- as.numeric(R[1, 2:ncol(R)])
    for (i in 2:(nrow(R)-1)) {
      mod.res <- c(mod.res, as.numeric(R[i, ((i+1):ncol(R))]))
    }
    ### Mean residual of the residual matrix ###
    Rmean <- (sum(mod.res) / ((nrow(R)*(nrow(R)-1))/2))

    ### MEAN VALUE OF THE OBSERVED COVARIANCE MATRIX ###
    ObsCovariances <- as.numeric(Wobs[1, 2:ncol(Wobs)])
    for (i in 2:(nrow(Wobs)-1)) {
      ObsCovariances <- c(ObsCovariances, as.numeric(Wobs[i, ((i+1):ncol(Wobs))]))
    }
    Wobsmean <- (sum(ObsCovariances) / ((nrow(Wobs)*(nrow(Wobs)-1))/2))

    ### FRACTION f OF THE VARIANCE IN RELATEDNESS BETWEEN POPULATIONS THAT'S ACCOUNTED FOR BY THE MODEL (see eqn. 30; Pickrell & Pritchard, 2012) ###
    f <- round((1 - (sum((mod.res - Rmean)^2) / sum((ObsCovariances - Wobsmean)^2))), 5)
    overall[pos, 2] <- f

    ##### Significant migrations #####
    if (n == 0) {
      overall[pos, 3] <- 0
      overall[pos, 4] <- 0
    } else if (n > 0) {
      msign <- read.table(paste(out.file,"_m",n, ".txt", sep=""), h=T)
      overall[pos, 3] <- as.numeric(length(which(msign[, 6] <= 0.05)))
      overall[pos, 4] <- (as.numeric(length(which(msign[, 6] <= 0.05))) / nrow(msign)) * 100
      rm(msign)
    }

    ##### Likelihood of the tested models #####
    llik <- read.table(paste(in.file,n,".llik", sep=""))
    overall[pos, 5] <- llik[1, 7]
    overall[pos, 6] <- llik[2, 7]
  }

  ### Write the results in a file ###
  write.table(overall, paste(out.file,"_overall.txt",sep=""), col.names=T, row.names=F, sep="\t", quote=FALSE)


  ##### Plot f for each migration edge tested #####
  pdf(paste(out.file,"_ModelFit.pdf",sep=""), 12, 7)
  par(oma = c(4, 2, 4, 2))
  plot(overall[, 1], overall[, 2], ylim=c(min(overall[, 2]), 1), xlab="# migrations events assumed", ylab="f", t="l",col="red", xaxt="n")
  axis(1, overall[, 1])
  abline(h=1, col="gray", lty=3)
  garbage <- dev.off()
}
