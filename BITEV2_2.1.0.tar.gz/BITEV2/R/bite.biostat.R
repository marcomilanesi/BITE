source("R/bite.functions.R", local = TRUE)
################################################################################
################################# BITE BIOSTAT #################################
################################################################################


bite.biostat <- function(gds.path, out.dir,  n.k = 3, report = FALSE, ws.save = FALSE, flagMDS = TRUE, flagPCA = TRUE, plotFormat = "pdf", HetObs.all = FALSE, snp.random.subset = NULL, dist.method = NULL, fst.method = NULL, ...) {


  #### OPEN GDS
  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  # take data
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.num <- length(snp.id)
  sample.num <- length(sample.id)

  ##### CHECK SNP.RANDOM.SUBSET #####
  if (is.null(snp.random.subset)) {

    # check num of snps
    if (snp.num >= 200000 & sample.num >= 500) {
      # warning message
      cat(paste("Warning: ", basename(gds.in$filename), " contains ", snp.num, " snps & ", sample.num, " individuals.\n", sep=""))
      cat("Bite.biostat() may take a long time.\nConsider the idea of using only a random subset of snps for IBD/PCA analysis:\n")
      cat("- Yes (1)\n")
      cat("- No (2)\n")

      choice <- readline()

      if (choice == 1) {
        cat("Enter the number of snps to consider: ")
        snp.random.subset <- readline()
        snp.random.subset <- as.numeric(snp.random.subset)

        if (snp.random.subset >= snp.num || snp.random.subset <= 0) {
          cat("Invalid value!\n")
          stop("Exit", call.=F)
        }
      } else if (choice == 2) {
        snp.random.subset <- snp.num
      } else {
        cat("Invalid selection .... \n")
        stop("Exit", call.=F)
      }
    }
  }

  if (snp.random.subset == snp.num || is.null(snp.random.subset)) {
    snp.sample <- snp.id
  } else {
    snp.sample <- sample(snp.id, snp.random.subset, replace = F)
  }

  cat("Running.....\n")
  ##### HET.OBS.ALL CHECK #####
  # HetObs.all -> consider missing genotypes for het calc
  start <- proc.time()
  options(warn=-1)

  ##### FILENAME #####
  name <- basename(gds.in$filename)
  filename <- str_sub(name, start=1, end=-5)

  #### RES DIR ####
  res.dir <- paste0(out.dir, "/biostat_", filename)
  if (!file.exists(res.dir)) {
    dir.create(res.dir)
  }

  ##### LOG FILE #####
  logname <- paste(res.dir, "/biostat_", filename, ".log", sep="")
  sink(file=logname)
  cat(date(),"\n\n")
  cat("**********************************************\n")
  cat(paste("Working dir: ", res.dir, "\n", sep=""))
  cat(paste("Input file: ", name, "\n", sep=""))
  sink()

  ##### CHECK DIST PARAMS #####
  if (!is.null(dist.method)) {
    if (!(dist.method %in% c("euclidean", "maximum", "manhattan", "canberra", "binary", "minkowski"))) {
      cat("Invalid distance method!")
      stop("Exit", call. = F)
    }
  }

  ##### CHECK FST METHOD #####
  if (!is.null(fst.method)) {
    if (!(fst.method %in% c("W&C84", "W&H02"))) {
      cat("Invalid fst method!")
      stop("Exit", call. = F)
    }
  }

  ##### PLOT FORMAT #####
  sink(file=logname, append=T)
  formats <- c("pdf", "png", "jpeg")
  if (!(plotFormat %in% formats)) {
    cat("Invalid format\n")
    break
  }
  cat(paste("Plots format: ", plotFormat, "\n", sep=""))
  sink()

  ##### WS SAVE #####
  if (ws.save == TRUE){
    save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
  }

  ##### OUT FILES #####
  nfile=paste(res.dir,"/",filename,"_GeneralStats.txt",sep="")
  nfile.ind=paste(res.dir,"/IND/",filename,"_IndStats.txt",sep="")
  nfile.snp=paste(res.dir,"/SNP/",filename,"_SNPStats.txt",sep="")

  sink(file=nfile)
  cat("**************** BITE.BIOSTAT ****************\n\n")
  sink()

  ##### PHENO INFO #####
  sink(logname, append = T)
  cat("Extract pheno data from gds file...\n")
  fam <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  uniqpop <- sort(unique(fam$pop))
  sink()


  sink(file=nfile, append=T)
  cat("***** Pop Info *****")
  print(table(fam$pop)) # table ordina alfabeticamente
  cat("********************\n")
  sink()

  ##### POPULATION ORDER & COLORS #####

  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))

  if (length(ordermatrix[,1]) > 1) {
    sink(file=logname, append=T)
    cat(paste("Save group labels within ", basename(res.dir), " directory ...\n", sep=""))
    # Breed code
    pdf(paste(res.dir,"/",filename,"_PopCode.pdf",sep=""), width = 18, height = 9)
    tmp <- ceiling(sqrt(length(ordermatrix[,1])))
    plot(0,0,type="n",xlim=c(0,tmp*7), ylim=c(0,tmp*7),yaxt="n", xaxt="n", frame.plot=F, xlab="", ylab="")
    legend(0,tmp*7,ordermatrix[,1], ncol=floor(tmp/2), col=ordermatrix[,2], lty=0,pch=as.numeric(ordermatrix[,3]), cex=0.75)
    garbage <- dev.off()
    rm(tmp)
    sink()
  }
  ################################################################################
  ############################ BASIC STATISTICS ##################################
  ################################################################################

  ##### DIST #####
  if (!is.null(dist.method)) {
    sink(logname, append = T)
    cat("Calculate dist ....\n")
    geno <- snpgdsGetGeno(gds.in, verbose = F)
    tmp.dist <- dist(geno, method = dist.method)
    tmp.dist.m <- as.matrix(tmp.dist)
    tmp.dist.df <- data.frame(tmp.dist.m)
    #saveRDS(tmp.dist, paste(res.dir, "/", dist.method, "_dist.rds", sep=""))
    write.table(tmp.dist.df, file = paste(res.dir, "/", dist.method, "_dist.txt", sep=""), quote = F)
    rm(geno, tmp.dist)
    sink()
  }

  ##### FST #####
  if(!is.null(fst.method)) {
    sink(logname, append = T)
    pheno <- read.gdsn(index.gdsn(gds.in, "phenotype"))
    pop <- as.factor(pheno$pop)
    cat("Calculate Fst ....\n")
    sink()
    sink(nfile, append = T)
    fstat.res <- snpgdsFst(gds.in, population = pop, method = fst.method, verbose = F)
    cat("\n********** FST **********\n")
    cat(" - Fst:", fstat.res$Fst, "\n")
    cat(" - Mean Fst:", fstat.res$MeanFst, "\n")
    sink()
    write.table(fstat.res$FstSNP, paste(res.dir, "/", filename, "_FstSNP.txt", sep=""), quote = F)
  }



  ##### SNP STATS #####
  sink(file=logname, append = T)
  SNPstats <- snpStats(gds.in, res.dir, nfile.snp)
  sumSNPstats <- summary(SNPstats)

  ##### ID STATS #####
  IDstats <- idStats(gds.in, res.dir, nfile.ind)
  sumIDstats <- summary(IDstats)
  sink()

  ##### STATS OVERVIEW #####
  sink(file=nfile, append=T)
  cat("\n*********************************************\n")
  cat("\n\n***** Per Marker stats ***** \n")
  cat("\n*** Summary ***\n")
  print(sumSNPstats)
  #Call Rate
  cat("\n\n*** Call rate ***\n")
  crate<- SNPstats$Call.rate
  cat("\nSummary ->\n")
  print(summary(crate))
  cat("\nDistribution\n")
  cat(catable(crate,c(seq(0.75,1,0.05)), cumulative = F))
  cat("\nCumulative Distribution\n")
  cat(catable(crate,c(seq(0.75,1,0.05)), cumulative = T))

  cat("\n\n*** MAF ***\n")
  maf <- SNPstats$maf
  cat("\nSummary -> \n")
  print(summary(maf))
  cat("\nCumulative Distribution\n")
  cat(catable(maf,c(seq(0,0.1,0.01)),cumulative = T))

  cat("\n\n*** H-W eq ***\n")
  hwp <- SNPstats$HWE_p
  cat("\nSummary -> \n")
  print(summary(hwp))
  cat("\nDistribution\n")
  ## NOTA: nsnps() non disponibile, devo ricercare una funzione analoga
  #print(catable(hwp,c(0.05/nsnps(MyData),1/100000,1/10000,.01,0.05)))
  cat(catable(hwp,c(1/100000,1/10000,.01,0.05)))
  cat("\nCumulative Distribution\n")
  #print(catable(hwp,c(0.05/nsnps(MyData),1/100000,1/10000,.01,0.05),cumulative = T))
  cat(catable(hwp,c(1/100000,1/10000,.01,0.05),cumulative = T))
  cat("\n\n")

  cat("***** Per ID stats ***** \n")
  cat("\n*** Summary ***\n")
  print(sumIDstats)
  # ID call
  idcall<-IDstats$Call.rate
  cat("\n\n*** ID call ***\n")
  cat("\nSummary ->\n")
  print(summary(idcall))
  cat("\nDistribution\n")
  cat(catable(idcall,c(seq(0.75,1,0.05)), cumulative = F))
  cat("\nCumulative Distribution\n")
  cat(catable(idcall,c(seq(0.75,1,0.05)), cumulative = T))

  # Het
  if (HetObs.all == TRUE) {
    het <- IDstats$HetObs.all
  } else {
    het <- IDstats$HetObs.call
  }
  cat("\n\n*** ID heterozygosity ***\n")
  cat("\nDistribution\n")
  print(summary(het))
  cat("\nDistribution\n")
  cat(catable(het,c(seq(0,1,0.05))))
  cat("\n\n")
  sink()

  ##### PLOTTING #####
  sink(logname, append=T)
  cat("SNP stats plots creation ...\n")
  sink()
  ## SNP STATS
  p1 <- ggplot(SNPstats, aes(x= Call.rate)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(x = "Call Rate", y = "Count", title="SNP Call Rate") +
    geom_vline(xintercept = c(0.90, 0.95, 0.99), linetype = "dashed", color = "black") +
    theme_bw()
  p2 <- ggplot(SNPstats, aes(x = maf)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(x = "Maf", y = "Count", title="MAF") +
    theme_bw()
  p3 <- ggplot(SNPstats, aes(x = HWE_p)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(x = "HWE p", y = "Count", title="HWE P-value") +
    theme_bw()
  dens <- densCols(SNPstats$Call.rate, SNPstats$maf)
  p4 <- ggplot(SNPstats) +
    geom_point(aes(x=Call.rate, y=maf, color = dens)) +
    scale_color_identity() +
    geom_vline(xintercept = c(.90, .95, .99), col="black", linetype="dashed") +
    geom_hline(yintercept = c(0.01, 0.05, 0.1), col = "black", linetype="dashed") +
    labs(x="Call rate", y = "Maf", title="Plot of Call Rate VS MAF") +
    theme_bw() +
    theme(legend.position = "none")
  grid_arr <- grid.arrange(p1, p2, p3, p4, ncol = 2, nrow = 2)
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_Stats.", plotFormat,sep=""),plot = grid_arr,  width = 12, height = 9)

  # PLot MAF
  p <- ggplot(SNPstats, aes(x = maf)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(title="MAF", x="Maf", y="Count") +
    theme_bw()
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_MAF.", plotFormat,sep=""), width = 12, height = 9)

  # MAF density
  p <- ggplot(SNPstats, aes(x = maf)) +
    geom_density(color="midnightblue", fill="skyblue", alpha=0.1) +
    labs(title="MAF Density", x="Maf", y="Density") +
    theme_bw()
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_MAF_density.",plotFormat, sep=""), width = 12, height = 9)

  # MAF zoom
  p <- ggplot(SNPstats, aes(x = maf)) +
    geom_histogram(binwidth = 0.002, color = "black", fill = "#A50021", alpha = 0.85) +
    labs(title="MAF zoom", x="Maf", y="Count") +
    scale_x_continuous(limits = c(0, 0.101), breaks = seq(0, 0.1, 0.01)) +
    geom_rug() +
    theme_bw()
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_MAF_zoom.", plotFormat,sep=""), width = 12, height = 9)

  p <- ggplot(SNPstats, aes(x= Call.rate)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(x = "Call rate", title = "SNP Call Rate", y ="Count") +
    geom_vline(xintercept = c(0.90, 0.95, 0.99), linetype = "dashed", color = "black") +
    theme_bw()
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_CR.", plotFormat ,sep=""), width = 12, height = 9)

  p <- ggplot(SNPstats, aes(x = Call.rate)) +
    geom_histogram(binwidth = 0.002, color = "black", fill = "#A50021", alpha = 0.85) +
    labs(x = "Call rate", title = "SNP Call Rate zoom", y="Count") +
    scale_x_continuous(limits = c(0.89, 1.01), breaks = seq(0.90, 1, 0.05)) +
    geom_vline(xintercept = c(0.90, 0.95, 0.99), linetype = "dashed", color = "black") +
    geom_rug(linewidth = 0.1) +
    theme_bw()
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_CR_zoom.", plotFormat,sep=""), width = 12, height = 9)

  # PLot CR vs MAF
  p <- ggplot(SNPstats) +
    geom_point(aes(x=Call.rate, y=maf, color = dens)) +
    scale_color_identity() +
    geom_vline(xintercept = c(.90, .95, .99), col="black", linetype="dashed") +
    geom_hline(yintercept = c(0.01, 0.05, 0.1), col = "black", linetype="dashed") +
    theme_bw() +
    labs(x="Call rate", y = "MAF", title="Plot of Call Rate VS MAF") +
    theme(legend.position = "none")
  ggsave(paste(res.dir,"/SNP/",filename,"_SNP_MAF_vs_CR.", plotFormat,sep=""), width = 12, height = 9)

  sink(logname, append = T)
  cat("ID stats plots creation ....\n")
  sink()

  # IND STATS PLOTS
  tmphet <- het
  tmphet[is.na(tmphet)] <-0
  temp <- data.frame(pop = factor(fam$pop), id = fam$id, idcall = IDstats$Call.rate, het = tmphet)

  p1 <- ggplot(data=temp, aes(x=idcall)) +
    geom_histogram(binwidth = 0.005, color="black", fill="#A50021", alpha=0.85) +
    geom_vline(xintercept = c(.90,.95,.99), color="black", linetype= "dashed") +
    labs(title="Individual Call Rate", y="Count", x="ID") +
    theme_bw()

  p2 <- ggplot(temp, aes(x = het)) +
    geom_histogram(binwidth = 0.01, fill = "#A50021", color = "black", alpha=0.85) +
    labs(title = "Individual Observed Heterozygosity", x="Count", y="Observed Heterozygosity") +
    theme_bw()
  temp$scalIDcall <- 1- temp$idcall
  temp$pop <- factor(temp$pop, levels = ordermatrix$V1)
  p3 <- ggplot(data = temp, aes(x = id, y=scalIDcall, fill=pop)) +
    geom_bar(stat = "identity", position = "dodge", alpha = 0.75) +
    scale_x_discrete(limits = unique(temp$id)) +
    scale_fill_manual(values= ordermatrix$V2) +
    labs(title = "Barplot of Individual Call Rate", y = "Call rate") +
    theme_classic() +
    if (length(ordermatrix[,1]) > 36) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }

  p4 <- ggplot(data = temp, aes(x = id, y=het, fill=pop)) +
    geom_bar(stat = "identity", position = "dodge", alpha = 0.75) +
    scale_x_discrete(limits = unique(temp$id)) +
    scale_fill_manual(values= ordermatrix$V2) +
    labs(title = "Barplot of Observed Heterozygosity", y = "Obs.Het") +
    theme_classic() +
    if (length(ordermatrix[,1]) > 36) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }

  grid_arr <- grid.arrange(p1, p2, p3, p4, ncol = 2, nrow = 2)
  ggsave(paste(res.dir,"/IND/",filename,"_IND_Stats.", plotFormat,sep=""), plot = grid_arr, width = 12, height = 9)

  # ID CALL RATE VS HET (ho rimosso i simboli)
  p <- ggplot(data=temp, aes(x=0, y=0)) +
    geom_point(aes(x=idcall,y=tmphet, color = pop, shape=pop)) +
    scale_shape_manual(values = ordermatrix$V3) +
    scale_x_continuous(limits = c(min(idcall)-0.06, 1)) +
    scale_y_continuous(limits = c(min(het, na.rm = T)-0.06, max(het, na.rm = T)+0.06)) +
    geom_hline(yintercept = c(mean(het, na.rm = TRUE) + (3 * sd(het, na.rm = TRUE)),
                              mean(het, na.rm = TRUE) - (3 * sd(het, na.rm = TRUE))),
               color = rgb(1, 0, 0, 0.8),
               linetype = "dashed") +
    geom_vline(xintercept = c(0.90, 0.95, 0.99),
               color = "black",
               linetype = "dashed") +
    scale_color_manual(values = ordermatrix$V2) +
    labs(x="ID Call Rate", y="Observed Heterozygosity", title="CR vs Obs.Het") +
    theme_bw() +
    if (length(ordermatrix[,1]) > 54) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }
  ggsave(paste(res.dir,"/IND/",filename,"_IND_CR_vs_HET.", plotFormat,sep=""), width = 12, height = 9)

  # Plot ID CR
  #spazi <- ceiling((max(idcall)-min(idcall))/0.005)
  #if (spazi < 10){spazi <- 10}
  #if (spazi > 100){spazi <- 100}
  p <- ggplot(data=temp, aes(x=idcall)) +
    geom_histogram(binwidth = 0.005, color="black", fill="#A50021", alpha=0.85) +
    geom_vline(xintercept = c(.90,.95,.99), color="black", linetype= "dashed") +
    #scale_x_continuous(breaks = spazi)
    labs(x="Call rate", title="Individual Call Rate", y="Count") +
    theme_bw()
  ggsave(paste(res.dir,"/IND/",filename,"_IND_CR_hist.", plotFormat,sep=""), width = 12, height = 9)

  # PLOT ID CR ZOOM
  p <- ggplot(data=temp, aes(x=idcall)) +
    geom_histogram(binwidth = 0.005, color="black", fill="#A50021", alpha=0.85) +
    geom_vline(xintercept = c(.90,.95,.99), color="black", linetype= "dashed") +
    scale_x_continuous(limits = c(0.9, 1.01), breaks = seq(0.90, 1, 0.02)) +
    labs(x="Call rate", title = "Individual Call Rate", y = "Count") +
    theme_bw()
  ggsave(paste(res.dir,"/IND/",filename,"_IND_CR_hist_zoom.", plotFormat,sep=""), width = 12, height = 9)

  # PLOT IND CR pop -> non ho messo le etichette sotto, sono già presenti di lato tanto
  p <- ggplot(data = temp, aes(x = id, y=scalIDcall, fill=pop)) +
    geom_bar(stat = "identity", position = "dodge", alpha = 0.75) +
    scale_x_discrete(limits = unique(temp$id)) +
    scale_fill_manual(values= ordermatrix$V2) +
    labs(y="Call Rate", title="Barplot of Individual Call Rate", x="Id") +
    theme_classic() +
    if (length(ordermatrix[,1]) > 54) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }
  ggsave(paste(res.dir,"/IND/",filename,"_IND_CR.", plotFormat,sep=""), width = 24, height = 18)

  p <- ggplot(data = temp, aes(x = id, y=het, fill=pop)) +
    geom_bar(stat = "identity", position = "dodge", alpha = 0.75) +
    scale_x_discrete(limits = unique(temp$id)) +
    scale_fill_manual(values= ordermatrix$V2) +
    theme_classic() +
    labs(y = "Observed Heterozygosity", title="Barplot of Observed Heterozygosity", x="Id") +
    if (length(ordermatrix[,1]) > 54) {
      theme(axis.text.x = element_blank(), legend.position = "none")
    } else {
      theme(axis.text.x = element_blank())
    }
  ggsave(paste(res.dir,"/IND/",filename,"_IND_HET.", plotFormat,sep=""), width = 24, height = 18)

  # IND HET BOXPLOT
  p <- ggplot(temp, aes(x= pop, y=het, fill=pop)) +
    geom_boxplot(alpha = 0.75) +
    scale_fill_manual(values = ordermatrix$V2) +
    theme_bw()+
    labs(title="Boxplot of Observed Heterozygosity", x="Pop", y = "Observed Heter cvozygosity") +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1), legend.position = "none")
  ggsave(paste(res.dir,"/IND/",filename,"_IND_HET_boxplot.", plotFormat,sep=""), width = 24, height = 18)

  # IND HET BEANPLOT
  if (length(ordermatrix$V1) > 40) {
    p <- ggplot(temp, aes(x= pop, y=het, fill=pop)) +
      geom_violin(alpha=0.75, scale = "width") +
      geom_boxplot(color = "black", fill = NA) +
      geom_jitter(alpha = 0.2, position = position_jitter(width = .1)) +
      scale_fill_manual(values = ordermatrix$V2) +
      labs(title="Beanplot of Observed Heterozygosity", x="Pop", y = "Observed Heterozygosity") +
      theme_bw()+
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1), legend.position = "none")
      ggsave(paste(res.dir,"/IND/",filename,"_IND_HET_beanplot.", plotFormat,sep=""), width = 24, height = 18)
  } else {
    p <- ggplot(temp, aes(x= pop, y=het, fill=pop)) +
      geom_violin(alpha=0.75) +
    geom_boxplot(color = "black", fill = NA) +
      geom_jitter(alpha = 0.2, position = position_jitter(width = .1)) +
      scale_fill_manual(values = ordermatrix$V2) +
      labs(title="Beanplot of Observed Heterozygosity", x="Pop", y = "Observed Heterozygosity") +
      theme_bw()+
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1), legend.position = "none")
    ggsave(paste(res.dir,"/IND/",filename,"_IND_HET_beanplot.", plotFormat,sep=""), width = 24, height = 18)
  }

  ################################################################################
  ###################### ANALYSIS BASED ON IBS/IBD MATRIX ########################
  ################################################################################

  ##### WS SAVE #####
  if (ws.save == TRUE){
    save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
  }

  ##### CHECK NUM AUTOSOMAL MARKER #####
  sink(logname, append=T)
  cat("Check the number of autosomal chromosomes ...\n")
  chr <- read.gdsn(index.gdsn(gds.in, "snp.chromosome"))
  id_snp <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  SNPinfo <- data.frame(cbind(id_snp, chr))
  autosomal_markers <- SNPinfo[SNPinfo$chr %in% 1:max(chr),]
  autosomal_markers <- autosomal_markers$id_snp

  Refsnpsize <- 5000
  if (length(autosomal_markers) <= Refsnpsize) {
    snpsize <- length(autosomal_markers)
  }else {
    snpsize <- Refsnpsize
  }
  sink()
  ####################


  ##### IBS/IBD CALCULATION #####
  sink(logname, append=T)
  cat("Calculate IBS & IBD ...\n")
  sink()
  ibs <- snpgdsIBS(gds.in, autosome.only = TRUE, snp.id = autosomal_markers[1:snpsize], verbose = FALSE)
  ibs.dist <- as.dist(ibs$ibs)

  ibs.dist[ibs.dist == 1] <- 0

  ibd <- snpgdsIBDMoM(gds.in, autosome.only = TRUE, kinship = TRUE, verbose = FALSE, snp.id =snp.sample)
  kin <- as.dist(0.5-ibd$kinship)
  mds.15 <- cmdscale(kin, k=n.k, eig=TRUE)

  ##### SUMMARY STATS #####

  sink(file=nfile, append=T)
  cat("***** IBS evaluation *****\n")
  cat("\nSummary ->\n")
  print(summary(ibs.dist))
  cat("\nDistribution\n")
  cat(catable(as.vector(ibs.dist),c(seq(0.90,1,0.01)), cumulative = F))
  cat("\nCumulative Distribution\n")
  cat(catable(as.vector(ibs.dist),c(seq(0.90,1,0.01)), cumulative = T))
  cat("*********************************************\n\n")
  sink()

  ##### MULTI DIMENSIONAL SCALING #####

  ##### WS SAVE #####
  if (ws.save == TRUE){
    save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
  }


  if (flagMDS == TRUE){
    MDS<-paste(res.dir,"/MDS",sep="")
    sink(file=logname, append=T)
    cat("MDS analysis: running ...\n")
    if (file.exists(MDS) == FALSE) {
      dir.create(MDS)
    } else {
      cat(paste(basename(MDS), " directory already exists!\n", sep=""))
    }
    sink()
    # pc
    t <- as.data.frame(cbind(fam$pop,fam$id,mds.15$points))
    colnames(t) <- c("POP","ID",paste("PC",seq(1:n.k),sep=""))
    t <- t[order(match(t$POP, table = ordermatrix[,1])),]
    write.table(t,file=paste(res.dir,"/MDS/",filename,"_MDS_table_points.txt",sep=""),quote=F, row.names = F, col.names = TRUE)

    # eig
    tempeig<-mds.15$eig
    tempeig[which(tempeig<=0)]<-0
    tottempeig<-sum(tempeig)
    perctempeig<-(tempeig/tottempeig)*100
    csperctempeig<-cumsum(perctempeig)
    tmp <- data.frame(mds.15$eig,perctempeig,csperctempeig,stringsAsFactors = F)
    colnames(tmp) <- c("EIG","perc_EIG","CumSum_EIG")
    write.table(tmp,file=paste(res.dir,"/MDS/",filename,"_MDS_table_eig.txt",sep=""),quote=F, col.names=T, row.names = T)

    if (length(tempeig)>20){
      perctempeig20 <- data.frame(perctempeig = perctempeig[1:20])
      p <- ggplot(perctempeig20, aes(x = factor(1:20), y = perctempeig)) +
        geom_bar(stat = "identity", fill ="#A50021", alpha= 0.85) +
        labs(y="%", title="Percentage of Explained Variances zoom") +
        scale_x_discrete(name = "Principal Components") +
        theme_bw()
      ggsave(paste(res.dir,"/MDS/",filename,"_MDS_eig_barplot_zoom.", plotFormat,sep=""), width = 12, height = 9)
    }

    perctempeigD <- data.frame(perctempeig = perctempeig)
    p <- ggplot(perctempeigD, aes(x = factor(1:length(perctempeig)), y = perctempeig)) +
      geom_bar(stat = "identity", fill ="#A50021", alpha= 0.85) +
      labs(y="%", title="Percentage of Explained Variances") +
      scale_x_discrete(name = "Principal Components") +
      theme_classic()
    ggsave(paste(res.dir,"/MDS/",filename,"_MDS_eig_barplot.", plotFormat,sep=""),width = 12, height = 9)

    csperctempeigD <- data.frame(csperctempeig=csperctempeig)
    p <- ggplot(csperctempeigD, aes(x = factor(1:length(csperctempeig)), y = csperctempeig, group=1)) +
      geom_line(color = "midnightblue") +
      labs(x="Principal Components", y="%", title="Cumulative Distribution of Explained Variances") +
      theme_classic()
    ggsave(paste(res.dir,"/MDS/",filename,"_MDS_eig_cumsum.", plotFormat,sep=""), width = 12, height = 9)


    mds <- as.data.frame(mds.15$points)
    mds$BRD<-factor(fam$pop, levels = ordermatrix$V1)

    ##### WS SAVE #####
    if (ws.save == TRUE){
      save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
    }


    mdsAnalysis(mds,n.k, perctempeig, fam, ordermatrix, res.dir, filename, plotFormat)
  }

  ##### PRINCIPAL COMPONENT ANALYSIS #####

  if (flagPCA == TRUE) {
    comb<-combn(n.k,2)
    sink(file=logname, append=T)
    cat("PCA analysis: running ...\n")
    PCA<-paste(res.dir,"/PCA",sep="")
    if (file.exists(PCA) == FALSE) {
      dir.create(PCA)
    } else {
      cat(paste(basename(PCA), " directory already exists!\n", sep=""))
    }
    sink()

    #### PCA PLOT  #####
    pca <- snpgdsPCA(gds.in, verbose=FALSE, snp.id = snp.sample)

    pc.percent <- pca$varprop*100
    # delete NaN values
    pc.percent <- pc.percent[!is.na(pc.percent)]
    pcperc <- data.frame(perc = pc.percent, pc = factor(paste("PC", 1:length(pc.percent), sep="")))



    ##### WS SAVE #####
    if (ws.save == TRUE){
      save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
    }

    p <- ggplot() +
      geom_bar(data = pcperc, aes(x = reorder(pc,-perc), y = perc), stat = "identity", fill = "#A50021", alpha = 0.85) +
      scale_x_discrete(name = "Principal Components") +
      labs(y="%", title="Percentage of Explained Variances") +
      theme_classic() +
      guides(fill = "none")
    ggsave(paste(res.dir,"/PCA/",filename,"_PCA_eig_barplot.", plotFormat,sep=""), width = 12, height = 9)



    if (length(pc.percent)>20){
      pcperc20 <- data.frame(pc = pcperc$pc[1:20], perc = pc.percent[1:20])
      rownames(pcperc20) <- NULL
      p <- ggplot() +
        geom_bar(data = pcperc20, aes(x = reorder(pc, -perc), y = perc), stat = "identity", position="dodge", fill = "#A50021", alpha = 0.85) +
        scale_x_discrete(name = "Principal Components") +
        labs(y="%", title="Percentage of Explained Variances zoom") +
        theme_bw() +
        guides(fill = "none")
      ggsave(paste(res.dir,"/PCA/",filename,"_PCA_eig_barplot_zoom.", plotFormat,sep=""), width = 12, height = 9)
    }

    ### cumsum non ha senso
    ## snpgdsPCA probabilmente considera come nan percentuali di var spiegata troppo piccole, cumsum quindi non arriva a 100
    # temp df for PC

    tab <- as.data.frame(pca$eigenvect)
    tab$id <- pca$sample.id
    tab$pop <- factor(fam$pop, levels = ordermatrix$V1)

    pcaAnalysis(tab, n.k, pc.percent, fam, ordermatrix, res.dir, filename, plotFormat)
  }

  ##### WS SAVE #####
  if (ws.save == TRUE){
    save(list = objects(), file = paste(res.dir, "/", "biostat_", filename,"_ws.RData",sep=""))
  }

  end <- proc.time()
  elapsed <- end - start
  sink(file=logname, append=T)
  cat(paste("Runtime: ", elapsed["elapsed"], "\n", sep=""))
  cat("**********************************************")
  sink()
}



