


################################################################################
################################## BITE REPORT #################################
################################################################################


bite.report <- function(gds.name, wd, out.name = "bite_report") {

  showfile.gds(closeall = T, verbose = F)
  rmd <- system.file("rmd", "report.rmd", package = "BITEV2")

  cat("Running ....\n")

  ##### PATH & NAMES
  filename <- str_sub(gds.name, start = 1, end = -5)

  qc_path <- paste(wd, "/qc_", gds.name, sep="")


  ############# COPIA RMD #############
  rmd.path <- paste0(wd, "/", out.name, ".rmd")
  file.copy(rmd, rmd.path, overwrite = T)

  gds.path <- paste0(wd, "/", gds.name)

  ## check gds path ##
  if (!file.exists(gds.path)){
    cat(paste("GDS file not found in", gds.path, sep="\n"))
    stop("Exit", call. = F)
  }

  ## check dirs ##

  if (!file.exists(paste(wd, "/biostat_", filename, sep=""))) {
    cat("Biostat pre quality control directory not found\n")
    stop("Exit", call. = F)
  }

  if (!file.exists(paste(wd, "/qc_", filename, sep=""))) {
    cat("Quality control directory not found\n")
    stop("Exit", call. = F)
  }

  pqc_filn <- paste("qc_", filename, sep="")

  if (!file.exists(paste(wd, "/biostat_", pqc_filn, sep=""))) {
    cat("Biostat post quality control directory not found\n")
    stop("Exit", call. = F)
  }

  #####################

  showfile.gds(closeall = T, verbose = F)
  gds.in <- snpgdsOpen(gds.path)

  # n marcatori e n individui
  nsnps <- length(read.gdsn(index.gdsn(gds.in, "snp.id")))
  nind <- length(read.gdsn(index.gdsn(gds.in, "sample.id")))

  # pheno info
  pheno <- read.gdsn(index.gdsn(gds.in, "phenotype"))

  # GDS name
  filename <- str_sub(gds.name, start=1, end=-5)


  ####### PRE QC BIOSTAT

  # campioni vs snp
  sink(file = rmd.path, append = T)
  cat("## Bite.biostat pre Quality Control\n")
  cat("### Info\n")
  cat("#### Samples X SNPs\n")
  cat(paste(nind, "X", nsnps, "\n"))
  sink()

  # pop count

  sink(file = rmd.path, append = T)
  cat("\n#### N° individuals x Pop\n")
  # va ragionata di nuovo
  matrix(table(pheno$pop), dimnames = list(unique(pheno$pop), ""))
  sink()


  # general stats SNPS

  biostat_preqc_path <- paste(wd, "/biostat_", filename, "/SNP/", sep = "")

  genstats <- "_SNP_Stats.png"
  tmp <- paste(biostat_preqc_path, filename, genstats, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n### SNP Statistics\n")
  cat(paste("![](", tmp, ")", sep = ""))
  sink()

  # general stats IND


  biostat_preqc_path <- paste(wd, "/biostat_", filename, "/IND/", sep = "")
  genstats <- "_IND_Stats.png"

  tmp <- paste(biostat_preqc_path, filename, genstats, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### IND Statistics\n")
  cat(paste("![](", tmp, ")", sep = ""))
  sink()

  beanplot <- "_IND_HET_beanplot.png"
  tmp <- paste(biostat_preqc_path, filename, beanplot, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  # ind beanplot
  sink(file = rmd.path, append = T)
  cat(paste("\n![Heterozigosity Beanplot](", tmp, ")", sep = ""))
  sink()

  # Multi Dimensional Scaling
  biostat_preqc_path <- paste(wd, "/biostat_", filename, "/MDS/", sep = "")
  mds <- "_MDS_PC_1-vs-2.png"
  tmp <- paste(biostat_preqc_path, filename, mds, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### Multi-Dimensional Scaling\n")
  cat(paste("\n![](", tmp, ")", sep = ""))
  sink()

  # Principal Component Analysis
  biostat_preqc_path <- paste(wd, "/biostat_", filename, "/PCA/", sep = "")
  pca <- "_PCA_PC_1-vs-2.png"
  tmp <- paste(biostat_preqc_path, filename, pca, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### Principal Component Analysis\n")
  cat(paste("\n![](", tmp, ")", sep = ""))
  sink()

  ######### QUALITY CONTROL

  # leggi id_report e snp_report e stampa informazioni
  qc_path <- paste(wd, "/qc_", filename, sep="")
  id_report_path <- paste(qc_path, "/id_report.txt", sep="")
  snp_report_path <-paste(qc_path, "/snp_report.txt", sep="")

  params_path <- paste(qc_path, "/bite_qc_params.txt", sep="")

  params <- read.table(params_path, sep = "\t")
  snp_report <- read.table(snp_report_path)
  id_report <- read.table(id_report_path)

  showfile.gds(closeall = T, verbose = F)
  qc.gds <- snpgdsOpen(paste(qc_path, ".gds", sep=""))

  nind_pqc <- length(read.gdsn(index.gdsn(qc.gds, "sample.id")))
  nsnp_pqc <- length(read.gdsn(index.gdsn(qc.gds, "snp.id")))


  sink(file = rmd.path, append = T)
  cat("\n\n## Quality Control\n")

  cat("\n\n### Parameters\n")

  cat(paste("chromosome.filter", params[1,1], "\n"))
  cat(paste("chromosome.subset", params[2,1], "\n"))
  cat(paste("snp.callrate", params[3,1], "\n"))
  cat(paste("hwe.p", params[4,1], "\n"))
  cat(paste("maf", params[5,1], "\n"))
  cat(paste("ind.callrate", params[6,1], "\n"))
  cat(paste("HetObs.all", params[7,1], "\n"))
  cat(paste("het.min", params[8,1], "\n"))
  cat(paste("het.max", params[9,1], "\n"))
  cat(paste("ibs.threshold", params[10,1], "\n"))
  cat(paste("first.ind", params[11,1], "\n"))
  cat(paste("ld.pruning.params", params[12,1], "\n"))


  # chromosome subset
  cat("\n\n### SNPs Filtering\n")
  cat("\n\n#### Total pre QC:", nrow(snp_report), "SNPs\n")

  tmp <- sum(snp_report[,1] == 1)
  cat(paste("Chromosome Filter - removed: ", tmp , "\n\n", sep=""))

  # call rate
  tmp <- sum(snp_report[,2] == 1)
  cat(paste("Call Rate - removed: ", tmp , "\n\n", sep=""))

  # MAF
  tmp <- sum(snp_report[,3] == 1)
  cat(paste("Minor Allele Frequency - removed: ", tmp , "\n\n", sep=""))

  # HWE
  tmp <- sum(snp_report[,4] == 1)
  cat(paste("Hardy Weinberg Equilibrium - removed: ", tmp , "\n\n", sep=""))

  # LD pruning
  tmp <- sum(snp_report[,5] == 1)
  cat(paste("Linkage Disequilibrium threshold - removed: ", tmp , "\n\n", sep=""))

  cat("\n\n#### Total post QC:", nsnp_pqc, "SNPs\n")

  cat("\n\n### INDs Filtering\n")
  cat("\n\n#### Total pre QC:", nrow(id_report), "INDs\n")

  # Call rate
  tmp <- sum(id_report[,1] == 1)
  cat(paste("Call Rate - removed: ", tmp , "\n\n", sep=""))

  # Het
  tmp <- sum(id_report[,2] == 1)
  cat(paste("Heterozigosity threshold - removed: ", tmp , "\n\n", sep=""))

  # IBS
  tmp <- sum(id_report[,3] == 1)
  cat(paste("Identity By State threshold - removed: ", tmp , "\n\n", sep=""))

  cat("\n\n#### Total post QC:", nind_pqc, "INDs\n")

  sink()


  ####### POST QC BIOSTAT

  # campioni vs snp
  sink(file = rmd.path, append = T)
  cat("## Bite.biostat post Quality Control\n")
  cat("### Info\n")
  cat("#### Samples X SNPs\n")
  cat(paste(nind_pqc, "X", nsnp_pqc, "\n"))
  sink()

  # pop count

  new_pheno <- read.gdsn(index.gdsn(qc.gds, "phenotype"))
  sink(file = rmd.path, append = T)
  cat("\n#### N° individuals x Pop\n")
  matrix(table(new_pheno$pop), dimnames = list(unique(new_pheno$pop), ""))
  sink()


  # general stats SNPS

  pqc_filename <- basename(qc_path)

  biostat_postqc_path <- paste(wd, "/biostat_", pqc_filename, "/SNP/", sep = "")
  genstats <- "_SNP_Stats.png"
  tmp <- paste(biostat_postqc_path, pqc_filename, genstats, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n### SNP general stats\n")
  cat(paste("![](", tmp, ")", sep = ""))
  sink()

  # general stats IND

  biostat_postqc_path <- paste(wd, "/biostat_", pqc_filename, "/IND/", sep = "")
  genstats <- "_IND_Stats.png"
  tmp <- paste(biostat_postqc_path, pqc_filename, genstats, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### IND general stats\n")
  cat(paste("![](", tmp, ")", sep = ""))
  sink()

  beanplot <- "_IND_HET_beanplot.png"
  tmp <- paste(biostat_postqc_path, pqc_filename, beanplot, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  # ind beanplot
  sink(file = rmd.path, append = T)
  cat(paste("\n![Heterozigosity Beanplot](", tmp, ")", sep = ""))
  sink()

  # Multi Dimensional Scaling
  biostat_postqc_path <- paste(wd, "/biostat_", pqc_filename, "/MDS/", sep = "")
  mds <- "_MDS_PC_1-vs-2.png"
  tmp <- paste(biostat_postqc_path, pqc_filename, mds, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### Multi-Dimensional Scaling\n")
  cat(paste("\n![](", tmp, ")", sep = ""))
  sink()

  # Principal Component Analysis
  biostat_postqc_path <- paste(wd, "/biostat_", pqc_filename, "/PCA/", sep = "")
  pca <- "_PCA_PC_1-vs-2.png"
  tmp <- paste(biostat_postqc_path, pqc_filename, pca, sep="")

  if (!file.exists(tmp)) {
    cat("Bite.report() only accepts images in .png format.\nPlease select the option plotFormat = 'png' when using bite.biostat().\n")
    stop("Exit", call. = F)
  }

  sink(file = rmd.path, append = T)
  cat("\n\n### Principal Component Analysis\n")
  cat(paste("\n![](", tmp, ")", sep = ""))
  sink()

}

