source("R/bite.functions.R", local = TRUE)


################################################################################
################################### BITE QC ####################################
################################################################################



bite.qc <- function(gds.path, out.dir, chromosome.filter = "autosome.only",chromosome.subset = NULL, snp.callrate = 0.95, hwe.p = 1e-6, maf = 0.05,ind.callrate = 0.95, HetObs.all = FALSE, het.min = "default", het.max = "default",ibs.threshold = 0.95, first.ind =FALSE, ld.pruning.params = list(method = "composite", slide.max.bp = 500000L, slide.max.n = NA, ld.threshold = 0.2, start.pos = "random"), ...) {
  cat("Running ....\n")
  showfile.gds(closeall = T, verbose = F)

  ########## OPEN GDS FILE ##########
  gds.temp <- snpgdsOpen(gds.path)

  ########## CREATE QC.GDS.IN ##########
  temp <- basename(gds.temp$filename)
  qc.pre <- str_sub(temp, start = 1, end = -5)
  qc.filename <- paste(out.dir, "/qc_", str_sub(temp, start = 1, end = -5), ".gds", sep="")

  file.copy(gds.path, qc.filename, overwrite = TRUE)

  # close orig gds file & open qc gds file
  showfile.gds(closeall=TRUE, verbose = FALSE)
  gds.in <- snpgdsOpen(qc.filename)

  ######### OUT DIR & LOGFILE ##########
  out <- paste(out.dir, "/qc_", str_sub(temp, start=1, end=-5), sep="")
  if (!file.exists(out)) {
    dir.create(out)
  }

  ######### CHECK LD PARAMS ##########
  if (!is.null(ld.pruning.params)) {
    if (ld.pruning.params$method %in% c("composite", "r", "dprime", "corr")) {
      method <- ld.pruning.params$method
    } else {
      cat("Invalid method parameter ....\n")
      stop("Exit", call. = F)
    }

    if (ld.pruning.params$start.pos %in% c("random", "first", "last")) {
      start.pos <- ld.pruning.params$start.pos
    } else {
      cat("Invalid start.pos parameter ....\n")
      stop("Exit", call. = F)
    }

    slide.max.bp <- ld.pruning.params$slide.max.bp
    slide.max.n <- ld.pruning.params$slide.max.n
    ld.threshold <- ld.pruning.params$ld.threshold
  } else {
    method <- NA
    start.pos <- NA
    slide.max.bp <- NA
    slide.max.n <- NA
    ld.threshold <- NA
  }


  qc.logfile <- paste(out, "/qc_", qc.pre, ".log", sep="")
  sink(file=qc.logfile)
  cat("**************** BITE.QC ****************\n")
  cat("***** QC PARAMS *****\n")
  cat(paste("Gds file: ", temp, "\n",
            "chromosome.filter: ", chromosome.filter, "\n", "chromosome.subset: ", ifelse(is.null(chromosome.subset), NA, chromosome.subset), "\n",
            "snp.callrate: ", ifelse(is.null(snp.callrate), NA, snp.callrate), "\n", "hwe.p: ", ifelse(is.null(hwe.p), NA, hwe.p), "\n",  "maf: ", ifelse(is.null(maf),NA, maf), "\n", "ind.callrate: ",
            ifelse(is.null(ind.callrate), NA, ind.callrate), "\n", "HetObs.all: ", HetObs.all, "\n", "het.min: ", ifelse(is.null(het.min), NA, het.min), "\n", "het.max: ", ifelse(is.null(het.max), NA, het.max),
            "\n", "ibs.threshold: ", ifelse(is.null(ibs.threshold), NA, ibs.threshold), "\nLd pruning parameters:\n", "- method: ", method, "\n", "- slide.max.bp: ", slide.max.bp, "\n", "- slide.max.n: ", slide.max.n, "\n",
            "- ld threshold: ",ld.threshold, "\n", "- start.pos: ", start.pos, "\n", sep=""))
  sink()

  ########## EXTRACT INFO ##########
  sample.id <- read.gdsn(index.gdsn(gds.in, "sample.id"))
  snp.id <- read.gdsn(index.gdsn(gds.in, "snp.id"))
  snp.pos <- read.gdsn(index.gdsn(gds.in, "snp.position"))
  snp.chromosome <- read.gdsn(index.gdsn(gds.in, "snp.chromosome"))
  attr.snp.chromosome <- get.attr.gdsn(index.gdsn(gds.in, "snp.chromosome"))
  snp.allele <- read.gdsn(index.gdsn(gds.in, "snp.allele"))
  genotype <- snpgdsGetGeno(gds.in, verbose = F)
  phenotype <- read.gdsn(index.gdsn(gds.in, "phenotype"))
  ordermatrix <- read.gdsn(index.gdsn(gds.in, "ordermatrix"))


  ###### REPORT ######
  snp.report <- data.frame(rep(0, length(snp.id)), row.names = snp.id)
  colnames(snp.report) <- "chromosome.subset"
  snp.report$call.rate <- 0
  snp.report$maf <- 0
  snp.report$hwe <- 0
  snp.report$ld.pruning <- 0
  id.report <- data.frame(rep(0, length(sample.id)), row.names = sample.id)
  colnames(id.report) <- "call.rate"
  id.report$het <- 0
  id.report$ibs <- 0

  ########## CHROMOSOME FILTER ##########

  ##### AUTOSOME ONLY OR ALL #####
  tmp <- c("all", "autosome.only")

  # valid choice ?
  if (!(chromosome.filter %in% tmp)) {
    #break
    cat("Invalid choice for chromosome.filter ....\n")
    stop("Exit", call. = FALSE)
  }

  # check choice
  to_rm1 <- NULL
  if (chromosome.filter == "autosome.only") {
    to_rm1 <- which(snp.chromosome == "X" | snp.chromosome == "Y")
  }

  ##### USER DEFINED SET #####
  to_rm2 <- NULL
  if (!is.null(chromosome.subset)) {
    to_rm2 <- which(!(snp.chromosome %in% chromosome.subset))
  }

  to_rm <- union(to_rm1, to_rm2)

  if (length(to_rm) != 0) {
    ##### REPORT #####
    tmpp <- data.frame(snp.chromosome[to_rm], snp.id[to_rm], snp.pos[to_rm], snp.allele[to_rm])
    colnames(tmpp) <- c("chr", "snp.id", "pos", "allele")
    write.table(tmpp, file=paste(out, "/snp_post_chromosome_filter.txt", sep=""), col.names = TRUE, quote=FALSE)

    # remove elements from snp.chromosome, snp.id, snp.pos, snp.allele
    snp.chromosome <- snp.chromosome[-to_rm]
    snp.id <- snp.id[-to_rm]
    snp.pos <- snp.pos[-to_rm]
    snp.allele <- snp.allele[-to_rm]
    # remove columns from genotype
    genotype <- subset(genotype, select = -to_rm)

    # report update
    snp.report$chromosome.subset[to_rm] <- 1
  }

  ############ CHECK FIRST.IND & QC ############

  sink(qc.logfile, append = T)
  cat("***** QC *****\n")
  sink()

  if (first.ind == FALSE) {

    ########## SNPs QUALITY CONTROL ##########

    ##### CALL RATE #####
    if (!is.null(snp.callrate)) {
      sink(qc.logfile, append = T)
      snp.cr.notok <- snp.callrate.filtering(genotype, snp.id, snp.callrate = 0.95, out)
      sink()
      to_rm <- which(snp.id %in% snp.cr.notok$snp.id)
      # remove snp.cr.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        # update report
        snp.report$call.rate[to_rm] <- 1
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp call rate filtering ....\n")
      sink()
    }




    ##### MINOR ALLELE FREQUENCY (MAF) #####
    if (!is.null(maf)) {
      sink(qc.logfile, append = T)
      snp.maf.notok <- snp.maf.filtering(gds.in, snp.id, maf, out, sample.id)
      sink()
      to_rm <- which(snp.id %in% snp.maf.notok$snp.id)

      # remove snp.maf.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        # update report
        snp.report$maf[to_rm] <- 1
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp maf filtering ....\n")
      sink()
    }


    ##### HARDY WEINBERG EQUILIBRIUM #####
    if (!is.null(hwe.p)) {
      sink(qc.logfile, append = T)
      snp.hwe.notok <- snp.hwe.filtering(gds.in, snp.id, hwe.p, out, sample.id)
      sink()
      to_rm <- which(snp.id %in% snp.hwe.notok$snp.id)

      # remove snp.maf.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        # update report
        snp.report$hwe[to_rm] <- 1
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp hwe filtering ....\n")
      sink()
    }

    ########## LD PRUNING ###########
    if (!is.null(ld.pruning.params)) {
      res.ldpruning <- snpgdsLDpruning(gds.in, snp.id = snp.id, method = method, slide.max.bp = slide.max.bp,
                                       slide.max.n = slide.max.n, ld.threshold = ld.threshold, start.pos = start.pos, verbose = F)

      snp.ldpruning.ok <- unlist(unname(res.ldpruning))
      length(snp.ldpruning.ok)
      to_take <- which(snp.id %in% snp.ldpruning.ok)
      snp.ldpruning.notok <- snp.id[-to_take]
      to_rm <- which(snp.id %in% snp.ldpruning.notok)
      length(to_rm)
      sink(qc.logfile, append = T)
      cat("*** LD treshold ***\n")
      cat(paste("SNPs ok: ", length(snp.ldpruning.ok), "\n", "SNPs not ok: ",
                length(snp.ldpruning.notok), "\nTotal: ", length(snp.id), "\n", sep=""))
      cat("********************\n")
      sink()

      # txt with snp.cr.notok
      write.table(snp.ldpruning.notok, file=paste(out, "/snp.ldpruning.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
      # txt with snp.cr.ok
      write.table(snp.ldpruning.ok, file=paste(out, "/snp.ldpruning.ok.txt", sep=""), col.names = TRUE, quote=FALSE)


      # remove snp.ld.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        snp.report$ld.pruning[to_rm] <- 1
      }

    } else {
      sink(qc.logfile, append = T)
      cat("Skip ld pruning filtering ....\n")
      sink()
    }

    ########## INDs QUALITY CONTROL ##########

    ##### CALL RATE #####
    if (!is.null(ind.callrate)) {
      sink(qc.logfile, append = T)
      ind.cr.notok <- ind.callrate.filtering(genotype, sample.id, ind.callrate, out)
      sink()
      to_rm <- which(sample.id %in% ind.cr.notok$sample.id)

      # uniqpop pre qc
      uniqpop_pre <- unique(phenotype$pop)

      # sample.id, genotype, phenotype, ordermatrix
      if (length(to_rm) != 0) {
        sample.id <- sample.id[-to_rm]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[-to_rm, ]

        id.report$call.rate[to_rm] <- 1
      }

      # uniqpop post qc
      uniqpop_post <- unique(phenotype$pop)

      # se il qc elimina tutti gli inidivui di una popolazione
      # controlla il nodo ordermatrix ed elimina la pop
      if (!(identical(uniqpop_pre, uniqpop_post))) {
        tmpp <- !(uniqpop_pre %in% uniqpop_post)
        to_rm_pop <- uniqpop_pre[tmpp]
        ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
        rownames(ordermatrix) <- NULL
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip ind call rate filtering ....\n")
      sink()
    }


    ##### HETEROZIGOSITY #####
    # Deviations can indicate sample contamination, inbreeding.
    # We suggest removing individuals who deviate ±3 SD from the samples' heterozygosity rate mean.
    # check het.min /het.max val
    if (is.null(het.min) & is.null(het.max)) {
      sink(qc.logfile, append = T)
      cat("Skip ind het filtering ....\n")
      sink()
    } else {
      if (het.min == "default" & het.max != "default") {
        cat("Please enter a value for both het.min & het.max or leave both fields blank....\n")
        stop("Exit", call. = FALSE)
        # break
      } else if (het.min != "default" & het.max == "default") {
        cat("Please enter a value for both het.min & het.max or leave both fields blank....\n")
        stop("Exit", call. = FALSE)
        # break
      }

      sink(qc.logfile, append = T)
      ind.het.notok <- ind.het.filtering(genotype, HetObs.all, sample.id, het.min, het.max, out)
      sink()

      if (!is.null(ind.het.notok)) {
        to_rm <- (sample.id %in% ind.het.notok$sample.id)

        # uniqpop pre qc
        uniqpop_pre <- unique(phenotype$pop)

        # sample.id, genotype, phenotype, ordermatrix
        sample.id <- sample.id[!to_rm]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[!to_rm, ]

        id.report$het[to_rm] <- 1

        # uniqpop post qc
        uniqpop_post <- unique(phenotype$pop)

        # se il qc elimina tutti gli inidivui di una popolazione
        # controlla il nodo ordermatrix ed elimina la pop
        if (!(identical(uniqpop_pre, uniqpop_post))) {
          tmpp <- !(uniqpop_pre %in% uniqpop_post)
          to_rm_pop <- uniqpop_pre[tmpp]
          ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
          rownames(ordermatrix) <- NULL
        }
      }
    }

    ##### IDENTITY BY STATE (IBS) #####

    if (!is.null(ibs.threshold)) {
      # calculate IBS
      ibs <- snpgdsIBS(gds.in, sample.id = sample.id, snp.id = snp.id, verbose = FALSE)
      ibs.matrix <- ibs$ibs

      # INDs to remove
      ibs.blacklist <- vector()

      # define while limits
      maxrow <- nrow(ibs.matrix)
      maxcol <- ncol(ibs.matrix)
      i <- 1

      # calculate inds callrate
      valid<- apply(genotype, 1, function(x) sum(!is.na(x)))
      total <- ncol(genotype)
      crateID <- valid / total
      ind.crate <- data.frame(sample.id, crateID)

      while(i < maxrow) {
        j <- i + 1
        while(j <= maxcol) {

          if (!(j %in% ibs.blacklist) && !(i %in% ibs.blacklist)) {


            if (ibs.matrix[i,j] > ibs.threshold) {

              # coppia di ind con ibs oltre la treshold
              #cat(paste("r:", i, " c:", j, " ", sep=""))
              #cat(paste(sample.id[i], "-", sample.id[j], ": ", ibs.matrix[i,j], sep=""))

              # confronta valore call rate
              i.callrate <- ind.crate$crateID[i]
              j.callrate <- ind.crate$crateID[j]
              #cat(paste(" " ,sample.id[i], " call rate: ", i.callrate, sep=""))
              #cat(paste(" ", sample.id[j], " call rate: ", j.callrate, "\n", sep=""))

              if (i.callrate > j.callrate) {
                ibs.blacklist <- c(ibs.blacklist, j)
                break # smetto di iterare su quella riga (ind)
              } else if (i.callrate < j.callrate) {
                ibs.blacklist <- c(ibs.blacklist, i)
              } else {
                ibs.blacklist <- c(ibs.blacklist, i) # elimina fisso il primo (da cambiare)
              }
            }
          }
          j <- j + 1
        }
        i <- i + 1
      }


      # ind.ibs.ok & ind.ibs.notok
      ind.ibs.ok <- sample.id[-ibs.blacklist]
      ind.ibs.notok <- sample.id[ibs.blacklist]

      write.table(ind.ibs.ok, file=paste(out, "/ind.ibs.ok.txt", sep=""), col.names = F, quote=FALSE)
      write.table(ind.ibs.notok, file=paste(out, "/ind.ibs.notok.txt", sep=""), col.names = F, quote=FALSE)


      # report
      tempp <- ifelse(length(ind.ibs.ok) == 0, length(sample.id), length(ind.ibs.ok))
      sink(qc.logfile, append = T)
      cat("*** IBS treshold ***\n")
      cat(paste("INDs ok: ", tempp, "\n", "INDs not ok: ",
                length(ind.ibs.notok), "\nTotal: ", length(sample.id), "\n", sep=""))
      cat("********************\n")
      sink()
      # aggiorna sample.id, genotype, phenotype e ordernatrix
      # uniqpop pre qc
      uniqpop_pre <- unique(phenotype$pop)

      # sample.id, genotype, phenotype, ordermatrix
      if (length(ibs.blacklist) != 0) {
        sample.id <- sample.id[-ibs.blacklist]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[-ibs.blacklist, ]

        id.report$ibs[ibs.blacklist] <- 1
      }


      # uniqpop post qc
      uniqpop_post <- unique(phenotype$pop)

      # se il qc elimina tutti gli inidivui di una popolazione
      # controlla il nodo ordermatrix ed elimina la pop
      if (!(identical(uniqpop_pre, uniqpop_post))) {
        tmpp <- !(uniqpop_pre %in% uniqpop_post)
        to_rm_pop <- uniqpop_pre[tmpp]
        ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
        rownames(ordermatrix) <- NULL
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip ind ibs filtering ....\n")
      sink()
    }

  } else if (first.ind) {

    ########## INDs QUALITY CONTROL ##########

    ##### CALL RATE #####

    if (!is.null(ind.callrate)) {
      sink(qc.logfile, append = T)
      ind.cr.notok <- ind.callrate.filtering(genotype, sample.id, ind.callrate, out)
      sink()
      to_rm <- which(sample.id %in% ind.cr.notok$sample.id)
      # uniqpop pre qc
      uniqpop_pre <- unique(phenotype$pop)

      # sample.id, genotype, phenotype, ordermatrix
      if (length(to_rm) != 0) {
        sample.id <- sample.id[-to_rm]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[-to_rm, ]

        id.report$call.rate[to_rm] <- 1
      }

      # uniqpop post qc
      uniqpop_post <- unique(phenotype$pop)

      # se il qc elimina tutti gli inidivui di una popolazione
      # controlla il nodo ordermatrix ed elimina la pop
      if (!(identical(uniqpop_pre, uniqpop_post))) {
        tmpp <- !(uniqpop_pre %in% uniqpop_post)
        to_rm_pop <- uniqpop_pre[tmpp]
        ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
        rownames(ordermatrix) <- NULL
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip ind call rate filtering ....\n")
      sink()
    }

    ##### HETEROZIGOSITY #####
    # Deviations can indicate sample contamination, inbreeding.
    # We suggest removing individuals who deviate ±3 SD from the samples' heterozygosity rate mean.

    if (is.null(het.min) & is.null(het.max)) {
      sink(qc.logfile, append = T)
      cat("Skip ind het filtering ....\n")
      sink()
    } else {
      # check het.min /het.max val
      if (het.min == "default" & het.max != "default") {
        cat("Please enter a value for both het.min & het.max or leave both fields blank....\n")
        stop("Exit", call. = FALSE)
      } else if (het.min != "default" & het.max == "default") {
        cat("Please enter a value for both het.min & het.max or leave both fields blank....\n")
        stop("Exit", call. = FALSE)
      }

      sink(qc.logfile, append = T)
      ind.het.notok <- ind.het.filtering(genotype, HetObs.all, sample.id, het.min, het.max, out)
      sink()

      if (!is.null(ind.het.notok)) {
        to_rm <- (sample.id %in% ind.het.notok$sample.id)

        # uniqpop pre qc
        uniqpop_pre <- unique(phenotype$pop)

        # sample.id, genotype, phenotype, ordermatrix
        sample.id <- sample.id[-to_rm]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[-to_rm, ]

        id.report$het[to_rm] <- 1

        # uniqpop post qc
        uniqpop_post <- unique(phenotype$pop)

        # se il qc elimina tutti gli inidivui di una popolazione
        # controlla il nodo ordermatrix ed elimina la pop
        if (!(identical(uniqpop_pre, uniqpop_post))) {
          tmpp <- !(uniqpop_pre %in% uniqpop_post)
          to_rm_pop <- uniqpop_pre[tmpp]
          ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
          rownames(ordermatrix) <- NULL
        }
      }
    }

    ##### IDENTITY BY STATE (IBS) #####

    if (!is.null(ibs.threshold)) {
      # calculate IBS
      ibs <- snpgdsIBS(gds.in, sample.id = sample.id, snp.id = snp.id, verbose = FALSE)
      ibs.matrix <- ibs$ibs

      # INDs to remove
      ibs.blacklist <- vector()

      # define while limits
      maxrow <- nrow(ibs.matrix)
      maxcol <- ncol(ibs.matrix)
      i <- 1

      # calculate inds callrate
      valid<- apply(genotype, 1, function(x) sum(!is.na(x)))
      total <- ncol(genotype)
      crateID <- valid / total
      ind.crate <- data.frame(sample.id, crateID)

      while(i < maxrow) {
        j <- i + 1
        while(j <= maxcol) {

          if (!(j %in% ibs.blacklist) & !(i %in% ibs.blacklist)) {

            if (ibs.matrix[i,j] > ibs.threshold) {

              # coppia di ind con ibs oltre la treshold
              #cat(paste("r:", i, " c:", j, " ", sep=""))
              #cat(paste(sample.id[i], "-", sample.id[j], ": ", ibs.matrix[i,j], sep=""))

              # confronta valore call rate
              i.callrate <- ind.crate$crateID[i]
              j.callrate <- ind.crate$crateID[j]
              #cat(paste(" " ,sample.id[i], " call rate: ", i.callrate, sep=""))
              #cat(paste(" ", sample.id[j], " call rate: ", j.callrate, "\n", sep=""))

              if (i.callrate > j.callrate) {
                ibs.blacklist <- c(ibs.blacklist, j)
                break # smetto di iterare su quella riga (ind)
              } else if (i.callrate < j.callrate) {
                ibs.blacklist <- c(ibs.blacklist, i)
              } else {
                ibs.blacklist <- c(ibs.blacklist, i)
              }
            }
          }
          j <- j + 1
        }
        i <- i + 1
      }

      # ind.ibs.ok & ind.ibs.notok
      ind.ibs.ok <- sample.id[-ibs.blacklist]
      ind.ibs.notok <- sample.id[ibs.blacklist]

      write.table(ind.ibs.ok, file=paste(out, "/ind.ibs.ok.txt", sep=""), col.names = F, quote=FALSE)
      write.table(ind.ibs.notok, file=paste(out, "/ind.ibs.notok.txt", sep=""), col.names = F, quote=FALSE)


      # report
      tempp <- ifelse(length(ind.ibs.ok) == 0, length(sample.id), length(ind.ibs.ok))
      sink(qc.logfile, append = T)
      cat("*** IBS treshold ***\n")
      cat(paste("INDs ok: ", tempp, "\n", "INDs not ok: ",
                length(ind.ibs.notok), "\nTotal: ", length(sample.id), "\n", sep=""))
      cat("********************\n")
      sink()
      # aggiorna sample.id, genotype, phenotype e ordernatrix
      # uniqpop pre qc
      uniqpop_pre <- unique(phenotype$pop)

      # sample.id, genotype, phenotype, ordermatrix
      if (length(ibs.blacklist) != 0) {
        sample.id <- sample.id[-ibs.blacklist]
        phenotype <- phenotype[which(phenotype$id %in% sample.id),]
        rownames(phenotype) <- NULL
        genotype <- genotype[-ibs.blacklist, ]

        id.report$ibs[ibs.blacklist] <- 1
      }


      # uniqpop post qc
      uniqpop_post <- unique(phenotype$pop)

      # se il qc elimina tutti gli inidivui di una popolazione
      # controlla il nodo ordermatrix ed elimina la pop
      if (!(identical(uniqpop_pre, uniqpop_post))) {
        tmpp <- !(uniqpop_pre %in% uniqpop_post)
        to_rm_pop <- uniqpop_pre[tmpp]
        ordermatrix <- ordermatrix[!(ordermatrix$V1 %in% to_rm_pop), ]
        rownames(ordermatrix) <- NULL
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip ind ibs filtering ....\n")
      sink()
    }


    ########## SNPs QUALITY CONTROL ##########

    ##### CALL RATE #####
    if (!is.null(snp.callrate)) {
      sink(qc.logfile, append = T)
      snp.cr.notok <- snp.callrate.filtering(genotype, snp.id, snp.callrate = 0.95, out)
      sink()
      to_rm <- which(snp.id %in% snp.cr.notok$snp.id)
      # remove snp.cr.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        snp.report$call.rate[to_rm] <- 1
      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp call rate filtering ....\n")
      sink()
    }

    ##### MINOR ALLELE FREQUENCY (MAF) #####
    if (!is.null(maf)) {
      sink(qc.logfile, append = T)
      snp.maf.notok <- snp.maf.filtering(gds.in, snp.id, maf, out, sample.id)
      sink()
      to_rm <- which(snp.id %in% snp.maf.notok$snp.id)
      # remove snp.maf.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        snp.report$maf[to_rm] <- 1

      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp maf filtering ....\n")
      sink()
    }


    ##### HARDY WEINBERG EQUILIBRIUM #####
    if (!is.null(hwe.p)) {
      sink(qc.logfile, append = T)
      snp.hwe.notok <- snp.hwe.filtering(gds.in, snp.id, hwe.p, out, sample.id)
      sink()
      to_rm <- which(snp.id %in% snp.hwe.notok$snp.id)
      # remove snp.maf.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        snp.report$hwe[to_rm] <- 1

      }
    } else {
      sink(qc.logfile, append = T)
      cat("Skip snp hwe filtering ....\n")
      sink()
    }

    ########## LD PRUNING ###########
    if (!is.null(ld.pruning.params)) {
      res.ldpruning <- snpgdsLDpruning(gds.in, snp.id = snp.id, method = method, slide.max.bp = slide.max.bp,
                                       slide.max.n = slide.max.n, ld.threshold = ld.threshold, start.pos = start.pos, verbose = F)

      snp.ldpruning.ok <- unlist(unname(res.ldpruning))
      length(snp.ldpruning.ok)
      to_take <- which(snp.id %in% snp.ldpruning.ok)
      snp.ldpruning.notok <- snp.id[-to_take]
      to_rm <- which(snp.id %in% snp.ldpruning.notok)
      length(to_rm)
      sink(qc.logfile, append = T)
      cat("*** LD treshold ***\n")
      cat(paste("SNPs ok: ", length(snp.ldpruning.ok), "\n", "SNPs not ok: ",
                length(snp.ldpruning.notok), "\nTotal: ", length(snp.id), "\n", sep=""))
      cat("********************\n")
      sink()

      # txt with snp.cr.notok
      write.table(snp.ldpruning.notok, file=paste(out, "/snp.ldpruning.notok.txt", sep=""), col.names = TRUE, quote=FALSE)
      # txt with snp.cr.ok
      write.table(snp.ldpruning.ok, file=paste(out, "/snp.ldpruning.ok.txt", sep=""), col.names = TRUE, quote=FALSE)

      # remove snp.ld.notok and update data
      if (length(to_rm) != 0) {
        snp.id <- snp.id[-to_rm]
        snp.pos <- snp.pos[-to_rm]
        snp.chromosome <- snp.chromosome[-to_rm]
        snp.allele <- snp.allele[-to_rm]
        genotype <- subset(genotype, select = -to_rm)

        snp.report$ld.pruning[to_rm] <- 1

      }

    } else {
      sink(qc.logfile, append = T)
      cat("Skip ld pruning filtering ....\n")
      sink()
    }

  } else {
    cat("Invalid param .... \n")
    stop("Exit", call. = F)
  }

  #### PARAMS OUTPUT
  params <- data.frame(values=c(chromosome.filter, ifelse(is.null(chromosome.subset), "NULL", chromosome.subset), snp.callrate, hwe.p, maf, ind.callrate, HetObs.all, het.min, het.max, ibs.threshold, first.ind, paste(ld.pruning.params$method, ld.pruning.params$slide.max.bp, ld.pruning.params$slide.max.n, ld.pruning.params$ld.threshold, ld.pruning.params$start.pos, sep=" ")))
  rownames(params) <- c("chromosome.filter", "chromosome.subset", "snp.callrate", "hwe.p", "maf", "ind.callrate", "HetObs.all","het.min", "het.max", "ibs.threshold", "first.ind", "ld.pruning.params")

  write.table(params, file = paste(out, "/bite_qc_params.txt", sep=""), col.names = T, row.names = T, quote = F, sep="\t")

  ### WRITE REPORT
  write.table(snp.report, file = paste(out, "/snp_report.txt", sep=""), col.names = T, row.names = T, quote = F, sep = "\t")
  write.table(id.report, file = paste(out, "/id_report.txt", sep=""), col.names = T, row.names = T, quote = F, sep = "\t")


  showfile.gds(closeall=TRUE, verbose = FALSE)

  gds.in <- snpgdsOpen(qc.filename, readonly = FALSE)

  update.gds(gds.in, sample.id, snp.chromosome, snp.id,
             snp.pos, snp.allele, genotype, phenotype, ordermatrix)

  return (gds.in)
}














